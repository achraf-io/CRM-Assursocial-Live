#
# TABLE STRUCTURE FOR: tblactivity_log
#

DROP TABLE IF EXISTS `tblactivity_log`;

CREATE TABLE `tblactivity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB AUTO_INCREMENT=514 DEFAULT CHARSET=utf8;

INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (1, 'Non Existing User Tried to Login [Email: chammaa.hossam@assursocial.com, Is Staff Member: No, IP: ::1]', '2021-11-16 14:21:20', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (2, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-16 14:21:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (3, 'Non Existing User Tried to Login [Email: chammaa.hossam@assursocial.com, Is Staff Member: No, IP: ::1]', '2021-11-16 14:21:50', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (4, 'New Role Added [ID: 2.Conseiller]', '2021-11-16 14:42:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (5, 'Role Updated [ID: 1, Name: Responsable]', '2021-11-16 14:47:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (6, 'New Role Added [ID: 3.Supervisor]', '2021-11-16 14:48:04', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (7, 'New Role Added [ID: 4.Gestionnaire]', '2021-11-16 14:48:18', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (8, 'New Role Added [ID: 5.Admin]', '2021-11-16 14:48:50', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (9, 'New Staff Member Added [ID: 2, conseiller conseiller]', '2021-11-16 14:53:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (10, 'Staff Member Updated [ID: 2, conseiller conseiller]', '2021-11-16 14:53:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (11, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 0]', '2021-11-16 14:55:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (12, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 1]', '2021-11-16 14:55:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (13, 'New Staff Member Added [ID: 3, spervisor spervisor]', '2021-11-16 14:56:17', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (14, 'Staff Member Updated [ID: 3, spervisor spervisor]', '2021-11-16 14:56:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (15, 'Staff Member Updated [ID: 2, conseiller conseiller]', '2021-11-16 14:57:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (16, 'Non Existing User Tried to Login [Email: conseiller@conseiller.fr, Is Staff Member: No, IP: ::1]', '2021-11-16 14:57:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (17, 'Non Existing User Tried to Login [Email: conseiller@conseiller.fr, Is Staff Member: No, IP: ::1]', '2021-11-16 14:58:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (18, 'New Staff Member Added [ID: 4, gestionnaire gestionnaire]', '2021-11-16 15:00:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (19, 'Role Updated [ID: 5, Name: Admin]', '2021-11-16 15:04:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (20, 'Role Updated [ID: 5, Name: Admin]', '2021-11-16 15:04:23', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (21, 'Staff Member Updated [ID: 1, Houssameddin chammaa]', '2021-11-16 15:04:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (22, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-16 15:08:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (23, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-16 15:08:23', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (24, 'Role Updated [ID: 4, Name: Gestionnaire]', '2021-11-16 15:10:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (25, 'Role Updated [ID: 1, Name: Responsable]', '2021-11-16 15:15:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (26, 'Role Updated [ID: 3, Name: Supervisor]', '2021-11-16 15:16:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (27, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-17 08:05:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (28, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-17 14:05:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (29, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-17 14:07:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (30, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-17 14:09:50', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (31, 'New Lead Added [ID: 1]', '2021-11-17 14:20:55', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (32, 'New Lead Added [ID: 2]', '2021-11-17 16:33:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (33, 'New Lead Added [ID: 3]', '2021-11-17 16:39:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (34, 'New Lead Added [ID: 4]', '2021-11-17 16:44:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (35, 'New Lead Added [ID: 5]', '2021-11-17 16:58:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (36, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-18 08:02:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (37, 'New Lead Added [ID: 16]', '2021-11-18 09:58:57', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (38, 'New Lead Added [ID: 17]', '2021-11-18 10:00:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (39, 'New Lead Added [ID: 18]', '2021-11-18 10:05:06', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (40, 'New Lead Added [ID: 19]', '2021-11-18 10:10:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (41, 'New Lead Added [ID: 20]', '2021-11-18 10:41:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (42, 'New Lead Added [ID: 21]', '2021-11-18 10:51:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (43, 'New Lead Added [ID: 22]', '2021-11-18 10:54:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (44, 'New Lead Added [ID: 23]', '2021-11-18 11:08:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (45, 'New Lead Added [ID: 24]', '2021-11-18 13:24:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (46, 'New Lead Added [ID: 25]', '2021-11-18 13:28:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (47, 'New Lead Added [ID: 26]', '2021-11-18 13:33:10', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (48, 'New Lead Added [ID: 27]', '2021-11-18 13:54:25', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (49, 'New Lead Added [ID: 28]', '2021-11-18 13:59:38', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (50, 'New Lead Added [ID: 29]', '2021-11-18 14:00:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (51, 'New Lead Added [ID: 30]', '2021-11-18 14:14:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (52, 'New Lead Added [ID: 31]', '2021-11-18 14:16:38', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (53, 'New Lead Added [ID: 32]', '2021-11-18 14:23:21', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (54, 'New Lead Added [ID: 33]', '2021-11-18 14:31:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (55, 'New Lead Added [ID: 34]', '2021-11-18 14:33:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (56, 'New Lead Added [ID: 35]', '2021-11-18 14:34:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (57, 'New Lead Added [ID: 36]', '2021-11-18 14:36:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (58, 'New Lead Added [ID: 37]', '2021-11-18 14:37:19', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (59, 'New Lead Added [ID: 38]', '2021-11-18 14:39:07', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (60, 'New Lead Added [ID: 39]', '2021-11-18 14:42:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (61, 'New Lead Added [ID: 40]', '2021-11-18 14:43:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (62, 'New Lead Added [ID: 41]', '2021-11-18 14:46:24', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (63, 'New Lead Added [ID: 42]', '2021-11-18 14:49:42', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (64, 'New Lead Added [ID: 43]', '2021-11-18 15:16:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (65, 'New Lead Added [ID: 44]', '2021-11-18 15:19:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (66, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 08:06:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (67, 'New Lead Added [ID: 47]', '2021-11-19 08:36:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (68, 'New Lead Added [ID: 50]', '2021-11-19 08:38:17', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (69, 'New Lead Added [ID: 51]', '2021-11-19 08:40:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (70, 'New Lead Added [ID: 52]', '2021-11-19 08:42:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (71, 'New Lead Added [ID: 53]', '2021-11-19 08:47:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (72, 'New Lead Added [ID: 54]', '2021-11-19 08:48:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (73, 'New Lead Added [ID: 55]', '2021-11-19 08:51:44', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (74, 'New Lead Added [ID: 56]', '2021-11-19 08:53:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (75, 'New Leads Status Added [StatusID: 2, Name: déja souscris]', '2021-11-19 10:36:47', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (76, 'New Leads Status Added [StatusID: 3, Name: Doublon]', '2021-11-19 10:37:06', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (77, 'New Leads Status Added [StatusID: 4, Name: Exclusion]', '2021-11-19 10:37:42', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (78, 'New Leads Status Added [StatusID: 5, Name: Fausse Fiche]', '2021-11-19 10:37:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (79, 'New Leads Status Added [StatusID: 6, Name: Faux Numéro]', '2021-11-19 10:38:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (80, 'New Leads Status Added [StatusID: 7, Name: Hors Cible]', '2021-11-19 10:38:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (81, 'New Leads Status Added [StatusID: 8, Name: N\'a pas fait de demande]', '2021-11-19 10:38:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (82, 'New Leads Status Added [StatusID: 9, Name: Pas Intéresser]', '2021-11-19 10:39:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (83, 'New Leads Status Added [StatusID: 10, Name: Trop Chére]', '2021-11-19 10:39:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (84, 'Leads Status Updated [StatusID: 1, Name: Nouvelle Fiche]', '2021-11-19 10:40:49', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (85, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-19 10:43:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (86, 'New Staff Member Added [ID: 5, test test]', '2021-11-19 10:43:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (87, 'User Successfully Logged In [User Id: 5, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:44:12', 'test test');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (88, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:49:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (89, 'Staff Member Updated [ID: 3, spervisor spervisor]', '2021-11-19 10:51:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (90, 'User Successfully Logged In [User Id: 3, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:52:03', 'spervisor spervisor');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (91, 'Non Existing User Tried to Login [Email: chammaa.houssam@asursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:55:18', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (92, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:55:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (93, 'Staff Member Updated [ID: 4, gestionnaire gestionnaire]', '2021-11-19 10:57:55', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (94, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-19 10:58:15', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (95, 'Non Existing User Tried to Login [Email: chammaa.houssam@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:05:41', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (96, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:06:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (97, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-19 11:08:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (98, 'New Staff Member Added [ID: 6, responsable resonsable]', '2021-11-19 11:08:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (99, 'Staff Member Updated [ID: 6, responsable resonsable]', '2021-11-19 11:08:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (100, 'Staff Member Updated [ID: 6, responsable resonsable]', '2021-11-19 11:09:07', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (101, 'Non Existing User Tried to Login [Email: chammaa.hossameddine@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:10:36', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (102, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:11:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (103, 'User Successfully Logged In [User Id: 6, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:11:44', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (104, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-19 11:17:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (105, 'Leads Status Updated [StatusID: 2, Name: déja souscris]', '2021-11-19 11:18:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (106, 'Leads Status Updated [StatusID: 4, Name: Exclusion]', '2021-11-19 11:18:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (107, 'Leads Status Updated [StatusID: 3, Name: Doublon]', '2021-11-19 11:21:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (108, 'Leads Status Updated [StatusID: 5, Name: Fausse Fiche]', '2021-11-19 11:21:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (109, 'Leads Status Updated [StatusID: 6, Name: Faux Numéro]', '2021-11-19 11:22:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (110, 'Leads Status Updated [StatusID: 9, Name: Pas Intéresser]', '2021-11-19 11:22:21', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (111, 'Leads Status Updated [StatusID: 8, Name: N\'a pas fait de demande]', '2021-11-19 11:22:42', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (112, 'Leads Status Updated [StatusID: 10, Name: Trop Chére]', '2021-11-19 11:22:58', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (113, 'Staff Status Changed [StaffID: 6 - Status(Active/Inactive): 0]', '2021-11-19 15:44:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (114, 'Staff Status Changed [StaffID: 6 - Status(Active/Inactive): 1]', '2021-11-19 15:44:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (115, 'Staff Status Changed [StaffID: 4 - Status(Active/Inactive): 0]', '2021-11-19 15:44:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (116, 'Staff Status Changed [StaffID: 4 - Status(Active/Inactive): 1]', '2021-11-19 15:44:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (117, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 0]', '2021-11-19 15:44:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (118, 'Staff Status Changed [StaffID: 5 - Status(Active/Inactive): 0]', '2021-11-19 15:44:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (119, 'Staff Status Changed [StaffID: 3 - Status(Active/Inactive): 0]', '2021-11-19 15:44:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (120, 'Staff Status Changed [StaffID: 6 - Status(Active/Inactive): 0]', '2021-11-19 15:44:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (121, 'Staff Status Changed [StaffID: 4 - Status(Active/Inactive): 0]', '2021-11-19 15:44:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (122, 'Staff Status Changed [StaffID: 4 - Status(Active/Inactive): 1]', '2021-11-19 15:44:49', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (123, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 1]', '2021-11-19 15:44:49', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (124, 'Staff Status Changed [StaffID: 5 - Status(Active/Inactive): 1]', '2021-11-19 15:44:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (125, 'Staff Status Changed [StaffID: 6 - Status(Active/Inactive): 1]', '2021-11-19 15:44:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (126, 'Staff Status Changed [StaffID: 3 - Status(Active/Inactive): 1]', '2021-11-19 15:44:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (127, 'Payment Mode Status Changed [ModeID: 1 Status(Active/Inactive): 0]', '2021-11-19 15:49:24', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (128, 'Payment Mode Status Changed [ModeID: 1 Status(Active/Inactive): 1]', '2021-11-19 15:49:24', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (129, 'Payment Mode Status Changed [ModeID: 1 Status(Active/Inactive): 0]', '2021-11-19 15:49:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (130, 'Payment Mode Status Changed [ModeID: 1 Status(Active/Inactive): 1]', '2021-11-19 15:49:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (131, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 0]', '2021-11-19 15:51:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (132, 'Staff Status Changed [StaffID: 2 - Status(Active/Inactive): 1]', '2021-11-19 15:51:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (133, 'Non Existing User Tried to Login [Email: chammaa.hossameddine@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-22 08:40:25', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (134, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-22 08:41:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (135, 'New Lead Added [ID: 58]', '2021-11-22 13:27:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (136, 'New Lead Added [ID: 60]', '2021-11-22 13:27:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (137, 'New Lead Added [ID: 62]', '2021-11-22 13:27:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (138, 'New Lead Added [ID: 64]', '2021-11-22 13:27:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (139, 'New Lead Added [ID: 66]', '2021-11-22 13:27:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (140, 'New Lead Added [ID: 68]', '2021-11-22 13:27:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (141, 'New Lead Added [ID: 70]', '2021-11-22 13:27:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (142, 'New Lead Added [ID: 72]', '2021-11-22 13:27:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (143, 'New Lead Added [ID: 74]', '2021-11-22 13:27:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (144, 'New Lead Added [ID: 76]', '2021-11-22 13:27:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (145, 'New Lead Added [ID: 78]', '2021-11-22 13:27:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (146, 'New Lead Added [ID: 80]', '2021-11-22 13:27:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (147, 'New Lead Added [ID: 82]', '2021-11-22 13:27:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (148, 'New Lead Added [ID: 84]', '2021-11-22 13:27:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (149, 'New Lead Added [ID: 86]', '2021-11-22 13:27:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (150, 'New Lead Added [ID: 88]', '2021-11-22 13:27:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (151, 'New Lead Added [ID: 90]', '2021-11-22 13:27:57', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (152, 'New Lead Added [ID: 91]', '2021-11-22 13:30:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (153, 'New Lead Added [ID: 92]', '2021-11-22 13:31:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (154, 'New Lead Added [ID: 93]', '2021-11-22 13:33:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (155, 'New Lead Added [ID: 94]', '2021-11-22 14:09:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (156, 'New Lead Added [ID: 95]', '2021-11-22 14:30:50', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (157, 'New Lead Added [ID: 96]', '2021-11-22 14:32:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (158, 'New Lead Added [ID: 97]', '2021-11-22 14:33:17', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (159, 'New Lead Added [ID: 98]', '2021-11-22 14:33:50', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (160, 'New Lead Added [ID: 99]', '2021-11-22 14:38:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (161, 'New Lead Added [ID: 100]', '2021-11-22 14:39:42', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (162, 'New Lead Added [ID: 101]', '2021-11-22 14:40:25', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (163, 'New Lead Added [ID: 102]', '2021-11-22 14:41:57', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (164, 'New Lead Added [ID: 103]', '2021-11-22 14:42:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (165, 'New Lead Added [ID: 104]', '2021-11-22 15:11:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (166, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-22 15:11:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (167, 'New Lead Added [ID: 105]', '2021-11-22 15:12:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (168, 'New Lead Added [ID: 106]', '2021-11-22 16:45:57', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (169, 'New Lead Added [ID: 107]', '2021-11-22 17:00:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (170, 'New Lead Added [ID: 108]', '2021-11-22 17:01:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (171, 'New Lead Added [ID: 109]', '2021-11-22 17:02:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (172, 'New Lead Added [ID: 110]', '2021-11-22 17:15:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (173, 'New Lead Added [ID: 111]', '2021-11-22 17:16:24', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (174, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 08:04:25', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (175, 'New Lead Added [ID: 112]', '2021-11-23 08:08:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (176, 'New Lead Added [ID: 113]', '2021-11-23 08:09:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (177, 'New Lead Added [ID: 114]', '2021-11-23 08:10:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (178, 'New Lead Added [ID: 115]', '2021-11-23 08:12:58', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (179, 'New Lead Added [ID: 116]', '2021-11-23 08:21:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (180, 'New Lead Added [ID: 117]', '2021-11-23 08:27:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (181, 'New Lead Added [ID: 118]', '2021-11-23 09:48:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (182, 'New Ticket Service Added [ID: 1.santé]', '2021-11-23 10:00:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (183, 'New Lead Added [ID: 119]', '2021-11-23 10:18:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (184, 'New Lead Added [ID: 120]', '2021-11-23 10:21:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (185, 'New Lead Added [ID: 121]', '2021-11-23 10:23:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (186, 'New Lead Added [ID: 122]', '2021-11-23 10:26:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (187, 'New Lead Added [ID: 123]', '2021-11-23 10:33:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (188, 'New Lead Added [ID: 124]', '2021-11-23 10:34:25', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (189, 'New Lead Added [ID: 125]', '2021-11-23 10:46:23', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (190, 'New Lead Added [ID: 126]', '2021-11-23 10:47:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (191, 'New Lead Added [ID: 127]', '2021-11-23 10:49:07', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (192, 'New Lead Added [ID: 128]', '2021-11-23 10:51:04', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (193, 'New Leads Status Added [StatusID: 11, Name: Nouvelle fiche]', '2021-11-23 10:53:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (194, 'New Lead Added [ID: 129]', '2021-11-23 10:57:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (195, 'New Lead Added [ID: 130]', '2021-11-23 10:57:47', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (196, 'New Lead Added [ID: 131]', '2021-11-23 11:21:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (197, 'New Lead Added [ID: 132]', '2021-11-23 11:21:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (198, 'New Lead Added [ID: 133]', '2021-11-23 11:25:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (199, 'New Lead Added [ID: 134]', '2021-11-23 11:26:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (200, 'New Lead Added [ID: 135]', '2021-11-23 11:27:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (201, 'New Lead Added [ID: 136]', '2021-11-23 11:28:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (202, 'New Lead Added [ID: 137]', '2021-11-23 11:28:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (203, 'New Lead Added [ID: 138]', '2021-11-23 11:43:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (204, 'New Lead Added [ID: 139]', '2021-11-23 11:45:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (205, 'Leads Status Updated [StatusID: 1, Name: Client]', '2021-11-23 11:52:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (206, 'Leads Status Updated [StatusID: 11, Name: Nouvelle Fich]', '2021-11-23 11:52:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (207, 'New Project Created [ID: 1]', '2021-11-23 12:23:19', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (208, 'New Project Created [ID: 2]', '2021-11-23 12:25:42', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (209, 'New Project Created [ID: 3]', '2021-11-23 14:32:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (210, 'New Project Created [ID: 4]', '2021-11-23 14:32:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (211, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 14:39:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (212, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 14:41:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (213, 'New Project Created [ID: 5]', '2021-11-23 14:41:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (214, 'New Project Created [ID: 6]', '2021-11-23 14:50:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (215, 'New Project Created [ID: 7]', '2021-11-23 14:55:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (216, 'New Lead Added [ID: 140]', '2021-11-23 15:12:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (217, 'New Lead Added [ID: 141]', '2021-11-23 15:13:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (218, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 15:14:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (219, 'Contact Created [ID: 1]', '2021-11-23 15:14:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (220, 'New Client Created [ID: 1, From Staff: 1]', '2021-11-23 15:14:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (221, 'Created Lead Client Profile [LeadID: 141, ClientID: 1]', '2021-11-23 15:14:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (222, 'Customer Info Updated [ID: 1]', '2021-11-23 15:15:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (223, 'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: ::1]', '2021-11-23 15:15:26', 'ok ');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (224, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 15:17:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (225, 'New Staff Member Added [ID: 7, zdzad dzadza]', '2021-11-23 15:47:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (226, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 15:58:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (227, 'New Staff Member Added [ID: 8, etre ryrte]', '2021-11-23 15:58:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (228, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 15:59:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (229, 'New Staff Member Added [ID: 9, erter trzt]', '2021-11-23 15:59:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (230, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 16:03:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (231, 'New Staff Member Added [ID: 10, fg gefr]', '2021-11-23 16:03:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (232, 'Staff Member Updated [ID: 3, spervisor spervisor]', '2021-11-23 16:10:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (233, 'Staff Member Updated [ID: 2, conseiller conseiller]', '2021-11-23 16:11:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (234, 'User Successfully Logged In [User Id: 2, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:11:42', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (235, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:12:25', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (236, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-23 16:13:17', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (237, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 16:14:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (238, 'New Staff Member Added [ID: 11, test test]', '2021-11-23 16:14:08', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (239, 'User Successfully Logged In [User Id: 11, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:14:20', 'test test');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (240, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:17:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (241, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-23 16:19:47', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (242, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-23 16:20:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (243, 'User Successfully Logged In [User Id: 11, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:21:02', 'test test');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (244, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 16:27:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (245, 'Failed Login Attempt [Email: conseiller@conseiller.fr, Is Staff Member: Yes, IP: ::1]', '2021-11-23 17:32:39', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (246, 'Failed Login Attempt [Email: conseiller@conseiller.fr, Is Staff Member: Yes, IP: ::1]', '2021-11-23 17:32:48', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (247, 'User Successfully Logged In [User Id: 2, Is Staff Member: Yes, IP: ::1]', '2021-11-23 17:32:54', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (248, 'New Lead Added [ID: 142]', '2021-11-23 17:37:46', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (249, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 17:37:46', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (250, 'New Lead Added [ID: 143]', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (251, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (252, 'New Lead Added [ID: 144]', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (253, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (254, 'New Lead Added [ID: 145]', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (255, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (256, 'New Lead Added [ID: 146]', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (257, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-23 17:38:03', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (258, 'New Lead Added [ID: 147]', '2021-11-23 17:38:37', 'conseiller conseiller');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (259, 'Failed Login Attempt [Email: chammaa.hossam@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-23 17:40:51', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (260, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-23 17:41:18', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (261, 'Contact Updated [ID: 1]', '2021-11-23 18:17:21', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (262, 'Contact Status Changed [ContactID: 1 Status(Active/Inactive): 0]', '2021-11-23 18:23:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (263, 'Contact Status Changed [ContactID: 1 Status(Active/Inactive): 1]', '2021-11-23 18:24:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (264, 'Contact Status Changed [ContactID: 1 Status(Active/Inactive): 0]', '2021-11-23 18:24:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (265, 'Contact Status Changed [ContactID: 1 Status(Active/Inactive): 1]', '2021-11-23 18:24:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (266, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 09:08:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (267, 'New Lead Added [ID: 148]', '2021-11-24 09:13:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (268, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 09:14:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (269, 'Contact Created [ID: 2]', '2021-11-24 09:14:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (270, 'New Client Created [ID: 2, From Staff: 1]', '2021-11-24 09:14:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (271, 'Created Lead Client Profile [LeadID: 148, ClientID: 2]', '2021-11-24 09:14:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (272, 'New Customer Group Created [ID:1, Name:auto]', '2021-11-24 09:15:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (273, 'New Customer Group Created [ID:2, Name:décennal]', '2021-11-24 09:15:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (274, 'New Customer Group Created [ID:3, Name:prévoyance]', '2021-11-24 09:16:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (275, 'New Customer Group Created [ID:4, Name:santé]', '2021-11-24 09:16:19', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (276, 'Contact Updated [ID: 2]', '2021-11-24 09:19:06', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (277, 'Contact Status Changed [ContactID: 2 Status(Active/Inactive): 0]', '2021-11-24 09:20:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (278, 'Contact Status Changed [ContactID: 2 Status(Active/Inactive): 1]', '2021-11-24 09:20:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (279, 'Staff Member Updated [ID: 6, responsable resonsable]', '2021-11-24 09:25:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (280, 'User Successfully Logged In [User Id: 6, Is Staff Member: Yes, IP: ::1]', '2021-11-24 09:25:18', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (281, 'New Lead Added [ID: 149]', '2021-11-24 09:27:00', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (282, 'Contact Created [ID: 3]', '2021-11-24 09:27:23', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (283, 'New Client Created [ID: 3, From Staff: 6]', '2021-11-24 09:27:23', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (284, 'Created Lead Client Profile [LeadID: 149, ClientID: 3]', '2021-11-24 09:27:23', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (285, 'Customer Info Updated [ID: 1]', '2021-11-24 09:33:58', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (286, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 09:35:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (287, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 09:36:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (288, 'Contact Created [ID: 4]', '2021-11-24 09:36:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (289, 'New Client Created [ID: 4, From Staff: 1]', '2021-11-24 09:36:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (290, 'Created Lead Client Profile [LeadID: 143, ClientID: 4]', '2021-11-24 09:36:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (291, 'Customer Info Updated [ID: 4]', '2021-11-24 09:36:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (292, 'New Lead Added [ID: 150]', '2021-11-24 09:44:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (293, 'New Lead Added [ID: 151]', '2021-11-24 09:45:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (294, 'New Lead Added [ID: 152]', '2021-11-24 09:47:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (295, 'New Lead Added [ID: 153]', '2021-11-24 09:48:21', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (296, 'New Lead Added [ID: 154]', '2021-11-24 09:54:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (297, 'New Lead Added [ID: 155]', '2021-11-24 10:06:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (298, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 10:10:19', 'Client yioou');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (299, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 10:10:19', 'Client yioou');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (300, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:11:47', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (301, 'Staff Member Updated [ID: 4, gestionnaire gestionnaire]', '2021-11-24 10:13:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (302, 'Customer Attachment Deleted [ID: 2]', '2021-11-24 10:14:07', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (303, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:14:18', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (304, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:18:10', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (305, 'Staff Member Updated [ID: 3, spervisor spervisor]', '2021-11-24 10:18:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (306, 'User Successfully Logged In [User Id: 3, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:18:54', 'spervisor spervisor');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (307, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:20:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (308, 'Staff Member Updated [ID: 4, gestionnaire gestionnaire]', '2021-11-24 10:31:32', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (309, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:31:42', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (310, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:35:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (311, 'Failed Login Attempt [Email: gestionnaire@gestionnaire.ki, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:36:28', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (312, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:36:34', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (313, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:38:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (314, 'Role Updated [ID: 2, Name: Conseiller]', '2021-11-24 10:39:44', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (315, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:39:55', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (316, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:41:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (317, 'Staff Member Updated [ID: 4, gestionnaire gestionnaire]', '2021-11-24 10:44:16', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (318, 'User Successfully Logged In [User Id: 4, Is Staff Member: Yes, IP: ::1]', '2021-11-24 10:44:25', 'gestionnaire gestionnaire');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (319, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 11:20:58', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (320, 'Customer Group Deleted [ID:4]', '2021-11-24 14:02:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (321, 'Customer Group Deleted [ID:3]', '2021-11-24 14:02:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (322, 'Customer Group Deleted [ID:2]', '2021-11-24 14:02:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (323, 'Customer Group Deleted [ID:1]', '2021-11-24 14:02:46', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (324, 'Customer Status Changed [ID: 2 Status(Active/Inactive): 0]', '2021-11-24 14:06:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (325, 'Customer Status Changed [ID: 2 Status(Active/Inactive): 1]', '2021-11-24 14:06:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (326, 'Customer Status Changed [ID: 3 Status(Active/Inactive): 0]', '2021-11-24 14:06:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (327, 'Customer Status Changed [ID: 3 Status(Active/Inactive): 1]', '2021-11-24 14:06:04', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (328, 'Customer Status Changed [ID: 1 Status(Active/Inactive): 0]', '2021-11-24 14:06:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (329, 'Customer Status Changed [ID: 1 Status(Active/Inactive): 1]', '2021-11-24 14:06:06', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (330, 'Staff Member Updated [ID: 6, responsable resonsable]', '2021-11-24 14:32:04', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (331, 'User Successfully Logged In [User Id: 6, Is Staff Member: Yes, IP: ::1]', '2021-11-24 14:32:15', 'responsable resonsable');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (332, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:07:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (333, 'Staff Member Updated [ID: 9, erter trzt]', '2021-11-24 15:09:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (334, 'User Successfully Logged In [User Id: 9, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:09:20', 'erter trzt');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (335, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:12:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (336, 'Staff Member Deleted [Name: conseiller conseiller, Data Transferred To: Houssameddin chammaa]', '2021-11-24 15:13:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (337, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:14:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (338, 'New Staff Member Added [ID: 12, andré  mora]', '2021-11-24 15:14:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (339, 'Staff Member Updated [ID: 12, andré  mora]', '2021-11-24 15:15:18', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (340, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:17:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (341, 'New Staff Member Added [ID: 13, silvia alvares ]', '2021-11-24 15:17:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (342, 'New Lead Added [ID: 156]', '2021-11-24 15:19:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (343, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:27', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (344, 'New Lead Added [ID: 157]', '2021-11-24 15:19:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (345, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (346, 'New Lead Added [ID: 158]', '2021-11-24 15:19:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (347, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (348, 'New Lead Added [ID: 159]', '2021-11-24 15:19:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (349, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (350, 'New Lead Added [ID: 160]', '2021-11-24 15:19:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (351, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (352, 'New Lead Added [ID: 161]', '2021-11-24 15:19:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (353, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (354, 'New Lead Added [ID: 162]', '2021-11-24 15:19:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (355, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (356, 'New Lead Added [ID: 163]', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (357, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (358, 'New Lead Added [ID: 164]', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (359, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (360, 'New Lead Added [ID: 165]', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (361, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (362, 'New Lead Added [ID: 166]', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (363, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:19:51', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (364, 'New Lead Added [ID: 167]', '2021-11-24 15:22:19', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (365, 'New Lead Added [ID: 168]', '2021-11-24 15:23:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (366, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:23:13', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (367, 'User Successfully Logged In [User Id: 13, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:24:27', 'silvia alvares ');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (368, 'User Successfully Logged In [User Id: 12, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:25:37', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (369, 'Lead Updated [ID: 168]', '2021-11-24 15:26:25', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (370, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:26:46', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (371, 'Contact Created [ID: 5]', '2021-11-24 15:26:46', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (372, 'New Client Created [ID: 5, From Staff: 12]', '2021-11-24 15:26:46', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (373, 'Created Lead Client Profile [LeadID: 168, ClientID: 5]', '2021-11-24 15:26:46', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (374, 'Contact Updated [ID: 5]', '2021-11-24 15:27:58', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (375, 'New Invoice Item Added [ID:1, Assurance auto]', '2021-11-24 15:32:18', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (376, 'New Contract Type Added [assurance normal]', '2021-11-24 15:36:09', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (377, 'New Contract Added [assuirance auto]', '2021-11-24 15:36:18', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (378, 'Contact Updated [ID: 4]', '2021-11-24 15:37:42', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (379, 'User Successfully Logged In [User Id: 4, Is Staff Member: No, IP: ::1]', '2021-11-24 15:37:56', 'clientauto auto');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (380, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:42:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (381, 'New Lead Added [ID: 169]', '2021-11-24 15:43:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (382, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:43:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (383, 'New Lead Added [ID: 170]', '2021-11-24 15:43:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (384, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:43:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (385, 'New Lead Added [ID: 171]', '2021-11-24 15:43:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (386, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:43:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (387, 'New Lead Added [ID: 172]', '2021-11-24 15:44:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (388, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:44:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (389, 'New Lead Added [ID: 173]', '2021-11-24 15:44:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (390, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 15:44:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (391, 'New Lead Added [ID: 174]', '2021-11-24 15:49:35', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (392, 'Staff Member Updated [ID: 12, andré  mora]', '2021-11-24 15:58:49', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (393, 'User Successfully Logged In [User Id: 12, Is Staff Member: Yes, IP: ::1]', '2021-11-24 15:58:59', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (394, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 16:00:13', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (395, 'Contact Created [ID: 6]', '2021-11-24 16:00:13', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (396, 'New Client Created [ID: 6, From Staff: 12]', '2021-11-24 16:00:13', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (397, 'Created Lead Client Profile [LeadID: 169, ClientID: 6]', '2021-11-24 16:00:13', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (398, 'Contact Updated [ID: 6]', '2021-11-24 16:01:28', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (399, 'Customer Info Updated [ID: 1]', '2021-11-24 16:03:53', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (400, 'Contact Updated [ID: 1]', '2021-11-24 16:04:18', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (401, 'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: ::1]', '2021-11-24 16:04:37', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (402, 'Contact Password Changed [ContactID: 1]', '2021-11-24 16:05:32', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (403, 'Failed Login Attempt [Email: azf@keza.mo, Is Staff Member: No, IP: ::1]', '2021-11-24 16:05:44', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (404, 'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: ::1]', '2021-11-24 16:05:51', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (405, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:07:00', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (406, 'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: ::1]', '2021-11-24 16:09:17', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (407, 'Non Existing User Tried to Login [Email: azf@keza.mo, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:09:23', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (408, 'Non Existing User Tried to Login [Email: azf@keza.mo, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:09:28', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (409, 'User Successfully Logged In [User Id: 1, Is Staff Member: No, IP: ::1]', '2021-11-24 16:11:37', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (410, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 16:14:17', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (411, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 16:14:17', 'ok ok');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (412, 'Failed Login Attempt [Email: andre.mora@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:15:22', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (413, 'Failed Login Attempt [Email: andre.mora@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:15:43', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (414, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:16:16', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (415, 'Staff Member Updated [ID: 12, andré  mora]', '2021-11-24 16:16:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (416, 'User Successfully Logged In [User Id: 12, Is Staff Member: Yes, IP: ::1]', '2021-11-24 16:17:04', 'andré  mora');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (417, 'Failed Login Attempt [Email: chammaa.hossam@assursocial.com, Is Staff Member: Yes, IP: ::1]', '2021-11-24 17:26:45', NULL);
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (418, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-24 17:27:16', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (419, 'New Custom Field Added [service]', '2021-11-24 17:32:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (420, 'Custom Field Updated [service]', '2021-11-24 17:34:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (421, 'Custom Field Status Changed [FieldID: 1 - Active: 1]', '2021-11-24 17:37:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (422, 'Custom Field Status Changed [FieldID: 1 - Active: 0]', '2021-11-24 17:37:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (423, 'Custom Field Updated [service]', '2021-11-24 17:39:19', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (424, 'Custom Field Updated [service]', '2021-11-24 17:40:31', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (425, 'New Lead Added [ID: 175]', '2021-11-24 17:46:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (426, 'Custom Field Updated [service]', '2021-11-24 17:48:37', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (427, 'Custom Field Deleted [1]', '2021-11-24 17:49:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (428, 'New Custom Field Added [leads_services]', '2021-11-24 17:53:21', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (429, 'New Lead Added [ID: 176]', '2021-11-24 17:53:52', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (430, 'New Lead Added [ID: 177]', '2021-11-24 17:57:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (431, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 17:57:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (432, 'New Lead Added [ID: 178]', '2021-11-24 17:58:12', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (433, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 17:58:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (434, 'Contact Created [ID: 7]', '2021-11-24 17:58:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (435, 'New Client Created [ID: 7, From Staff: 1]', '2021-11-24 17:58:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (436, 'Created Lead Client Profile [LeadID: 178, ClientID: 7]', '2021-11-24 17:58:54', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (437, 'New Lead Added [ID: 179]', '2021-11-24 18:01:15', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (438, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:02:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (439, 'Contact Created [ID: 8]', '2021-11-24 18:02:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (440, 'New Client Created [ID: 8, From Staff: 1]', '2021-11-24 18:02:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (441, 'Created Lead Client Profile [LeadID: 179, ClientID: 8]', '2021-11-24 18:02:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (442, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:04:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (443, 'Contact Created [ID: 9]', '2021-11-24 18:04:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (444, 'New Client Created [ID: 9, From Staff: 1]', '2021-11-24 18:04:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (445, 'Created Lead Client Profile [LeadID: 177, ClientID: 9]', '2021-11-24 18:04:22', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (446, 'Custom Field Deleted [2]', '2021-11-24 18:07:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (447, 'New Custom Field Added [service]', '2021-11-24 18:11:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (448, 'New Lead Added [ID: 180]', '2021-11-24 18:12:26', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (449, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:13:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (450, 'Contact Created [ID: 10]', '2021-11-24 18:13:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (451, 'New Client Created [ID: 10, From Staff: 1]', '2021-11-24 18:13:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (452, 'Created Lead Client Profile [LeadID: 180, ClientID: 10]', '2021-11-24 18:13:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (453, 'New Lead Added [ID: 181]', '2021-11-24 18:14:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (454, 'Contact Created [ID: 11]', '2021-11-24 18:15:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (455, 'New Client Created [ID: 11, From Staff: 1]', '2021-11-24 18:15:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (456, 'Created Lead Client Profile [LeadID: 181, ClientID: 11]', '2021-11-24 18:15:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (457, 'New Lead Added [ID: 182]', '2021-11-24 18:17:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (458, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:17:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (459, 'Contact Created [ID: 12]', '2021-11-24 18:17:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (460, 'New Client Created [ID: 12, From Staff: 1]', '2021-11-24 18:17:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (461, 'Created Lead Client Profile [LeadID: 182, ClientID: 12]', '2021-11-24 18:17:34', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (462, 'Custom Field Deleted [4]', '2021-11-24 18:18:09', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (463, 'Custom Field Deleted [3]', '2021-11-24 18:18:14', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (464, 'New Custom Field Added [Equipe]', '2021-11-24 18:20:01', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (465, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:20:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (466, 'New Staff Member Added [ID: 14, tyuty trstr]', '2021-11-24 18:20:48', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (467, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-24 18:21:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (468, 'New Staff Member Added [ID: 15, fghy hdfh]', '2021-11-24 18:21:53', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (469, 'User Successfully Logged In [User Id: 1, Is Staff Member: Yes, IP: ::1]', '2021-11-25 09:05:33', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (470, 'Staff Member Updated [ID: 8, etre ryrte]', '2021-11-25 09:11:17', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (471, 'New Custom Field Added [service]', '2021-11-25 09:14:30', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (472, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-25 09:19:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (473, 'Contact Created [ID: 13]', '2021-11-25 09:19:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (474, 'New Client Created [ID: 13, From Staff: 1]', '2021-11-25 09:19:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (475, 'Created Lead Client Profile [LeadID: 176, ClientID: 13]', '2021-11-25 09:19:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (476, 'Custom Field Updated [Equipe]', '2021-11-25 09:25:45', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (477, 'Custom Field Updated [Equipe]', '2021-11-25 09:26:24', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (478, 'Custom Field Updated [Equipe]', '2021-11-25 09:28:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (479, 'New Lead Added [ID: 183]', '2021-11-25 09:44:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (480, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-25 09:45:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (481, 'Contact Created [ID: 14]', '2021-11-25 09:45:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (482, 'New Client Created [ID: 14, From Staff: 1]', '2021-11-25 09:45:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (483, 'Created Lead Client Profile [LeadID: 183, ClientID: 14]', '2021-11-25 09:45:41', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (484, 'Failed Login Attempt [Email: cl@cl.fi, Is Staff Member: No, IP: ::1]', '2021-11-25 09:51:28', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (485, 'Failed Login Attempt [Email: cl@cl.fi, Is Staff Member: No, IP: ::1]', '2021-11-25 09:51:36', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (486, 'Failed Login Attempt [Email: cl@cl.fi, Is Staff Member: No, IP: ::1]', '2021-11-25 09:51:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (487, 'Failed Login Attempt [Email: cl@cl.fi, Is Staff Member: No, IP: ::1]', '2021-11-25 09:52:04', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (488, 'New Lead Added [ID: 184]', '2021-11-25 09:59:02', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (489, 'New Lead Added [ID: 185]', '2021-11-25 10:03:20', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (490, 'Failed to send email template - Invalid address:  (From): root@localhost<br /><pre>\n\n</pre>', '2021-11-25 10:03:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (491, 'Contact Created [ID: 15]', '2021-11-25 10:03:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (492, 'New Client Created [ID: 15, From Staff: 1]', '2021-11-25 10:03:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (493, 'Created Lead Client Profile [LeadID: 185, ClientID: 15]', '2021-11-25 10:03:56', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (494, 'User Successfully Logged In [User Id: 15, Is Staff Member: No, IP: ::1]', '2021-11-25 10:04:07', 'client ');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (495, 'New Lead Added [ID: 186]', '2021-11-25 10:11:11', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (496, 'Contact Created [ID: 16]', '2021-11-25 10:11:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (497, 'New Client Created [ID: 16, From Staff: 1]', '2021-11-25 10:11:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (498, 'Created Lead Client Profile [LeadID: 186, ClientID: 16]', '2021-11-25 10:11:43', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (499, 'Custom Field Updated [service]', '2021-11-25 11:07:29', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (500, 'New Lead Added [ID: 187]', '2021-11-25 11:07:39', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (501, 'Contact Created [ID: 17]', '2021-11-25 11:08:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (502, 'New Client Created [ID: 17, From Staff: 1]', '2021-11-25 11:08:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (503, 'Created Lead Client Profile [LeadID: 187, ClientID: 17]', '2021-11-25 11:08:40', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (504, 'New Lead Added [ID: 188]', '2021-11-25 11:19:18', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (505, 'Contact Created [ID: 18]', '2021-11-25 11:19:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (506, 'New Client Created [ID: 18, From Staff: 1]', '2021-11-25 11:19:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (507, 'Created Lead Client Profile [LeadID: 188, ClientID: 18]', '2021-11-25 11:19:59', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (508, 'Contact Updated [ID: 15]', '2021-11-25 11:50:03', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (509, 'New Lead Added [ID: 189]', '2021-11-25 11:53:38', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (510, 'Contact Created [ID: 19]', '2021-11-25 11:54:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (511, 'New Client Created [ID: 19, From Staff: 1]', '2021-11-25 11:54:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (512, 'Created Lead Client Profile [LeadID: 189, ClientID: 19]', '2021-11-25 11:54:05', 'Houssameddin chammaa');
INSERT INTO `tblactivity_log` (`id`, `description`, `date`, `staffid`) VALUES (513, 'Customer Info Updated [ID: 19]', '2021-11-25 11:54:16', 'Houssameddin chammaa');


#
# TABLE STRUCTURE FOR: tblannouncements
#

DROP TABLE IF EXISTS `tblannouncements`;

CREATE TABLE `tblannouncements` (
  `announcementid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` text DEFAULT NULL,
  `showtousers` int(11) NOT NULL,
  `showtostaff` int(11) NOT NULL,
  `showname` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `userid` varchar(100) NOT NULL,
  PRIMARY KEY (`announcementid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblclients
#

DROP TABLE IF EXISTS `tblclients`;

CREATE TABLE `tblclients` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(191) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `leadid` int(11) DEFAULT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT 0,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT 0,
  `longitude` varchar(191) DEFAULT NULL,
  `latitude` varchar(191) DEFAULT NULL,
  `default_language` varchar(40) DEFAULT NULL,
  `default_currency` int(11) NOT NULL DEFAULT 0,
  `show_primary_contact` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(40) DEFAULT NULL,
  `registration_confirmed` int(11) NOT NULL DEFAULT 1,
  `addedfrom` int(11) NOT NULL DEFAULT 0,
  `service` varchar(60) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `country` (`country`),
  KEY `leadid` (`leadid`),
  KEY `company` (`company`),
  KEY `active` (`active`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `service`) VALUES (15, NULL, NULL, '0547854', 76, 'paris', '15487', 'ile de france', 'paris', NULL, '2021-11-25 10:03:56', 1, 185, 'paris', 'paris', 'ile de france', '15487', 76, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', 0, 0, NULL, 1, 1, 'santé');
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `service`) VALUES (16, NULL, NULL, '', 76, '', '', '', '', NULL, '2021-11-25 10:11:42', 1, 186, '', '', '', '', 76, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', 0, 0, NULL, 1, 1, 'prévoyance');
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `service`) VALUES (17, NULL, NULL, '', 76, 'paris', '93000', 'ile de france', '', NULL, '2021-11-25 11:08:39', 1, 187, '', 'paris', 'ile de france', '93000', 76, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', 0, 0, NULL, 1, 1, 'décennal');
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `service`) VALUES (18, NULL, NULL, '', 76, 'fsqf', '', 'fsq', '', NULL, '2021-11-25 11:19:59', 1, 188, '', 'fsqf', 'fsq', '', 76, NULL, NULL, NULL, NULL, 0, NULL, NULL, '', 0, 0, NULL, 1, 1, 'prévoyance');
INSERT INTO `tblclients` (`userid`, `company`, `vat`, `phonenumber`, `country`, `city`, `zip`, `state`, `address`, `website`, `datecreated`, `active`, `leadid`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `longitude`, `latitude`, `default_language`, `default_currency`, `show_primary_contact`, `stripe_id`, `registration_confirmed`, `addedfrom`, `service`) VALUES (19, 'ouidad', NULL, '8465465465', 76, 'paris', '75000', 'ile de france', 'zafrzf', '', '2021-11-25 11:54:05', 1, 189, 'zafrzf', 'paris', 'ile de france', '75000', 76, '', '', '', '', 0, NULL, NULL, '', 0, 0, NULL, 1, 1, 'décennal');


#
# TABLE STRUCTURE FOR: tblconsent_purposes
#

DROP TABLE IF EXISTS `tblconsent_purposes`;

CREATE TABLE `tblconsent_purposes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblconsents
#

DROP TABLE IF EXISTS `tblconsents`;

CREATE TABLE `tblconsents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(10) NOT NULL,
  `date` datetime NOT NULL,
  `ip` varchar(40) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `opt_in_purpose_description` text DEFAULT NULL,
  `purpose_id` int(11) NOT NULL,
  `staff_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purpose_id` (`purpose_id`),
  KEY `contact_id` (`contact_id`),
  KEY `lead_id` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontact_permissions
#

DROP TABLE IF EXISTS `tblcontact_permissions`;

CREATE TABLE `tblcontact_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (3, 3, 1);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (4, 4, 1);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (5, 5, 1);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (8, 2, 2);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (9, 3, 2);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (10, 4, 2);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (11, 5, 2);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (13, 1, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (14, 2, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (15, 3, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (16, 4, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (17, 5, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (18, 6, 3);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (20, 2, 4);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (21, 3, 4);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (22, 4, 4);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (23, 5, 4);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (25, 1, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (26, 2, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (27, 3, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (28, 4, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (29, 5, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (30, 6, 5);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (32, 2, 6);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (33, 3, 6);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (34, 4, 6);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (35, 5, 6);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (36, 6, 6);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (37, 2, 1);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (38, 1, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (39, 2, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (40, 3, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (41, 4, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (42, 5, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (43, 6, 7);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (44, 1, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (45, 2, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (46, 3, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (47, 4, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (48, 5, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (49, 6, 8);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (50, 1, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (51, 2, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (52, 3, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (53, 4, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (54, 5, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (55, 6, 9);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (56, 1, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (57, 2, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (58, 3, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (59, 4, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (60, 5, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (61, 6, 10);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (62, 1, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (63, 2, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (64, 3, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (65, 4, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (66, 5, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (67, 6, 11);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (68, 1, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (69, 2, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (70, 3, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (71, 4, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (72, 5, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (73, 6, 12);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (74, 1, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (75, 2, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (76, 3, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (77, 4, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (78, 5, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (79, 6, 13);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (80, 1, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (81, 2, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (82, 3, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (83, 4, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (84, 5, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (85, 6, 14);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (86, 1, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (87, 2, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (88, 3, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (89, 4, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (90, 5, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (91, 6, 15);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (92, 1, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (93, 2, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (94, 3, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (95, 4, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (96, 5, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (97, 6, 16);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (98, 1, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (99, 2, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (100, 3, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (101, 4, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (102, 5, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (103, 6, 17);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (104, 1, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (105, 2, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (106, 3, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (107, 4, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (108, 5, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (109, 6, 18);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (110, 1, 19);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (111, 2, 19);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (112, 3, 19);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (113, 4, 19);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (114, 5, 19);
INSERT INTO `tblcontact_permissions` (`id`, `permission_id`, `userid`) VALUES (115, 6, 19);


#
# TABLE STRUCTURE FOR: tblcontacts
#

DROP TABLE IF EXISTS `tblcontacts`;

CREATE TABLE `tblcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `is_primary` int(11) NOT NULL DEFAULT 1,
  `firstname` varchar(191) NOT NULL,
  `lastname` varchar(191) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` varchar(100) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `email_verification_key` varchar(32) DEFAULT NULL,
  `email_verification_sent_at` datetime DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `profile_image` varchar(191) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `invoice_emails` tinyint(1) NOT NULL DEFAULT 1,
  `estimate_emails` tinyint(1) NOT NULL DEFAULT 1,
  `credit_note_emails` tinyint(1) NOT NULL DEFAULT 1,
  `contract_emails` tinyint(1) NOT NULL DEFAULT 1,
  `task_emails` tinyint(1) NOT NULL DEFAULT 1,
  `project_emails` tinyint(1) NOT NULL DEFAULT 1,
  `ticket_emails` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`),
  KEY `email` (`email`),
  KEY `is_primary` (`is_primary`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (1, 1, 1, 'ok', 'ok', 'azf@keza.mo', '894968', 'décennal', '2021-11-23 15:14:46', '$2a$08$mIJ4XA5J7AAraANVmGAVauA3Ofn7WlIemGzvGG2ipmQW0xAUOkJN2', NULL, NULL, '2021-11-23 15:14:46', NULL, NULL, '::1', '2021-11-24 16:11:37', '2021-11-24 16:05:32', 1, NULL, '', 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (2, 2, 1, 'Client', 'yioou', 'cl@cl.fi', '0548796325', 'Auto', '2021-11-24 09:14:15', '$2a$08$adhBZJs61HBIpPJTEGLkUubQGnk8ABHpSWsuE1ww.p45TMda99Tkq', NULL, NULL, '2021-11-24 09:14:15', NULL, NULL, NULL, NULL, NULL, 1, NULL, '', 0, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (3, 3, 1, 'zsbfjhb', '', 'zffe@zek', '8649864', 'auto', '2021-11-24 09:27:23', '$2a$08$tAzCM49ftakUll7tOEAwtuCiE/TLCUmgs1poXCCU6IokAklF2ishC', NULL, NULL, '2021-11-24 09:27:23', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (4, 4, 1, 'clientauto', 'auto', 'clien@auto.oi', '65465465', 'auto', '2021-11-24 09:36:22', '$2a$08$mj4zgzR6tVyuOMBh7igyueRNkIjxKxem3xfoOUBUv5DAzhxVKkhiC', NULL, NULL, '2021-11-24 09:36:22', NULL, NULL, '::1', '2021-11-24 15:37:56', '2021-11-24 15:37:42', 1, NULL, '', 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (5, 5, 1, 'jean', 'dupont', 'jean@gmail.com', '123456', 'auto', '2021-11-24 15:26:46', '$2a$08$92lqJem1AOk39jnRNBmNdubf/Fkjz0cJ0tzdhsyHRmIMbsXqIMLMW', NULL, NULL, '2021-11-24 15:26:46', NULL, NULL, NULL, NULL, NULL, 1, NULL, '', 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (6, 6, 1, 'prospect', 'prospect', 'prospect@prospect.com', '56464654654', 'santé', '2021-11-24 16:00:13', '$2a$08$w6pL1mysxKcXo5VTkQYyKeGqATfnKTCUSm8x3iyI7eBGPOKDNcXG2', NULL, NULL, '2021-11-24 16:00:12', NULL, NULL, NULL, NULL, '2021-11-24 16:01:28', 1, NULL, '', 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (7, 7, 1, 'fghd', '', 'hgf@hgj.hi', '', '', '2021-11-24 17:58:54', '$2a$08$uu/sacmfdThPGEfozN0MaeQUS1ynEn4eFSINq4/N5V/ROTckUgWZW', NULL, NULL, '2021-11-24 17:58:54', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (8, 8, 1, 'fgjhfg', '', 'fjfj@fgij.ho', '', '', '2021-11-24 18:02:27', '$2a$08$6oy8zXY.Kt/a.j8nhJQJwO7oDVsqyQ8mf5.nSPfTC87jjeWDWMh/e', NULL, NULL, '2021-11-24 18:02:27', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (9, 9, 1, 'client', '', 'dfg@fkg.hy', '56456', '', '2021-11-24 18:04:22', '$2a$08$qJfP4VBn8dYWbivt7nib.eKn5Zd2g.0Zar96eKP98d/wMLpSNcGlu', NULL, NULL, '2021-11-24 18:04:22', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (10, 10, 1, 'tghtu', '', 'jryt@kjl.lo', '', '', '2021-11-24 18:13:01', '$2a$08$38XUyql2qG/7S1fBS52s0e.WlKOlOXNogI/nlm/qDFFXmy90AVrIG', NULL, NULL, '2021-11-24 18:13:01', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (11, 11, 1, 'rfdgtqery', '', 'ezez@ikfj', '', '', '2021-11-24 18:15:09', '$2a$08$rphsNkz8wa5861d7oMyy8O6uPxThhCuQdJpqWoCXsxyP2Bsu3xTOW', NULL, NULL, '2021-11-24 18:15:09', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (12, 12, 1, 'gfh', '', 'fgfg@lfk.juy', '', '', '2021-11-24 18:17:34', '$2a$08$UbwJr812jG7H43rp78amf.6e5D4XwsLAtoKVzsklah1rXmn1fp43S', NULL, NULL, '2021-11-24 18:17:34', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (13, 13, 1, 'yui', '', 'ab@loi.gt', '', '', '2021-11-25 09:19:10', '$2a$08$lgfkKOTDPtW3m9uPJ0fUA.qUvb7Pp5uMzZfq3TBjgwiCwQ4afCczy', NULL, NULL, '2021-11-25 09:19:10', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (14, 14, 1, 'client1', '', 'client1@cl.cl', '045123256', 'Santé', '2021-11-25 09:45:40', '$2a$08$cI2sMYEYkZ7WWm9iBH6SD.PKG1tjUbhILYHN70Zb8KhgkNEDNUHDe', NULL, NULL, '2021-11-25 09:45:40', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (15, 15, 1, 'client', 'client', 'client@li.hi', '0547854', 'santé', '2021-11-25 10:03:56', '$2a$08$TIaQ1wwEs5DdZJ267JIisO8XaTcvqxPVS9tsz61cxlJCeGE.Wkqb2', NULL, NULL, '2021-11-25 10:03:56', NULL, NULL, '::1', '2021-11-25 10:04:07', '2021-11-25 11:50:03', 1, NULL, '', 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (16, 16, 1, 'kjhsqbjh', '', 'frg@ju', '', '', '2021-11-25 10:11:42', '$2a$08$D4.hbE8yY68tIrdxmRJUX.w.Odu6TUPiJ.hHH3dS/TdlqbO8vg/Va', NULL, NULL, '2021-11-25 10:11:42', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (17, 17, 1, 'Houssam', 'eddine', 'Houssam@li', '', 'décennal', '2021-11-25 11:08:39', '$2a$08$w1FVFJCHUTOLz/rUWI2YWuGwDY7ng6AKLl1TtCqmVzV62T2pFgtEG', NULL, NULL, '2021-11-25 11:08:39', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (18, 18, 1, 'sfsfd', 'c', 'c@lio', '', 'sfdf', '2021-11-25 11:19:59', '$2a$08$MEEsOZ6MMSkfGKHVcph5zeMbibHTkN2U.XQPXuTCaJGUlpZljVbcG', NULL, NULL, '2021-11-25 11:19:59', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `tblcontacts` (`id`, `userid`, `is_primary`, `firstname`, `lastname`, `email`, `phonenumber`, `title`, `datecreated`, `password`, `new_pass_key`, `new_pass_key_requested`, `email_verified_at`, `email_verification_key`, `email_verification_sent_at`, `last_ip`, `last_login`, `last_password_change`, `active`, `profile_image`, `direction`, `invoice_emails`, `estimate_emails`, `credit_note_emails`, `contract_emails`, `task_emails`, `project_emails`, `ticket_emails`) VALUES (19, 19, 1, 'ouidad', 'zfz', 'ouidad@li', '8465465465', 'santé ', '2021-11-25 11:54:05', '$2a$08$zlBNQ5kO0YNqg/eYLryB5ua3HaHaMRBXRZjY3sSU/UoiXhvFFPW2i', NULL, NULL, '2021-11-25 11:54:05', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, 1, 1, 1, 1, 1, 1, 1);


#
# TABLE STRUCTURE FOR: tblcontract_comments
#

DROP TABLE IF EXISTS `tblcontract_comments`;

CREATE TABLE `tblcontract_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `contract_id` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontract_renewals
#

DROP TABLE IF EXISTS `tblcontract_renewals`;

CREATE TABLE `tblcontract_renewals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contractid` int(11) NOT NULL,
  `old_start_date` date NOT NULL,
  `new_start_date` date NOT NULL,
  `old_end_date` date DEFAULT NULL,
  `new_end_date` date DEFAULT NULL,
  `old_value` decimal(15,2) DEFAULT NULL,
  `new_value` decimal(15,2) DEFAULT NULL,
  `date_renewed` datetime NOT NULL,
  `renewed_by` varchar(100) NOT NULL,
  `renewed_by_staff_id` int(11) NOT NULL DEFAULT 0,
  `is_on_old_expiry_notified` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcontracts
#

DROP TABLE IF EXISTS `tblcontracts`;

CREATE TABLE `tblcontracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `client` int(11) NOT NULL,
  `datestart` date DEFAULT NULL,
  `dateend` date DEFAULT NULL,
  `contract_type` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `isexpirynotified` int(11) NOT NULL DEFAULT 0,
  `contract_value` decimal(15,2) DEFAULT NULL,
  `trash` tinyint(1) DEFAULT 0,
  `not_visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `signed` tinyint(1) NOT NULL DEFAULT 0,
  `signature` varchar(40) DEFAULT NULL,
  `marked_as_signed` tinyint(1) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client` (`client`),
  KEY `contract_type` (`contract_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontracts` (`id`, `content`, `description`, `subject`, `client`, `datestart`, `dateend`, `contract_type`, `project_id`, `addedfrom`, `dateadded`, `isexpirynotified`, `contract_value`, `trash`, `not_visible_to_client`, `hash`, `signed`, `signature`, `marked_as_signed`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `short_link`) VALUES (1, '<p><span class=\"text-danger text-uppercase mtop15 editor-add-content-notice\"> Cliquez ici pour ajouter du{contact_firstname} contenu</span></p>', 'test', 'assuirance auto', 4, '2021-11-24', NULL, 1, 0, 12, '2021-11-24 15:36:18', 0, '30.00', 0, 0, 'f1cc8b9f2b30ff19b8c6788a6557bad5', 0, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblcontracts_types
#

DROP TABLE IF EXISTS `tblcontracts_types`;

CREATE TABLE `tblcontracts_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblcontracts_types` (`id`, `name`) VALUES (1, 'assurance normal');


#
# TABLE STRUCTURE FOR: tblcountries
#

DROP TABLE IF EXISTS `tblcountries`;

CREATE TABLE `tblcountries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `iso2` char(2) DEFAULT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `long_name` varchar(80) NOT NULL DEFAULT '',
  `iso3` char(3) DEFAULT NULL,
  `numcode` varchar(6) DEFAULT NULL,
  `un_member` varchar(12) DEFAULT NULL,
  `calling_code` varchar(8) DEFAULT NULL,
  `cctld` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8;

INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (1, 'AF', 'Afghanistan', 'Islamic Republic of Afghanistan', 'AFG', '004', 'yes', '93', '.af');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (2, 'AX', 'Aland Islands', '&Aring;land Islands', 'ALA', '248', 'no', '358', '.ax');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (3, 'AL', 'Albania', 'Republic of Albania', 'ALB', '008', 'yes', '355', '.al');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (4, 'DZ', 'Algeria', 'People\'s Democratic Republic of Algeria', 'DZA', '012', 'yes', '213', '.dz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (5, 'AS', 'American Samoa', 'American Samoa', 'ASM', '016', 'no', '1+684', '.as');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (6, 'AD', 'Andorra', 'Principality of Andorra', 'AND', '020', 'yes', '376', '.ad');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (7, 'AO', 'Angola', 'Republic of Angola', 'AGO', '024', 'yes', '244', '.ao');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (8, 'AI', 'Anguilla', 'Anguilla', 'AIA', '660', 'no', '1+264', '.ai');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (9, 'AQ', 'Antarctica', 'Antarctica', 'ATA', '010', 'no', '672', '.aq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (10, 'AG', 'Antigua and Barbuda', 'Antigua and Barbuda', 'ATG', '028', 'yes', '1+268', '.ag');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (11, 'AR', 'Argentina', 'Argentine Republic', 'ARG', '032', 'yes', '54', '.ar');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (12, 'AM', 'Armenia', 'Republic of Armenia', 'ARM', '051', 'yes', '374', '.am');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (13, 'AW', 'Aruba', 'Aruba', 'ABW', '533', 'no', '297', '.aw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (14, 'AU', 'Australia', 'Commonwealth of Australia', 'AUS', '036', 'yes', '61', '.au');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (15, 'AT', 'Austria', 'Republic of Austria', 'AUT', '040', 'yes', '43', '.at');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (16, 'AZ', 'Azerbaijan', 'Republic of Azerbaijan', 'AZE', '031', 'yes', '994', '.az');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (17, 'BS', 'Bahamas', 'Commonwealth of The Bahamas', 'BHS', '044', 'yes', '1+242', '.bs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (18, 'BH', 'Bahrain', 'Kingdom of Bahrain', 'BHR', '048', 'yes', '973', '.bh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (19, 'BD', 'Bangladesh', 'People\'s Republic of Bangladesh', 'BGD', '050', 'yes', '880', '.bd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (20, 'BB', 'Barbados', 'Barbados', 'BRB', '052', 'yes', '1+246', '.bb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (21, 'BY', 'Belarus', 'Republic of Belarus', 'BLR', '112', 'yes', '375', '.by');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (22, 'BE', 'Belgium', 'Kingdom of Belgium', 'BEL', '056', 'yes', '32', '.be');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (23, 'BZ', 'Belize', 'Belize', 'BLZ', '084', 'yes', '501', '.bz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (24, 'BJ', 'Benin', 'Republic of Benin', 'BEN', '204', 'yes', '229', '.bj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (25, 'BM', 'Bermuda', 'Bermuda Islands', 'BMU', '060', 'no', '1+441', '.bm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (26, 'BT', 'Bhutan', 'Kingdom of Bhutan', 'BTN', '064', 'yes', '975', '.bt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (27, 'BO', 'Bolivia', 'Plurinational State of Bolivia', 'BOL', '068', 'yes', '591', '.bo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (28, 'BQ', 'Bonaire, Sint Eustatius and Saba', 'Bonaire, Sint Eustatius and Saba', 'BES', '535', 'no', '599', '.bq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (29, 'BA', 'Bosnia and Herzegovina', 'Bosnia and Herzegovina', 'BIH', '070', 'yes', '387', '.ba');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (30, 'BW', 'Botswana', 'Republic of Botswana', 'BWA', '072', 'yes', '267', '.bw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (31, 'BV', 'Bouvet Island', 'Bouvet Island', 'BVT', '074', 'no', 'NONE', '.bv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (32, 'BR', 'Brazil', 'Federative Republic of Brazil', 'BRA', '076', 'yes', '55', '.br');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (33, 'IO', 'British Indian Ocean Territory', 'British Indian Ocean Territory', 'IOT', '086', 'no', '246', '.io');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (34, 'BN', 'Brunei', 'Brunei Darussalam', 'BRN', '096', 'yes', '673', '.bn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (35, 'BG', 'Bulgaria', 'Republic of Bulgaria', 'BGR', '100', 'yes', '359', '.bg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (36, 'BF', 'Burkina Faso', 'Burkina Faso', 'BFA', '854', 'yes', '226', '.bf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (37, 'BI', 'Burundi', 'Republic of Burundi', 'BDI', '108', 'yes', '257', '.bi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (38, 'KH', 'Cambodia', 'Kingdom of Cambodia', 'KHM', '116', 'yes', '855', '.kh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (39, 'CM', 'Cameroon', 'Republic of Cameroon', 'CMR', '120', 'yes', '237', '.cm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (40, 'CA', 'Canada', 'Canada', 'CAN', '124', 'yes', '1', '.ca');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (41, 'CV', 'Cape Verde', 'Republic of Cape Verde', 'CPV', '132', 'yes', '238', '.cv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (42, 'KY', 'Cayman Islands', 'The Cayman Islands', 'CYM', '136', 'no', '1+345', '.ky');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (43, 'CF', 'Central African Republic', 'Central African Republic', 'CAF', '140', 'yes', '236', '.cf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (44, 'TD', 'Chad', 'Republic of Chad', 'TCD', '148', 'yes', '235', '.td');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (45, 'CL', 'Chile', 'Republic of Chile', 'CHL', '152', 'yes', '56', '.cl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (46, 'CN', 'China', 'People\'s Republic of China', 'CHN', '156', 'yes', '86', '.cn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (47, 'CX', 'Christmas Island', 'Christmas Island', 'CXR', '162', 'no', '61', '.cx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (48, 'CC', 'Cocos (Keeling) Islands', 'Cocos (Keeling) Islands', 'CCK', '166', 'no', '61', '.cc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (49, 'CO', 'Colombia', 'Republic of Colombia', 'COL', '170', 'yes', '57', '.co');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (50, 'KM', 'Comoros', 'Union of the Comoros', 'COM', '174', 'yes', '269', '.km');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (51, 'CG', 'Congo', 'Republic of the Congo', 'COG', '178', 'yes', '242', '.cg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (52, 'CK', 'Cook Islands', 'Cook Islands', 'COK', '184', 'some', '682', '.ck');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (53, 'CR', 'Costa Rica', 'Republic of Costa Rica', 'CRI', '188', 'yes', '506', '.cr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (54, 'CI', 'Cote d\'ivoire (Ivory Coast)', 'Republic of C&ocirc;te D\'Ivoire (Ivory Coast)', 'CIV', '384', 'yes', '225', '.ci');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (55, 'HR', 'Croatia', 'Republic of Croatia', 'HRV', '191', 'yes', '385', '.hr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (56, 'CU', 'Cuba', 'Republic of Cuba', 'CUB', '192', 'yes', '53', '.cu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (57, 'CW', 'Curacao', 'Cura&ccedil;ao', 'CUW', '531', 'no', '599', '.cw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (58, 'CY', 'Cyprus', 'Republic of Cyprus', 'CYP', '196', 'yes', '357', '.cy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (59, 'CZ', 'Czech Republic', 'Czech Republic', 'CZE', '203', 'yes', '420', '.cz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (60, 'CD', 'Democratic Republic of the Congo', 'Democratic Republic of the Congo', 'COD', '180', 'yes', '243', '.cd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (61, 'DK', 'Denmark', 'Kingdom of Denmark', 'DNK', '208', 'yes', '45', '.dk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (62, 'DJ', 'Djibouti', 'Republic of Djibouti', 'DJI', '262', 'yes', '253', '.dj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (63, 'DM', 'Dominica', 'Commonwealth of Dominica', 'DMA', '212', 'yes', '1+767', '.dm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (64, 'DO', 'Dominican Republic', 'Dominican Republic', 'DOM', '214', 'yes', '1+809, 8', '.do');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (65, 'EC', 'Ecuador', 'Republic of Ecuador', 'ECU', '218', 'yes', '593', '.ec');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (66, 'EG', 'Egypt', 'Arab Republic of Egypt', 'EGY', '818', 'yes', '20', '.eg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (67, 'SV', 'El Salvador', 'Republic of El Salvador', 'SLV', '222', 'yes', '503', '.sv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (68, 'GQ', 'Equatorial Guinea', 'Republic of Equatorial Guinea', 'GNQ', '226', 'yes', '240', '.gq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (69, 'ER', 'Eritrea', 'State of Eritrea', 'ERI', '232', 'yes', '291', '.er');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (70, 'EE', 'Estonia', 'Republic of Estonia', 'EST', '233', 'yes', '372', '.ee');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (71, 'ET', 'Ethiopia', 'Federal Democratic Republic of Ethiopia', 'ETH', '231', 'yes', '251', '.et');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (72, 'FK', 'Falkland Islands (Malvinas)', 'The Falkland Islands (Malvinas)', 'FLK', '238', 'no', '500', '.fk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (73, 'FO', 'Faroe Islands', 'The Faroe Islands', 'FRO', '234', 'no', '298', '.fo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (74, 'FJ', 'Fiji', 'Republic of Fiji', 'FJI', '242', 'yes', '679', '.fj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (75, 'FI', 'Finland', 'Republic of Finland', 'FIN', '246', 'yes', '358', '.fi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (76, 'FR', 'France', 'French Republic', 'FRA', '250', 'yes', '33', '.fr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (77, 'GF', 'French Guiana', 'French Guiana', 'GUF', '254', 'no', '594', '.gf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (78, 'PF', 'French Polynesia', 'French Polynesia', 'PYF', '258', 'no', '689', '.pf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (79, 'TF', 'French Southern Territories', 'French Southern Territories', 'ATF', '260', 'no', NULL, '.tf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (80, 'GA', 'Gabon', 'Gabonese Republic', 'GAB', '266', 'yes', '241', '.ga');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (81, 'GM', 'Gambia', 'Republic of The Gambia', 'GMB', '270', 'yes', '220', '.gm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (82, 'GE', 'Georgia', 'Georgia', 'GEO', '268', 'yes', '995', '.ge');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (83, 'DE', 'Germany', 'Federal Republic of Germany', 'DEU', '276', 'yes', '49', '.de');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (84, 'GH', 'Ghana', 'Republic of Ghana', 'GHA', '288', 'yes', '233', '.gh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (85, 'GI', 'Gibraltar', 'Gibraltar', 'GIB', '292', 'no', '350', '.gi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (86, 'GR', 'Greece', 'Hellenic Republic', 'GRC', '300', 'yes', '30', '.gr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (87, 'GL', 'Greenland', 'Greenland', 'GRL', '304', 'no', '299', '.gl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (88, 'GD', 'Grenada', 'Grenada', 'GRD', '308', 'yes', '1+473', '.gd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (89, 'GP', 'Guadaloupe', 'Guadeloupe', 'GLP', '312', 'no', '590', '.gp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (90, 'GU', 'Guam', 'Guam', 'GUM', '316', 'no', '1+671', '.gu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (91, 'GT', 'Guatemala', 'Republic of Guatemala', 'GTM', '320', 'yes', '502', '.gt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (92, 'GG', 'Guernsey', 'Guernsey', 'GGY', '831', 'no', '44', '.gg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (93, 'GN', 'Guinea', 'Republic of Guinea', 'GIN', '324', 'yes', '224', '.gn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (94, 'GW', 'Guinea-Bissau', 'Republic of Guinea-Bissau', 'GNB', '624', 'yes', '245', '.gw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (95, 'GY', 'Guyana', 'Co-operative Republic of Guyana', 'GUY', '328', 'yes', '592', '.gy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (96, 'HT', 'Haiti', 'Republic of Haiti', 'HTI', '332', 'yes', '509', '.ht');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (97, 'HM', 'Heard Island and McDonald Islands', 'Heard Island and McDonald Islands', 'HMD', '334', 'no', 'NONE', '.hm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (98, 'HN', 'Honduras', 'Republic of Honduras', 'HND', '340', 'yes', '504', '.hn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (99, 'HK', 'Hong Kong', 'Hong Kong', 'HKG', '344', 'no', '852', '.hk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (100, 'HU', 'Hungary', 'Hungary', 'HUN', '348', 'yes', '36', '.hu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (101, 'IS', 'Iceland', 'Republic of Iceland', 'ISL', '352', 'yes', '354', '.is');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (102, 'IN', 'India', 'Republic of India', 'IND', '356', 'yes', '91', '.in');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (103, 'ID', 'Indonesia', 'Republic of Indonesia', 'IDN', '360', 'yes', '62', '.id');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (104, 'IR', 'Iran', 'Islamic Republic of Iran', 'IRN', '364', 'yes', '98', '.ir');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (105, 'IQ', 'Iraq', 'Republic of Iraq', 'IRQ', '368', 'yes', '964', '.iq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (106, 'IE', 'Ireland', 'Ireland', 'IRL', '372', 'yes', '353', '.ie');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (107, 'IM', 'Isle of Man', 'Isle of Man', 'IMN', '833', 'no', '44', '.im');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (108, 'IL', 'Israel', 'State of Israel', 'ISR', '376', 'yes', '972', '.il');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (109, 'IT', 'Italy', 'Italian Republic', 'ITA', '380', 'yes', '39', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (110, 'JM', 'Jamaica', 'Jamaica', 'JAM', '388', 'yes', '1+876', '.jm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (111, 'JP', 'Japan', 'Japan', 'JPN', '392', 'yes', '81', '.jp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (112, 'JE', 'Jersey', 'The Bailiwick of Jersey', 'JEY', '832', 'no', '44', '.je');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (113, 'JO', 'Jordan', 'Hashemite Kingdom of Jordan', 'JOR', '400', 'yes', '962', '.jo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (114, 'KZ', 'Kazakhstan', 'Republic of Kazakhstan', 'KAZ', '398', 'yes', '7', '.kz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (115, 'KE', 'Kenya', 'Republic of Kenya', 'KEN', '404', 'yes', '254', '.ke');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (116, 'KI', 'Kiribati', 'Republic of Kiribati', 'KIR', '296', 'yes', '686', '.ki');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (117, 'XK', 'Kosovo', 'Republic of Kosovo', '---', '---', 'some', '381', '');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (118, 'KW', 'Kuwait', 'State of Kuwait', 'KWT', '414', 'yes', '965', '.kw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (119, 'KG', 'Kyrgyzstan', 'Kyrgyz Republic', 'KGZ', '417', 'yes', '996', '.kg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (120, 'LA', 'Laos', 'Lao People\'s Democratic Republic', 'LAO', '418', 'yes', '856', '.la');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (121, 'LV', 'Latvia', 'Republic of Latvia', 'LVA', '428', 'yes', '371', '.lv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (122, 'LB', 'Lebanon', 'Republic of Lebanon', 'LBN', '422', 'yes', '961', '.lb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (123, 'LS', 'Lesotho', 'Kingdom of Lesotho', 'LSO', '426', 'yes', '266', '.ls');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (124, 'LR', 'Liberia', 'Republic of Liberia', 'LBR', '430', 'yes', '231', '.lr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (125, 'LY', 'Libya', 'Libya', 'LBY', '434', 'yes', '218', '.ly');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (126, 'LI', 'Liechtenstein', 'Principality of Liechtenstein', 'LIE', '438', 'yes', '423', '.li');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (127, 'LT', 'Lithuania', 'Republic of Lithuania', 'LTU', '440', 'yes', '370', '.lt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (128, 'LU', 'Luxembourg', 'Grand Duchy of Luxembourg', 'LUX', '442', 'yes', '352', '.lu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (129, 'MO', 'Macao', 'The Macao Special Administrative Region', 'MAC', '446', 'no', '853', '.mo');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (130, 'MK', 'North Macedonia', 'Republic of North Macedonia', 'MKD', '807', 'yes', '389', '.mk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (131, 'MG', 'Madagascar', 'Republic of Madagascar', 'MDG', '450', 'yes', '261', '.mg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (132, 'MW', 'Malawi', 'Republic of Malawi', 'MWI', '454', 'yes', '265', '.mw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (133, 'MY', 'Malaysia', 'Malaysia', 'MYS', '458', 'yes', '60', '.my');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (134, 'MV', 'Maldives', 'Republic of Maldives', 'MDV', '462', 'yes', '960', '.mv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (135, 'ML', 'Mali', 'Republic of Mali', 'MLI', '466', 'yes', '223', '.ml');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (136, 'MT', 'Malta', 'Republic of Malta', 'MLT', '470', 'yes', '356', '.mt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (137, 'MH', 'Marshall Islands', 'Republic of the Marshall Islands', 'MHL', '584', 'yes', '692', '.mh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (138, 'MQ', 'Martinique', 'Martinique', 'MTQ', '474', 'no', '596', '.mq');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (139, 'MR', 'Mauritania', 'Islamic Republic of Mauritania', 'MRT', '478', 'yes', '222', '.mr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (140, 'MU', 'Mauritius', 'Republic of Mauritius', 'MUS', '480', 'yes', '230', '.mu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (141, 'YT', 'Mayotte', 'Mayotte', 'MYT', '175', 'no', '262', '.yt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (142, 'MX', 'Mexico', 'United Mexican States', 'MEX', '484', 'yes', '52', '.mx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (143, 'FM', 'Micronesia', 'Federated States of Micronesia', 'FSM', '583', 'yes', '691', '.fm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (144, 'MD', 'Moldava', 'Republic of Moldova', 'MDA', '498', 'yes', '373', '.md');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (145, 'MC', 'Monaco', 'Principality of Monaco', 'MCO', '492', 'yes', '377', '.mc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (146, 'MN', 'Mongolia', 'Mongolia', 'MNG', '496', 'yes', '976', '.mn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (147, 'ME', 'Montenegro', 'Montenegro', 'MNE', '499', 'yes', '382', '.me');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (148, 'MS', 'Montserrat', 'Montserrat', 'MSR', '500', 'no', '1+664', '.ms');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (149, 'MA', 'Morocco', 'Kingdom of Morocco', 'MAR', '504', 'yes', '212', '.ma');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (150, 'MZ', 'Mozambique', 'Republic of Mozambique', 'MOZ', '508', 'yes', '258', '.mz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (151, 'MM', 'Myanmar (Burma)', 'Republic of the Union of Myanmar', 'MMR', '104', 'yes', '95', '.mm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (152, 'NA', 'Namibia', 'Republic of Namibia', 'NAM', '516', 'yes', '264', '.na');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (153, 'NR', 'Nauru', 'Republic of Nauru', 'NRU', '520', 'yes', '674', '.nr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (154, 'NP', 'Nepal', 'Federal Democratic Republic of Nepal', 'NPL', '524', 'yes', '977', '.np');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (155, 'NL', 'Netherlands', 'Kingdom of the Netherlands', 'NLD', '528', 'yes', '31', '.nl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (156, 'NC', 'New Caledonia', 'New Caledonia', 'NCL', '540', 'no', '687', '.nc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (157, 'NZ', 'New Zealand', 'New Zealand', 'NZL', '554', 'yes', '64', '.nz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (158, 'NI', 'Nicaragua', 'Republic of Nicaragua', 'NIC', '558', 'yes', '505', '.ni');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (159, 'NE', 'Niger', 'Republic of Niger', 'NER', '562', 'yes', '227', '.ne');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (160, 'NG', 'Nigeria', 'Federal Republic of Nigeria', 'NGA', '566', 'yes', '234', '.ng');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (161, 'NU', 'Niue', 'Niue', 'NIU', '570', 'some', '683', '.nu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (162, 'NF', 'Norfolk Island', 'Norfolk Island', 'NFK', '574', 'no', '672', '.nf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (163, 'KP', 'North Korea', 'Democratic People\'s Republic of Korea', 'PRK', '408', 'yes', '850', '.kp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (164, 'MP', 'Northern Mariana Islands', 'Northern Mariana Islands', 'MNP', '580', 'no', '1+670', '.mp');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (165, 'NO', 'Norway', 'Kingdom of Norway', 'NOR', '578', 'yes', '47', '.no');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (166, 'OM', 'Oman', 'Sultanate of Oman', 'OMN', '512', 'yes', '968', '.om');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (167, 'PK', 'Pakistan', 'Islamic Republic of Pakistan', 'PAK', '586', 'yes', '92', '.pk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (168, 'PW', 'Palau', 'Republic of Palau', 'PLW', '585', 'yes', '680', '.pw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (169, 'PS', 'Palestine', 'State of Palestine (or Occupied Palestinian Territory)', 'PSE', '275', 'some', '970', '.ps');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (170, 'PA', 'Panama', 'Republic of Panama', 'PAN', '591', 'yes', '507', '.pa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (171, 'PG', 'Papua New Guinea', 'Independent State of Papua New Guinea', 'PNG', '598', 'yes', '675', '.pg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (172, 'PY', 'Paraguay', 'Republic of Paraguay', 'PRY', '600', 'yes', '595', '.py');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (173, 'PE', 'Peru', 'Republic of Peru', 'PER', '604', 'yes', '51', '.pe');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (174, 'PH', 'Philippines', 'Republic of the Philippines', 'PHL', '608', 'yes', '63', '.ph');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (175, 'PN', 'Pitcairn', 'Pitcairn', 'PCN', '612', 'no', 'NONE', '.pn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (176, 'PL', 'Poland', 'Republic of Poland', 'POL', '616', 'yes', '48', '.pl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (177, 'PT', 'Portugal', 'Portuguese Republic', 'PRT', '620', 'yes', '351', '.pt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (178, 'PR', 'Puerto Rico', 'Commonwealth of Puerto Rico', 'PRI', '630', 'no', '1+939', '.pr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (179, 'QA', 'Qatar', 'State of Qatar', 'QAT', '634', 'yes', '974', '.qa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (180, 'RE', 'Reunion', 'R&eacute;union', 'REU', '638', 'no', '262', '.re');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (181, 'RO', 'Romania', 'Romania', 'ROU', '642', 'yes', '40', '.ro');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (182, 'RU', 'Russia', 'Russian Federation', 'RUS', '643', 'yes', '7', '.ru');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (183, 'RW', 'Rwanda', 'Republic of Rwanda', 'RWA', '646', 'yes', '250', '.rw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (184, 'BL', 'Saint Barthelemy', 'Saint Barth&eacute;lemy', 'BLM', '652', 'no', '590', '.bl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (185, 'SH', 'Saint Helena', 'Saint Helena, Ascension and Tristan da Cunha', 'SHN', '654', 'no', '290', '.sh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (186, 'KN', 'Saint Kitts and Nevis', 'Federation of Saint Christopher and Nevis', 'KNA', '659', 'yes', '1+869', '.kn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (187, 'LC', 'Saint Lucia', 'Saint Lucia', 'LCA', '662', 'yes', '1+758', '.lc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (188, 'MF', 'Saint Martin', 'Saint Martin', 'MAF', '663', 'no', '590', '.mf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (189, 'PM', 'Saint Pierre and Miquelon', 'Saint Pierre and Miquelon', 'SPM', '666', 'no', '508', '.pm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (190, 'VC', 'Saint Vincent and the Grenadines', 'Saint Vincent and the Grenadines', 'VCT', '670', 'yes', '1+784', '.vc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (191, 'WS', 'Samoa', 'Independent State of Samoa', 'WSM', '882', 'yes', '685', '.ws');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (192, 'SM', 'San Marino', 'Republic of San Marino', 'SMR', '674', 'yes', '378', '.sm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (193, 'ST', 'Sao Tome and Principe', 'Democratic Republic of S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'STP', '678', 'yes', '239', '.st');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (194, 'SA', 'Saudi Arabia', 'Kingdom of Saudi Arabia', 'SAU', '682', 'yes', '966', '.sa');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (195, 'SN', 'Senegal', 'Republic of Senegal', 'SEN', '686', 'yes', '221', '.sn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (196, 'RS', 'Serbia', 'Republic of Serbia', 'SRB', '688', 'yes', '381', '.rs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (197, 'SC', 'Seychelles', 'Republic of Seychelles', 'SYC', '690', 'yes', '248', '.sc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (198, 'SL', 'Sierra Leone', 'Republic of Sierra Leone', 'SLE', '694', 'yes', '232', '.sl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (199, 'SG', 'Singapore', 'Republic of Singapore', 'SGP', '702', 'yes', '65', '.sg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (200, 'SX', 'Sint Maarten', 'Sint Maarten', 'SXM', '534', 'no', '1+721', '.sx');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (201, 'SK', 'Slovakia', 'Slovak Republic', 'SVK', '703', 'yes', '421', '.sk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (202, 'SI', 'Slovenia', 'Republic of Slovenia', 'SVN', '705', 'yes', '386', '.si');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (203, 'SB', 'Solomon Islands', 'Solomon Islands', 'SLB', '090', 'yes', '677', '.sb');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (204, 'SO', 'Somalia', 'Somali Republic', 'SOM', '706', 'yes', '252', '.so');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (205, 'ZA', 'South Africa', 'Republic of South Africa', 'ZAF', '710', 'yes', '27', '.za');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (206, 'GS', 'South Georgia and the South Sandwich Islands', 'South Georgia and the South Sandwich Islands', 'SGS', '239', 'no', '500', '.gs');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (207, 'KR', 'South Korea', 'Republic of Korea', 'KOR', '410', 'yes', '82', '.kr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (208, 'SS', 'South Sudan', 'Republic of South Sudan', 'SSD', '728', 'yes', '211', '.ss');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (209, 'ES', 'Spain', 'Kingdom of Spain', 'ESP', '724', 'yes', '34', '.es');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (210, 'LK', 'Sri Lanka', 'Democratic Socialist Republic of Sri Lanka', 'LKA', '144', 'yes', '94', '.lk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (211, 'SD', 'Sudan', 'Republic of the Sudan', 'SDN', '729', 'yes', '249', '.sd');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (212, 'SR', 'Suriname', 'Republic of Suriname', 'SUR', '740', 'yes', '597', '.sr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (213, 'SJ', 'Svalbard and Jan Mayen', 'Svalbard and Jan Mayen', 'SJM', '744', 'no', '47', '.sj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (214, 'SZ', 'Swaziland', 'Kingdom of Swaziland', 'SWZ', '748', 'yes', '268', '.sz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (215, 'SE', 'Sweden', 'Kingdom of Sweden', 'SWE', '752', 'yes', '46', '.se');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (216, 'CH', 'Switzerland', 'Swiss Confederation', 'CHE', '756', 'yes', '41', '.ch');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (217, 'SY', 'Syria', 'Syrian Arab Republic', 'SYR', '760', 'yes', '963', '.sy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (218, 'TW', 'Taiwan', 'Republic of China (Taiwan)', 'TWN', '158', 'former', '886', '.tw');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (219, 'TJ', 'Tajikistan', 'Republic of Tajikistan', 'TJK', '762', 'yes', '992', '.tj');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (220, 'TZ', 'Tanzania', 'United Republic of Tanzania', 'TZA', '834', 'yes', '255', '.tz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (221, 'TH', 'Thailand', 'Kingdom of Thailand', 'THA', '764', 'yes', '66', '.th');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (222, 'TL', 'Timor-Leste (East Timor)', 'Democratic Republic of Timor-Leste', 'TLS', '626', 'yes', '670', '.tl');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (223, 'TG', 'Togo', 'Togolese Republic', 'TGO', '768', 'yes', '228', '.tg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (224, 'TK', 'Tokelau', 'Tokelau', 'TKL', '772', 'no', '690', '.tk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (225, 'TO', 'Tonga', 'Kingdom of Tonga', 'TON', '776', 'yes', '676', '.to');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (226, 'TT', 'Trinidad and Tobago', 'Republic of Trinidad and Tobago', 'TTO', '780', 'yes', '1+868', '.tt');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (227, 'TN', 'Tunisia', 'Republic of Tunisia', 'TUN', '788', 'yes', '216', '.tn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (228, 'TR', 'Turkey', 'Republic of Turkey', 'TUR', '792', 'yes', '90', '.tr');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (229, 'TM', 'Turkmenistan', 'Turkmenistan', 'TKM', '795', 'yes', '993', '.tm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (230, 'TC', 'Turks and Caicos Islands', 'Turks and Caicos Islands', 'TCA', '796', 'no', '1+649', '.tc');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (231, 'TV', 'Tuvalu', 'Tuvalu', 'TUV', '798', 'yes', '688', '.tv');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (232, 'UG', 'Uganda', 'Republic of Uganda', 'UGA', '800', 'yes', '256', '.ug');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (233, 'UA', 'Ukraine', 'Ukraine', 'UKR', '804', 'yes', '380', '.ua');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (234, 'AE', 'United Arab Emirates', 'United Arab Emirates', 'ARE', '784', 'yes', '971', '.ae');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (235, 'GB', 'United Kingdom', 'United Kingdom of Great Britain and Nothern Ireland', 'GBR', '826', 'yes', '44', '.uk');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (236, 'US', 'United States', 'United States of America', 'USA', '840', 'yes', '1', '.us');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (237, 'UM', 'United States Minor Outlying Islands', 'United States Minor Outlying Islands', 'UMI', '581', 'no', 'NONE', 'NONE');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (238, 'UY', 'Uruguay', 'Eastern Republic of Uruguay', 'URY', '858', 'yes', '598', '.uy');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (239, 'UZ', 'Uzbekistan', 'Republic of Uzbekistan', 'UZB', '860', 'yes', '998', '.uz');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (240, 'VU', 'Vanuatu', 'Republic of Vanuatu', 'VUT', '548', 'yes', '678', '.vu');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (241, 'VA', 'Vatican City', 'State of the Vatican City', 'VAT', '336', 'no', '39', '.va');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (242, 'VE', 'Venezuela', 'Bolivarian Republic of Venezuela', 'VEN', '862', 'yes', '58', '.ve');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (243, 'VN', 'Vietnam', 'Socialist Republic of Vietnam', 'VNM', '704', 'yes', '84', '.vn');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (244, 'VG', 'Virgin Islands, British', 'British Virgin Islands', 'VGB', '092', 'no', '1+284', '.vg');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (245, 'VI', 'Virgin Islands, US', 'Virgin Islands of the United States', 'VIR', '850', 'no', '1+340', '.vi');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (246, 'WF', 'Wallis and Futuna', 'Wallis and Futuna', 'WLF', '876', 'no', '681', '.wf');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (247, 'EH', 'Western Sahara', 'Western Sahara', 'ESH', '732', 'no', '212', '.eh');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (248, 'YE', 'Yemen', 'Republic of Yemen', 'YEM', '887', 'yes', '967', '.ye');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (249, 'ZM', 'Zambia', 'Republic of Zambia', 'ZMB', '894', 'yes', '260', '.zm');
INSERT INTO `tblcountries` (`country_id`, `iso2`, `short_name`, `long_name`, `iso3`, `numcode`, `un_member`, `calling_code`, `cctld`) VALUES (250, 'ZW', 'Zimbabwe', 'Republic of Zimbabwe', 'ZWE', '716', 'yes', '263', '.zw');


#
# TABLE STRUCTURE FOR: tblcreditnote_refunds
#

DROP TABLE IF EXISTS `tblcreditnote_refunds`;

CREATE TABLE `tblcreditnote_refunds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `credit_note_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `refunded_on` date NOT NULL,
  `payment_mode` varchar(40) NOT NULL,
  `note` text DEFAULT NULL,
  `amount` decimal(15,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcreditnotes
#

DROP TABLE IF EXISTS `tblcreditnotes`;

CREATE TABLE `tblcreditnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 1,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `adminnote` text DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `clientnote` text DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_credit_note` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `reference_no` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcredits
#

DROP TABLE IF EXISTS `tblcredits`;

CREATE TABLE `tblcredits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `credit_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcurrencies
#

DROP TABLE IF EXISTS `tblcurrencies`;

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `decimal_separator` varchar(5) DEFAULT NULL,
  `thousand_separator` varchar(5) DEFAULT NULL,
  `placement` varchar(10) DEFAULT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (1, '$', 'USD', '.', ',', 'before', 1);
INSERT INTO `tblcurrencies` (`id`, `symbol`, `name`, `decimal_separator`, `thousand_separator`, `placement`, `isdefault`) VALUES (2, '€', 'EUR', ',', '.', 'before', 0);


#
# TABLE STRUCTURE FOR: tblcustomer_admins
#

DROP TABLE IF EXISTS `tblcustomer_admins`;

CREATE TABLE `tblcustomer_admins` (
  `staff_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date_assigned` text NOT NULL,
  KEY `customer_id` (`customer_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomer_admins` (`staff_id`, `customer_id`, `date_assigned`) VALUES (4, 3, '2021-11-24 09:27:39');


#
# TABLE STRUCTURE FOR: tblcustomer_groups
#

DROP TABLE IF EXISTS `tblcustomer_groups`;

CREATE TABLE `tblcustomer_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `groupid` (`groupid`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomers_groups
#

DROP TABLE IF EXISTS `tblcustomers_groups`;

CREATE TABLE `tblcustomers_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblcustomfields
#

DROP TABLE IF EXISTS `tblcustomfields`;

CREATE TABLE `tblcustomfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldto` varchar(30) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `type` varchar(20) NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `display_inline` tinyint(1) NOT NULL DEFAULT 0,
  `field_order` int(11) DEFAULT 0,
  `active` int(11) NOT NULL DEFAULT 1,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `show_on_ticket_form` tinyint(1) NOT NULL DEFAULT 0,
  `only_admin` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_table` tinyint(1) NOT NULL DEFAULT 0,
  `show_on_client_portal` int(11) NOT NULL DEFAULT 0,
  `disalow_client_to_edit` int(11) NOT NULL DEFAULT 0,
  `bs_column` int(11) NOT NULL DEFAULT 12,
  `default_value` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (5, 'staff', 'Equipe', 'staff_equipe', 0, 'select', 'Auto-Sylvia,Santé-Sylvia,prévoyance-Sylvia,décennal-Sylvia', 0, 12, 1, 0, 0, 0, 1, 0, 0, 12, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (6, 'leads', 'service', 'leads_service', 0, 'select', 'auto,décennal,prévoyance,santé', 0, 0, 1, 0, 0, 1, 1, 0, 0, 6, '');
INSERT INTO `tblcustomfields` (`id`, `fieldto`, `name`, `slug`, `required`, `type`, `options`, `display_inline`, `field_order`, `active`, `show_on_pdf`, `show_on_ticket_form`, `only_admin`, `show_on_table`, `show_on_client_portal`, `disalow_client_to_edit`, `bs_column`, `default_value`) VALUES (7, 'customers', 'service', 'customers_service', 0, 'select', 'auto,décennal,prévoyance,santé', 0, 0, 1, 0, 0, 0, 1, 0, 0, 6, NULL);


#
# TABLE STRUCTURE FOR: tblcustomfieldsvalues
#

DROP TABLE IF EXISTS `tblcustomfieldsvalues`;

CREATE TABLE `tblcustomfieldsvalues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `fieldid` int(11) NOT NULL,
  `fieldto` varchar(15) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldto` (`fieldto`),
  KEY `fieldid` (`fieldid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (11, 14, 5, 'staff', 'Auto-Sylvia');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (12, 15, 5, 'staff', 'Auto-Sylvia');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (13, 8, 5, 'staff', 'Auto-Sylvia');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (14, 176, 6, 'leads', 'auto');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (15, 183, 6, 'leads', 'auto');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (16, 14, 7, 'customers', 'auto');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (17, 184, 6, 'leads', 'santé');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (18, 185, 6, 'leads', 'santé');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (19, 186, 6, 'leads', 'prévoyance');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (20, 187, 6, 'leads', 'décennal');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (21, 188, 6, 'leads', 'prévoyance');
INSERT INTO `tblcustomfieldsvalues` (`id`, `relid`, `fieldid`, `fieldto`, `value`) VALUES (22, 189, 6, 'leads', 'décennal');


#
# TABLE STRUCTURE FOR: tbldepartments
#

DROP TABLE IF EXISTS `tbldepartments`;

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(191) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT 0,
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext DEFAULT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(191) NOT NULL DEFAULT 'INBOX',
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `calendar_id` mediumtext DEFAULT NULL,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`departmentid`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbldismissed_announcements
#

DROP TABLE IF EXISTS `tbldismissed_announcements`;

CREATE TABLE `tbldismissed_announcements` (
  `dismissedannouncementid` int(11) NOT NULL AUTO_INCREMENT,
  `announcementid` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`dismissedannouncementid`),
  KEY `announcementid` (`announcementid`),
  KEY `staff` (`staff`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblemailtemplates
#

DROP TABLE IF EXISTS `tblemailtemplates`;

CREATE TABLE `tblemailtemplates` (
  `emailtemplateid` int(11) NOT NULL AUTO_INCREMENT,
  `type` mediumtext NOT NULL,
  `slug` varchar(100) NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `name` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `message` text NOT NULL,
  `fromname` mediumtext NOT NULL,
  `fromemail` varchar(100) DEFAULT NULL,
  `plaintext` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(4) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`emailtemplateid`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;

INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (1, 'client', 'new-client-created', 'english', 'New Contact Added/Registered (Welcome Email)', 'Welcome aboard', 'Dear {contact_firstname} {contact_lastname}<br /><br />Thank you for registering on the <strong>{companyname}</strong> CRM System.<br /><br />We just wanted to say welcome.<br /><br />Please contact us if you need any help.<br /><br />Click here to view your profile: <a href=\"{crm_url}\">{crm_url}</a><br /><br />Kind Regards, <br />{email_signature}<br /><br />(This is an automated email, so please don\'t reply to this email address)', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (2, 'invoice', 'invoice-send-to-client', 'english', 'Send Invoice to Customer', 'Invoice with number {invoice_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">We have prepared the following invoice for you: <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Invoice status</strong>: {invoice_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (3, 'ticket', 'new-ticket-opened-admin', 'english', 'New Ticket Opened (Opened by Staff, Sent to Customer)', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department:</strong> {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a><br /><br />Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (4, 'ticket', 'ticket-reply', 'english', 'Ticket Reply (Sent to Customer)', 'New Ticket Reply', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">You have a new ticket reply to ticket <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket Subject:</strong> {ticket_subject}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (5, 'ticket', 'ticket-autoresponse', 'english', 'New Ticket Opened - Autoresponse', 'New Support Ticket Opened', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Thank you for contacting our support team. A support ticket has now been opened for your request. You will be notified when a response is made by email.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_public_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (6, 'invoice', 'invoice-payment-recorded', 'english', 'Invoice Payment Recorded (Sent to Customer)', 'Invoice Payment Recorded', '<span style=\"font-size: 12pt;\">Hello {contact_firstname}&nbsp;{contact_lastname}<br /><br /></span>Thank you for the payment. Find the payment details below:<br /><br />-------------------------------------------------<br /><br />Amount:&nbsp;<strong>{payment_total}<br /></strong>Date:&nbsp;<strong>{payment_date}</strong><br />Invoice number:&nbsp;<span style=\"font-size: 12pt;\"><strong># {invoice_number}<br /><br /></strong></span>-------------------------------------------------<br /><br />You can always view the invoice for this payment at the following link:&nbsp;<a href=\"{invoice_link}\"><span style=\"font-size: 12pt;\">{invoice_number}</span></a><br /><br />We are looking forward working with you.<br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (7, 'invoice', 'invoice-overdue-notice', 'english', 'Invoice Overdue Notice', 'Invoice Overdue Notice - {invoice_number}', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">This is an overdue notice for invoice <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">This invoice was due: {invoice_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (8, 'invoice', 'invoice-already-send', 'english', 'Invoice Already Sent to Customer', 'Invoice # {invoice_number} ', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">At your request, here is the invoice with number <strong># {invoice_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (9, 'ticket', 'new-ticket-created-staff', 'english', 'New Ticket Created (Opened by Customer, Sent to Staff Members)', 'New Ticket Created', '<span style=\"font-size: 12pt;\">A new support ticket has been opened.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}<br /></span><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (10, 'estimate', 'estimate-send-to-client', 'english', 'Send Estimate to Customer', 'Estimate # {estimate_number} created', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the attached estimate <strong># {estimate_number}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Estimate status:</strong> {estimate_status}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">We look forward to your communication.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}<br /></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (11, 'ticket', 'ticket-reply-to-admin', 'english', 'Ticket Reply (Sent to Staff)', 'New Support Ticket Reply', '<span style=\"font-size: 12pt;\">A new support ticket reply from {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (12, 'estimate', 'estimate-already-send', 'english', 'Estimate Already Sent to Customer', 'Estimate # {estimate_number} ', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank you for your estimate request.</span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (13, 'contract', 'contract-expiration', 'english', 'Contract Expiration Reminder (Sent to Customer Contacts)', 'Contract Expiration Reminder', '<span style=\"font-size: 12pt;\">Dear {client_company}</span><br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (14, 'tasks', 'task-assigned', 'english', 'New Task Assigned (Sent to Staff)', 'New Task Assigned to You - {task_name}', '<span style=\"font-size: 12pt;\">Dear {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\">You have been assigned to a new task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}<br /></span><strong>Start Date:</strong> {task_startdate}<br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {task_priority}<br /><br /></span><span style=\"font-size: 12pt;\"><span>You can view the task on the following link</span>: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (15, 'tasks', 'task-added-as-follower', 'english', 'Staff Member Added as Follower on Task (Sent to Staff)', 'You are added as follower on task - {task_name}', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}<br /></span><br /><span style=\"font-size: 12pt;\">You have been added as follower on the following task:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Start date:</strong> {task_startdate}</span><br /><br /><span>You can view the task on the following link</span><span>: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (16, 'tasks', 'task-commented', 'english', 'New Comment on Task (Sent to Staff)', 'New Comment on Task - {task_name}', 'Dear {staff_firstname}<br /><br />A comment has been made on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><strong>Comment:</strong> {task_comment}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (17, 'tasks', 'task-added-attachment', 'english', 'New Attachment(s) on Task (Sent to Staff)', 'New Attachment on Task - {task_name}', 'Hi {staff_firstname}<br /><br /><strong>{task_user_take_action}</strong> added an attachment on the following task:<br /><br /><strong>Name:</strong> {task_name}<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (18, 'estimate', 'estimate-declined-to-staff', 'english', 'Estimate Declined (Sent to Staff)', 'Customer Declined Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) declined estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (19, 'estimate', 'estimate-accepted-to-staff', 'english', 'Estimate Accepted (Sent to Staff)', 'Customer Accepted Estimate', '<span style=\"font-size: 12pt;\">Hi</span><br /> <br /><span style=\"font-size: 12pt;\">Customer ({client_company}) accepted estimate with number <strong># {estimate_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (20, 'proposals', 'proposal-client-accepted', 'english', 'Customer Action - Accepted (Sent to Staff)', 'Customer Accepted Proposal', '<div>Hi<br /> <br />Client <strong>{proposal_proposal_to}</strong> accepted the following proposal:<br /> <br /><strong>Number:</strong> {proposal_number}<br /><strong>Subject</strong>: {proposal_subject}<br /><strong>Total</strong>: {proposal_total}<br /> <br />View the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>\r\n<div>&nbsp;</div>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (21, 'proposals', 'proposal-send-to-customer', 'english', 'Send Proposal to Customer', 'Proposal With Number {proposal_number} Created', 'Dear {proposal_proposal_to}<br /><br />Please find our attached proposal.<br /><br />This proposal is valid until: {proposal_open_till}<br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Please don\'t hesitate to comment online if you have any questions.<br /><br />We look forward to your communication.<br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (22, 'proposals', 'proposal-client-declined', 'english', 'Customer Action - Declined (Sent to Staff)', 'Client Declined Proposal', 'Hi<br /> <br />Customer <strong>{proposal_proposal_to}</strong> declined the proposal <strong>{proposal_subject}</strong><br /> <br />View the proposal on the following link <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (23, 'proposals', 'proposal-client-thank-you', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting proposal', 'Dear {proposal_proposal_to}<br /> <br />Thank for for accepting the proposal.<br /> <br />We look forward to doing business with you.<br /> <br />We will contact you as soon as possible<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (24, 'proposals', 'proposal-comment-to-client', 'english', 'New Comment  (Sent to Customer/Lead)', 'New Proposal Comment', 'Dear {proposal_proposal_to}<br /> <br />A new comment has been made on the following proposal: <strong>{proposal_number}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (25, 'proposals', 'proposal-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Proposal Comment', 'Hi<br /> <br />A new comment has been made to the proposal <strong>{proposal_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{proposal_link}\">{proposal_number}</a>&nbsp;or from the admin area.<br /> <br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (26, 'estimate', 'estimate-thank-you-to-customer', 'english', 'Thank You Email (Sent to Customer After Accept)', 'Thank for you accepting estimate', '<span style=\"font-size: 12pt;\">Dear {contact_firstname} {contact_lastname}</span><br /> <br /><span style=\"font-size: 12pt;\">Thank for for accepting the estimate.</span><br /> <br /><span style=\"font-size: 12pt;\">We look forward to doing business with you.</span><br /> <br /><span style=\"font-size: 12pt;\">We will contact you as soon as possible.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (27, 'tasks', 'task-deadline-notification', 'english', 'Task Deadline Reminder - Sent to Assigned Members', 'Task Deadline Reminder', 'Hi {staff_firstname}&nbsp;{staff_lastname}<br /><br />This is an automated email from {companyname}.<br /><br />The task <strong>{task_name}</strong> deadline is on <strong>{task_duedate}</strong>. <br />This task is still not finished.<br /><br />You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a><br /><br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (28, 'contract', 'send-contract', 'english', 'Send Contract to Customer', 'Contract - {contract_subject}', '<p><span style=\"font-size: 12pt;\">Hi&nbsp;{contact_firstname}&nbsp;{contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Please find the <a href=\"{contract_link}\">{contract_subject}</a> attached.<br /><br />Description: {contract_description}<br /><br /></span><span style=\"font-size: 12pt;\">Looking forward to hear from you.</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (29, 'invoice', 'invoice-payment-recorded-to-staff', 'english', 'Invoice Payment Recorded (Sent to Staff)', 'New Invoice Payment', '<span style=\"font-size: 12pt;\">Hi</span><br /><br /><span style=\"font-size: 12pt;\">Customer recorded payment for invoice <strong># {invoice_number}</strong></span><br /> <br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (30, 'ticket', 'auto-close-ticket', 'english', 'Auto Close Ticket', 'Ticket Auto Closed', '<p><span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">Ticket {ticket_subject} has been auto close due to inactivity.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket #</strong>: <a href=\"{ticket_public_url}\">{ticket_id}</a></span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority:</strong> {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (31, 'project', 'new-project-discussion-created-to-staff', 'english', 'New Project Discussion (Sent to Project Members)', 'New Project Discussion Created - {project_name}', '<p>Hi {staff_firstname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (32, 'project', 'new-project-discussion-created-to-customer', 'english', 'New Project Discussion (Sent to Customer Contacts)', 'New Project Discussion Created - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project discussion created from <strong>{discussion_creator}</strong><br /><br /><strong>Subject:</strong> {discussion_subject}<br /><strong>Description:</strong> {discussion_description}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (33, 'project', 'new-project-file-uploaded-to-customer', 'english', 'New Project File(s) Uploaded (Sent to Customer Contacts)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello {contact_firstname} {contact_lastname}<br /><br />New project file is uploaded on <strong>{project_name}</strong> from <strong>{file_creator}</strong><br /><br />You can view the project on the following link: <a href=\"{project_link}\">{project_name}</a><br /><br />To view the file in our CRM you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (34, 'project', 'new-project-file-uploaded-to-staff', 'english', 'New Project File(s) Uploaded (Sent to Project Members)', 'New Project File(s) Uploaded - {project_name}', '<p>Hello&nbsp;{staff_firstname}</p>\r\n<p>New project&nbsp;file is uploaded on&nbsp;<strong>{project_name}</strong> from&nbsp;<strong>{file_creator}</strong></p>\r\n<p>You can view the project on the following link: <a href=\"{project_link}\">{project_name}<br /></a><br />To view&nbsp;the file you can click on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></p>\r\n<p>Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (35, 'project', 'new-project-discussion-comment-to-customer', 'english', 'New Discussion Comment  (Sent to Customer Contacts)', 'New Discussion Comment', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Discussion subject:</strong> {discussion_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Comment</strong>: {discussion_comment}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (36, 'project', 'new-project-discussion-comment-to-staff', 'english', 'New Discussion Comment (Sent to Project Members)', 'New Discussion Comment', '<p>Hi {staff_firstname}<br /><br />New discussion comment has been made on <strong>{discussion_subject}</strong> from <strong>{comment_creator}</strong><br /><br /><strong>Discussion subject:</strong> {discussion_subject}<br /><strong>Comment:</strong> {discussion_comment}<br /><br />You can view the discussion on the following link: <a href=\"{discussion_link}\">{discussion_subject}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (37, 'project', 'staff-added-as-project-member', 'english', 'Staff Added as Project Member', 'New project assigned to you', '<p>Hi {staff_firstname}<br /><br />New project has been assigned to you.<br /><br />You can view the project on the following link <a href=\"{project_link}\">{project_name}</a><br /><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (38, 'estimate', 'estimate-expiry-reminder', 'english', 'Estimate Expiration Reminder', 'Estimate Expiration Reminder', '<p><span style=\"font-size: 12pt;\">Hello {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\">The estimate with <strong># {estimate_number}</strong> will expire on <strong>{estimate_expirydate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the estimate on the following link: <a href=\"{estimate_link}\">{estimate_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (39, 'proposals', 'proposal-expiry-reminder', 'english', 'Proposal Expiration Reminder', 'Proposal Expiration Reminder', '<p>Hello {proposal_proposal_to}<br /><br />The proposal {proposal_number}&nbsp;will expire on <strong>{proposal_open_till}</strong><br /><br />You can view the proposal on the following link: <a href=\"{proposal_link}\">{proposal_number}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (40, 'staff', 'new-staff-created', 'english', 'New Staff Created (Welcome Email)', 'You are added as staff member', 'Hi {staff_firstname}<br /><br />You are added as member on our CRM.<br /><br />Please use the following logic credentials:<br /><br /><strong>Email:</strong> {staff_email}<br /><strong>Password:</strong> {password}<br /><br />Click <a href=\"{admin_url}\">here </a>to login in the dashboard.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (41, 'client', 'contact-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2>Create a new password</h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a {companyname}&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (42, 'client', 'contact-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<strong><span style=\"font-size: 14pt;\">You have changed your password.</span><br /></strong><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {contact_email}<br /><br />If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (43, 'client', 'contact-set-password', 'english', 'Set New Password', 'Set new password on {companyname} ', '<h2><span style=\"font-size: 14pt;\">Setup your new password on {companyname}</span></h2>\r\nPlease use the following link to set up your new password:<br /><br /><a href=\"{set_password_url}\">Set new password</a><br /><br />Keep it in your records so you don\'t forget it.<br /><br />Please set your new password in <strong>48 hours</strong>. After that, you won\'t be able to set your password because this link will expire.<br /><br />You can login at: <a href=\"{crm_url}\">{crm_url}</a><br />Your email address for login: {contact_email}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (44, 'staff', 'staff-forgot-password', 'english', 'Forgot Password', 'Create New Password', '<h2><span style=\"font-size: 14pt;\">Create a new password</span></h2>\r\nForgot your password?<br /> To create a new password, just follow this link:<br /> <br /><a href=\"{reset_password_url}\">Reset Password</a><br /> <br /> You received this email, because it was requested by a <strong>{companyname}</strong>&nbsp;user. This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same. <br /><br /> {email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (45, 'staff', 'staff-password-reseted', 'english', 'Password Reset - Confirmation', 'Your password has been changed', '<span style=\"font-size: 14pt;\"><strong>You have changed your password.<br /></strong></span><br /> Please, keep it in your records so you don\'t forget it.<br /> <br /> Your email address for login is: {staff_email}<br /><br /> If this wasnt you, please contact us.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (46, 'project', 'assigned-to-project', 'english', 'New Project Created (Sent to Customer Contacts)', 'New Project Created', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>New project is assigned to your company.<br /><br /><strong>Project Name:</strong>&nbsp;{project_name}<br /><strong>Project Start Date:</strong>&nbsp;{project_start_date}</p>\r\n<p>You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>We are looking forward hearing from you.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (47, 'tasks', 'task-added-attachment-to-contacts', 'english', 'New Attachment(s) on Task (Sent to Customer Contacts)', 'New Attachment on Task - {task_name}', '<span>Hi {contact_firstname} {contact_lastname}</span><br /><br /><strong>{task_user_take_action}</strong><span> added an attachment on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (48, 'tasks', 'task-commented-to-contacts', 'english', 'New Comment on Task (Sent to Customer Contacts)', 'New Comment on Task - {task_name}', '<span>Dear {contact_firstname} {contact_lastname}</span><br /><br /><span>A comment has been made on the following task:</span><br /><br /><strong>Name:</strong><span> {task_name}</span><br /><strong>Comment:</strong><span> {task_comment}</span><br /><br /><span>You can view the task on the following link: </span><a href=\"{task_link}\">{task_name}</a><br /><br /><span>Kind Regards,</span><br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (49, 'leads', 'new-lead-assigned', 'english', 'New Lead Assigned to Staff Member', 'New lead assigned to you', '<p>Hello {lead_assigned}<br /><br />New lead is assigned to you.<br /><br /><strong>Lead Name:</strong>&nbsp;{lead_name}<br /><strong>Lead Email:</strong>&nbsp;{lead_email}<br /><br />You can view the lead on the following link: <a href=\"{lead_link}\">{lead_name}</a><br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (50, 'client', 'client-statement', 'english', 'Statement - Account Summary', 'Account Statement from {statement_from} to {statement_to}', 'Dear {contact_firstname} {contact_lastname}, <br /><br />Its been a great experience working with you.<br /><br />Attached with this email is a list of all transactions for the period between {statement_from} to {statement_to}<br /><br />For your information your account balance due is total:&nbsp;{statement_balance_due}<br /><br />Please contact us if you need more information.<br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (51, 'ticket', 'ticket-assigned-to-admin', 'english', 'New Ticket Assigned (Sent to Staff)', 'New support ticket has been assigned to you', '<p><span style=\"font-size: 12pt;\">Hi</span></p>\r\n<p><span style=\"font-size: 12pt;\">A new support ticket&nbsp;has been assigned to you.</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject</strong>: {ticket_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Department</strong>: {ticket_department}</span><br /><span style=\"font-size: 12pt;\"><strong>Priority</strong>: {ticket_priority}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Ticket message:</strong></span><br /><span style=\"font-size: 12pt;\">{ticket_message}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the ticket on the following link: <a href=\"{ticket_url}\">#{ticket_id}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (52, 'client', 'new-client-registered-to-admin', 'english', 'New Customer Registration (Sent to admins)', 'New Customer Registration', 'Hello.<br /><br />New customer registration on your customer portal:<br /><br /><strong>Firstname:</strong>&nbsp;{contact_firstname}<br /><strong>Lastname:</strong>&nbsp;{contact_lastname}<br /><strong>Company:</strong>&nbsp;{client_company}<br /><strong>Email:</strong>&nbsp;{contact_email}<br /><br />Best Regards', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (53, 'leads', 'new-web-to-lead-form-submitted', 'english', 'Web to lead form submitted - Sent to lead', '{lead_name} - We Received Your Request', 'Hello {lead_name}.<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (54, 'staff', 'two-factor-authentication', 'english', 'Two Factor Authentication', 'Confirm Your Login', '<p>Hi {staff_firstname}</p>\r\n<p style=\"text-align: left;\">You received this email because you have enabled two factor authentication in your account.<br />Use the following code to confirm your login:</p>\r\n<p style=\"text-align: left;\"><span style=\"font-size: 18pt;\"><strong>{two_factor_auth_code}<br /><br /></strong><span style=\"font-size: 12pt;\">{email_signature}</span><strong><br /><br /><br /><br /></strong></span></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (55, 'project', 'project-finished-to-customer', 'english', 'Project Marked as Finished (Sent to Customer Contacts)', 'Project Marked as Finished', '<p>Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}</p>\r\n<p>You are receiving this email because project&nbsp;<strong>{project_name}</strong> has been marked as finished. This project is assigned under your company and we just wanted to keep you up to date.<br /><br />You can view the project on the following link:&nbsp;<a href=\"{project_link}\">{project_name}</a></p>\r\n<p>If you have any questions don\'t hesitate to contact us.<br /><br />Kind Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (56, 'credit_note', 'credit-note-send-to-client', 'english', 'Send Credit Note To Email', 'Credit Note With Number #{credit_note_number} Created', 'Dear&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have attached the credit note with number <strong>#{credit_note_number} </strong>for your reference.<br /><br /><strong>Date:</strong>&nbsp;{credit_note_date}<br /><strong>Total Amount:</strong>&nbsp;{credit_note_total}<br /><br /><span style=\"font-size: 12pt;\">Please contact us for more information.</span><br /> <br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (57, 'tasks', 'task-status-change-to-staff', 'english', 'Task Status Changed (Sent to Staff)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {staff_firstname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (58, 'tasks', 'task-status-change-to-contacts', 'english', 'Task Status Changed (Sent to Customer Contacts)', 'Task Status Changed', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}</span><br /><br /><span style=\"font-size: 12pt;\"><strong>{task_user_take_action}</strong> marked task as <strong>{task_status}</strong></span><br /><br /><span style=\"font-size: 12pt;\"><strong>Name:</strong> {task_name}</span><br /><span style=\"font-size: 12pt;\"><strong>Due date:</strong> {task_duedate}</span><br /><br /><span style=\"font-size: 12pt;\">You can view the task on the following link: <a href=\"{task_link}\">{task_name}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (59, 'staff', 'reminder-email-staff', 'english', 'Staff Reminder Email', 'You Have a New Reminder!', '<p>Hello&nbsp;{staff_firstname}<br /><br /><strong>You have a new reminder&nbsp;linked to&nbsp;{staff_reminder_relation_name}!<br /><br />Reminder description:</strong><br />{staff_reminder_description}<br /><br />Click <a href=\"{staff_reminder_relation_link}\">here</a> to view&nbsp;<a href=\"{staff_reminder_relation_link}\">{staff_reminder_relation_name}</a><br /><br />Best Regards<br /><br /></p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (60, 'contract', 'contract-comment-to-client', 'english', 'New Comment  (Sent to Customer Contacts)', 'New Contract Comment', 'Dear {contact_firstname} {contact_lastname}<br /> <br />A new comment has been made on the following contract: <strong>{contract_subject}</strong><br /> <br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a><br /> <br />Kind Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (61, 'contract', 'contract-comment-to-admin', 'english', 'New Comment (Sent to Staff) ', 'New Contract Comment', 'Hi {staff_firstname}<br /><br />A new comment has been made to the contract&nbsp;<strong>{contract_subject}</strong><br /><br />You can view and reply to the comment on the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (62, 'subscriptions', 'send-subscription', 'english', 'Send Subscription to Customer', 'Subscription Created', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />We have prepared the subscription&nbsp;<strong>{subscription_name}</strong> for your company.<br /><br />Click <a href=\"{subscription_link}\">here</a> to review the subscription and subscribe.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (63, 'subscriptions', 'subscription-payment-failed', 'english', 'Subscription Payment Failed', 'Your most recent invoice payment failed', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br br=\"\" />Unfortunately, your most recent invoice payment for&nbsp;<strong>{subscription_name}</strong> was declined.<br /><br />This could be due to a change in your card number, your card expiring,<br />cancellation of your credit card, or the card issuer not recognizing the<br />payment and therefore taking action to prevent it.<br /><br />Please update your payment information as soon as possible by logging in here:<br /><a href=\"{crm_url}/login\">{crm_url}/login</a><br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (64, 'subscriptions', 'subscription-canceled', 'english', 'Subscription Canceled (Sent to customer primary contact)', 'Your subscription has been canceled', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />Your subscription&nbsp;<strong>{subscription_name} </strong>has been canceled, if you have any questions don\'t hesitate to contact us.<br /><br />It was a pleasure doing business with you.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (65, 'subscriptions', 'subscription-payment-succeeded', 'english', 'Subscription Payment Succeeded (Sent to customer primary contact)', 'Subscription  Payment Receipt - {subscription_name}', 'Hello&nbsp;{contact_firstname}&nbsp;{contact_lastname}<br /><br />This email is to let you know that we received your payment for subscription&nbsp;<strong>{subscription_name}&nbsp;</strong>of&nbsp;<strong><span>{payment_total}<br /><br /></span></strong>The invoice associated with it is now with status&nbsp;<strong>{invoice_status}<br /></strong><br />Thank you for your confidence.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (66, 'contract', 'contract-expiration-to-staff', 'english', 'Contract Expiration Reminder (Sent to Staff)', 'Contract Expiration Reminder', 'Hi {staff_firstname}<br /><br /><span style=\"font-size: 12pt;\">This is a reminder that the following contract will expire soon:</span><br /><br /><span style=\"font-size: 12pt;\"><strong>Subject:</strong> {contract_subject}</span><br /><span style=\"font-size: 12pt;\"><strong>Description:</strong> {contract_description}</span><br /><span style=\"font-size: 12pt;\"><strong>Date Start:</strong> {contract_datestart}</span><br /><span style=\"font-size: 12pt;\"><strong>Date End:</strong> {contract_dateend}</span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (67, 'gdpr', 'gdpr-removal-request', 'english', 'Removal Request From Contact (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by&nbsp;{contact_firstname} {contact_lastname}<br /><br />You can review this request and take proper actions directly from the admin area.', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (68, 'gdpr', 'gdpr-removal-request-lead', 'english', 'Removal Request From Lead (Sent to administrators)', 'Data Removal Request Received', 'Hello&nbsp;{staff_firstname}&nbsp;{staff_lastname}<br /><br />Data removal has been requested by {lead_name}<br /><br />You can review this request and take proper actions directly from the admin area.<br /><br />To view the lead inside the admin area click here:&nbsp;<a href=\"{lead_link}\">{lead_link}</a>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (69, 'client', 'client-registration-confirmed', 'english', 'Customer Registration Confirmed', 'Your registration is confirmed', '<p>Dear {contact_firstname} {contact_lastname}<br /><br />We just wanted to let you know that your registration at&nbsp;{companyname} is successfully confirmed and your account is now active.<br /><br />You can login at&nbsp;<a href=\"{crm_url}\">{crm_url}</a> with the email and password you provided during registration.<br /><br />Please contact us if you need any help.<br /><br />Kind Regards, <br />{email_signature}</p>\r\n<p><br />(This is an automated email, so please don\'t reply to this email address)</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (70, 'contract', 'contract-signed-to-staff', 'english', 'Contract Signed (Sent to Staff)', 'Customer Signed a Contract', 'Hi {staff_firstname}<br /><br />A contract with subject&nbsp;<strong>{contract_subject} </strong>has been successfully signed by the customer.<br /><br />You can view the contract at the following link: <a href=\"{contract_link}\">{contract_subject}</a>&nbsp;or from the admin area.<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (71, 'subscriptions', 'customer-subscribed-to-staff', 'english', 'Customer Subscribed to a Subscription (Sent to administrators and subscription creator)', 'Customer Subscribed to a Subscription', 'The customer <strong>{client_company}</strong> subscribed to a subscription with name&nbsp;<strong>{subscription_name}</strong><br /><br /><strong>ID</strong>:&nbsp;{subscription_id}<br /><strong>Subscription name</strong>:&nbsp;{subscription_name}<br /><strong>Subscription description</strong>:&nbsp;{subscription_description}<br /><br />You can view the subscription by clicking <a href=\"{subscription_link}\">here</a><br />\r\n<div style=\"text-align: center;\"><span style=\"font-size: 10pt;\">&nbsp;</span></div>\r\nBest Regards,<br />{email_signature}<br /><br /><span style=\"font-size: 10pt;\"><span style=\"color: #999999;\">You are receiving this email because you are either administrator or you are creator of the subscription.</span></span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (72, 'client', 'contact-verification-email', 'english', 'Email Verification (Sent to Contact After Registration)', 'Verify Email Address', '<p>Hello&nbsp;{contact_firstname}<br /><br />Please click the button below to verify your email address.<br /><br /><a href=\"{email_verification_url}\">Verify Email Address</a><br /><br />If you did not create an account, no further action is required</p>\r\n<p><br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (73, 'client', 'new-customer-profile-file-uploaded-to-staff', 'english', 'New Customer Profile File(s) Uploaded (Sent to Staff)', 'Customer Uploaded New File(s) in Profile', 'Hi!<br /><br />New file(s) is uploaded into the customer ({client_company}) profile by&nbsp;{contact_firstname}<br /><br />You can check the uploaded files into the admin area by clicking <a href=\"{customer_profile_files_admin_link}\">here</a> or at the following link:&nbsp;{customer_profile_files_admin_link}<br /><br />{email_signature}', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (74, 'staff', 'event-notification-to-staff', 'english', 'Event Notification (Calendar)', 'Upcoming Event - {event_title}', 'Hi {staff_firstname}! <br /><br />This is a reminder for event <a href=\\\"{event_link}\\\">{event_title}</a> scheduled at {event_start_date}. <br /><br />Regards.', '', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (75, 'subscriptions', 'subscription-payment-requires-action', 'english', 'Credit Card Authorization Required - SCA', 'Important: Confirm your subscription {subscription_name} payment', '<p>Hello {contact_firstname}</p>\r\n<p><strong>Your bank sometimes requires an additional step to make sure an online transaction was authorized.</strong><br /><br />Because of European regulation to protect consumers, many online payments now require two-factor authentication. Your bank ultimately decides when authentication is required to confirm a payment, but you may notice this step when you start paying for a service or when the cost changes.<br /><br />In order to pay the subscription <strong>{subscription_name}</strong>, you will need to&nbsp;confirm your payment by clicking on the follow link: <strong><a href=\"{subscription_authorize_payment_link}\">{subscription_authorize_payment_link}</a></strong><br /><br />To view the subscription, please click at the following link: <a href=\"{subscription_link}\"><span>{subscription_link}</span></a><br />or you can login in our dedicated area here: <a href=\"{crm_url}/login\">{crm_url}/login</a> in case you want to update your credit card or view the subscriptions you are subscribed.<br /><br />Best Regards,<br />{email_signature}</p>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (76, 'invoice', 'invoice-due-notice', 'english', 'Invoice Due Notice', 'Your {invoice_number} will be due soon', '<span style=\"font-size: 12pt;\">Hi {contact_firstname} {contact_lastname}<br /><br /></span>You invoice <span style=\"font-size: 12pt;\"><strong># {invoice_number} </strong>will be due on <strong>{invoice_duedate}</strong></span><br /><br /><span style=\"font-size: 12pt;\">You can view the invoice on the following link: <a href=\"{invoice_link}\">{invoice_number}</a></span><br /><br /><span style=\"font-size: 12pt;\">Kind Regards,</span><br /><span style=\"font-size: 12pt;\">{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (77, 'estimate_request', 'estimate-request-submitted-to-staff', 'english', 'Estimate Request Submitted (Sent to Staff)', 'New Estimate Request Submitted', '<span> Hello,&nbsp;</span><br /><br />{estimate_request_email} submitted an estimate request via the {estimate_request_form_name} form.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />==<br /><br />{estimate_request_submitted_data}<br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (78, 'estimate_request', 'estimate-request-assigned', 'english', 'Estimate Request Assigned (Sent to Staff)', 'New Estimate Request Assigned', '<span> Hello {estimate_request_assigned},&nbsp;</span><br /><br />Estimate request #{estimate_request_id} has been assigned to you.<br /><br />You can view the request at the following link: <a href=\"{estimate_request_link}\">{estimate_request_link}</a><br /><br />Kind Regards,<br /><span>{email_signature}</span>', '{companyname} | CRM', '', 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (79, 'estimate_request', 'estimate-request-received-to-user', 'english', 'Estimate Request Received (Sent to User)', 'Estimate Request Received', 'Hello,<br /><br /><strong>Your request has been received.</strong><br /><br />This email is to let you know that we received your request and we will get back to you as soon as possible with more information.<br /><br />Best Regards,<br />{email_signature}', '{companyname} | CRM', '', 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (80, 'client', 'new-client-created', 'french', 'New Contact Added/Registered (Welcome Email) [french]', 'Welcome aboard', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (81, 'invoice', 'invoice-send-to-client', 'french', 'Send Invoice to Customer [french]', 'Invoice with number {invoice_number} created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (82, 'ticket', 'new-ticket-opened-admin', 'french', 'New Ticket Opened (Opened by Staff, Sent to Customer) [french]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (83, 'ticket', 'ticket-reply', 'french', 'Ticket Reply (Sent to Customer) [french]', 'New Ticket Reply', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (84, 'ticket', 'ticket-autoresponse', 'french', 'New Ticket Opened - Autoresponse [french]', 'New Support Ticket Opened', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (85, 'invoice', 'invoice-payment-recorded', 'french', 'Invoice Payment Recorded (Sent to Customer) [french]', 'Invoice Payment Recorded', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (86, 'invoice', 'invoice-overdue-notice', 'french', 'Invoice Overdue Notice [french]', 'Invoice Overdue Notice - {invoice_number}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (87, 'invoice', 'invoice-already-send', 'french', 'Invoice Already Sent to Customer [french]', 'Invoice # {invoice_number} ', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (88, 'ticket', 'new-ticket-created-staff', 'french', 'New Ticket Created (Opened by Customer, Sent to Staff Members) [french]', 'New Ticket Created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (89, 'estimate', 'estimate-send-to-client', 'french', 'Send Estimate to Customer [french]', 'Estimate # {estimate_number} created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (90, 'ticket', 'ticket-reply-to-admin', 'french', 'Ticket Reply (Sent to Staff) [french]', 'New Support Ticket Reply', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (91, 'estimate', 'estimate-already-send', 'french', 'Estimate Already Sent to Customer [french]', 'Estimate # {estimate_number} ', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (92, 'contract', 'contract-expiration', 'french', 'Contract Expiration Reminder (Sent to Customer Contacts) [french]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (93, 'tasks', 'task-assigned', 'french', 'New Task Assigned (Sent to Staff) [french]', 'New Task Assigned to You - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (94, 'tasks', 'task-added-as-follower', 'french', 'Staff Member Added as Follower on Task (Sent to Staff) [french]', 'You are added as follower on task - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (95, 'tasks', 'task-commented', 'french', 'New Comment on Task (Sent to Staff) [french]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (96, 'tasks', 'task-added-attachment', 'french', 'New Attachment(s) on Task (Sent to Staff) [french]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (97, 'estimate', 'estimate-declined-to-staff', 'french', 'Estimate Declined (Sent to Staff) [french]', 'Customer Declined Estimate', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (98, 'estimate', 'estimate-accepted-to-staff', 'french', 'Estimate Accepted (Sent to Staff) [french]', 'Customer Accepted Estimate', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (99, 'proposals', 'proposal-client-accepted', 'french', 'Customer Action - Accepted (Sent to Staff) [french]', 'Customer Accepted Proposal', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (100, 'proposals', 'proposal-send-to-customer', 'french', 'Send Proposal to Customer [french]', 'Proposal With Number {proposal_number} Created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (101, 'proposals', 'proposal-client-declined', 'french', 'Customer Action - Declined (Sent to Staff) [french]', 'Client Declined Proposal', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (102, 'proposals', 'proposal-client-thank-you', 'french', 'Thank You Email (Sent to Customer After Accept) [french]', 'Thank for you accepting proposal', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (103, 'proposals', 'proposal-comment-to-client', 'french', 'New Comment  (Sent to Customer/Lead) [french]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (104, 'proposals', 'proposal-comment-to-admin', 'french', 'New Comment (Sent to Staff)  [french]', 'New Proposal Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (105, 'estimate', 'estimate-thank-you-to-customer', 'french', 'Thank You Email (Sent to Customer After Accept) [french]', 'Thank for you accepting estimate', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (106, 'tasks', 'task-deadline-notification', 'french', 'Task Deadline Reminder - Sent to Assigned Members [french]', 'Task Deadline Reminder', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (107, 'contract', 'send-contract', 'french', 'Send Contract to Customer [french]', 'Contract - {contract_subject}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (108, 'invoice', 'invoice-payment-recorded-to-staff', 'french', 'Invoice Payment Recorded (Sent to Staff) [french]', 'New Invoice Payment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (109, 'ticket', 'auto-close-ticket', 'french', 'Auto Close Ticket [french]', 'Ticket Auto Closed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (110, 'project', 'new-project-discussion-created-to-staff', 'french', 'New Project Discussion (Sent to Project Members) [french]', 'New Project Discussion Created - {project_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (111, 'project', 'new-project-discussion-created-to-customer', 'french', 'New Project Discussion (Sent to Customer Contacts) [french]', 'New Project Discussion Created - {project_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (112, 'project', 'new-project-file-uploaded-to-customer', 'french', 'New Project File(s) Uploaded (Sent to Customer Contacts) [french]', 'New Project File(s) Uploaded - {project_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (113, 'project', 'new-project-file-uploaded-to-staff', 'french', 'New Project File(s) Uploaded (Sent to Project Members) [french]', 'New Project File(s) Uploaded - {project_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (114, 'project', 'new-project-discussion-comment-to-customer', 'french', 'New Discussion Comment  (Sent to Customer Contacts) [french]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (115, 'project', 'new-project-discussion-comment-to-staff', 'french', 'New Discussion Comment (Sent to Project Members) [french]', 'New Discussion Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (116, 'project', 'staff-added-as-project-member', 'french', 'Staff Added as Project Member [french]', 'New project assigned to you', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (117, 'estimate', 'estimate-expiry-reminder', 'french', 'Estimate Expiration Reminder [french]', 'Estimate Expiration Reminder', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (118, 'proposals', 'proposal-expiry-reminder', 'french', 'Proposal Expiration Reminder [french]', 'Proposal Expiration Reminder', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (119, 'staff', 'new-staff-created', 'french', 'New Staff Created (Welcome Email) [french]', 'You are added as staff member', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (120, 'client', 'contact-forgot-password', 'french', 'Forgot Password [french]', 'Create New Password', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (121, 'client', 'contact-password-reseted', 'french', 'Password Reset - Confirmation [french]', 'Your password has been changed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (122, 'client', 'contact-set-password', 'french', 'Set New Password [french]', 'Set new password on {companyname} ', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (123, 'staff', 'staff-forgot-password', 'french', 'Forgot Password [french]', 'Create New Password', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (124, 'staff', 'staff-password-reseted', 'french', 'Password Reset - Confirmation [french]', 'Your password has been changed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (125, 'project', 'assigned-to-project', 'french', 'New Project Created (Sent to Customer Contacts) [french]', 'New Project Created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (126, 'tasks', 'task-added-attachment-to-contacts', 'french', 'New Attachment(s) on Task (Sent to Customer Contacts) [french]', 'New Attachment on Task - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (127, 'tasks', 'task-commented-to-contacts', 'french', 'New Comment on Task (Sent to Customer Contacts) [french]', 'New Comment on Task - {task_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (128, 'leads', 'new-lead-assigned', 'french', 'New Lead Assigned to Staff Member [french]', 'New lead assigned to you', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (129, 'client', 'client-statement', 'french', 'Statement - Account Summary [french]', 'Account Statement from {statement_from} to {statement_to}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (130, 'ticket', 'ticket-assigned-to-admin', 'french', 'New Ticket Assigned (Sent to Staff) [french]', 'New support ticket has been assigned to you', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (131, 'client', 'new-client-registered-to-admin', 'french', 'New Customer Registration (Sent to admins) [french]', 'New Customer Registration', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (132, 'leads', 'new-web-to-lead-form-submitted', 'french', 'Web to lead form submitted - Sent to lead [french]', '{lead_name} - We Received Your Request', '', '{companyname} | CRM', NULL, 0, 0, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (133, 'staff', 'two-factor-authentication', 'french', 'Two Factor Authentication [french]', 'Confirm Your Login', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (134, 'project', 'project-finished-to-customer', 'french', 'Project Marked as Finished (Sent to Customer Contacts) [french]', 'Project Marked as Finished', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (135, 'credit_note', 'credit-note-send-to-client', 'french', 'Send Credit Note To Email [french]', 'Credit Note With Number #{credit_note_number} Created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (136, 'tasks', 'task-status-change-to-staff', 'french', 'Task Status Changed (Sent to Staff) [french]', 'Task Status Changed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (137, 'tasks', 'task-status-change-to-contacts', 'french', 'Task Status Changed (Sent to Customer Contacts) [french]', 'Task Status Changed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (138, 'staff', 'reminder-email-staff', 'french', 'Staff Reminder Email [french]', 'You Have a New Reminder!', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (139, 'contract', 'contract-comment-to-client', 'french', 'New Comment  (Sent to Customer Contacts) [french]', 'New Contract Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (140, 'contract', 'contract-comment-to-admin', 'french', 'New Comment (Sent to Staff)  [french]', 'New Contract Comment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (141, 'subscriptions', 'send-subscription', 'french', 'Send Subscription to Customer [french]', 'Subscription Created', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (142, 'subscriptions', 'subscription-payment-failed', 'french', 'Subscription Payment Failed [french]', 'Your most recent invoice payment failed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (143, 'subscriptions', 'subscription-canceled', 'french', 'Subscription Canceled (Sent to customer primary contact) [french]', 'Your subscription has been canceled', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (144, 'subscriptions', 'subscription-payment-succeeded', 'french', 'Subscription Payment Succeeded (Sent to customer primary contact) [french]', 'Subscription  Payment Receipt - {subscription_name}', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (145, 'contract', 'contract-expiration-to-staff', 'french', 'Contract Expiration Reminder (Sent to Staff) [french]', 'Contract Expiration Reminder', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (146, 'gdpr', 'gdpr-removal-request', 'french', 'Removal Request From Contact (Sent to administrators) [french]', 'Data Removal Request Received', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (147, 'gdpr', 'gdpr-removal-request-lead', 'french', 'Removal Request From Lead (Sent to administrators) [french]', 'Data Removal Request Received', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (148, 'client', 'client-registration-confirmed', 'french', 'Customer Registration Confirmed [french]', 'Your registration is confirmed', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (149, 'contract', 'contract-signed-to-staff', 'french', 'Contract Signed (Sent to Staff) [french]', 'Customer Signed a Contract', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (150, 'subscriptions', 'customer-subscribed-to-staff', 'french', 'Customer Subscribed to a Subscription (Sent to administrators and subscription creator) [french]', 'Customer Subscribed to a Subscription', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (151, 'client', 'contact-verification-email', 'french', 'Email Verification (Sent to Contact After Registration) [french]', 'Verify Email Address', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (152, 'client', 'new-customer-profile-file-uploaded-to-staff', 'french', 'New Customer Profile File(s) Uploaded (Sent to Staff) [french]', 'Customer Uploaded New File(s) in Profile', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (153, 'staff', 'event-notification-to-staff', 'french', 'Event Notification (Calendar) [french]', 'Upcoming Event - {event_title}', '', '', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (154, 'subscriptions', 'subscription-payment-requires-action', 'french', 'Credit Card Authorization Required - SCA [french]', 'Important: Confirm your subscription {subscription_name} payment', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (155, 'invoice', 'invoice-due-notice', 'french', 'Invoice Due Notice [french]', 'Your {invoice_number} will be due soon', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (156, 'estimate_request', 'estimate-request-submitted-to-staff', 'french', 'Estimate Request Submitted (Sent to Staff) [french]', 'New Estimate Request Submitted', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (157, 'estimate_request', 'estimate-request-assigned', 'french', 'Estimate Request Assigned (Sent to Staff) [french]', 'New Estimate Request Assigned', '', '{companyname} | CRM', NULL, 0, 1, 0);
INSERT INTO `tblemailtemplates` (`emailtemplateid`, `type`, `slug`, `language`, `name`, `subject`, `message`, `fromname`, `fromemail`, `plaintext`, `active`, `order`) VALUES (158, 'estimate_request', 'estimate-request-received-to-user', 'french', 'Estimate Request Received (Sent to User) [french]', 'Estimate Request Received', '', '{companyname} | CRM', NULL, 0, 0, 0);


#
# TABLE STRUCTURE FOR: tblestimate_request_forms
#

DROP TABLE IF EXISTS `tblestimate_request_forms`;

CREATE TABLE `tblestimate_request_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `type` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `submit_btn_name` varchar(100) DEFAULT NULL,
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `success_submit_msg` text DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` mediumtext DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `dateadded` datetime DEFAULT NULL,
  `notify_type` varchar(100) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) DEFAULT NULL,
  `notify_request_submitted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblestimate_request_status
#

DROP TABLE IF EXISTS `tblestimate_request_status`;

CREATE TABLE `tblestimate_request_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT NULL,
  `flag` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (1, 'Cancelled', 1, '#808080', 'cancelled');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (2, 'Processing', 2, '#007bff', 'processing');
INSERT INTO `tblestimate_request_status` (`id`, `name`, `statusorder`, `color`, `flag`) VALUES (3, 'Completed', 3, '#28a745', 'completed');


#
# TABLE STRUCTURE FOR: tblestimate_requests
#

DROP TABLE IF EXISTS `tblestimate_requests`;

CREATE TABLE `tblestimate_requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `submission` longtext NOT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `date_estimated` datetime DEFAULT NULL,
  `from_form_id` int(11) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `default_language` int(11) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblestimates
#

DROP TABLE IF EXISTS `tblestimates`;

CREATE TABLE `tblestimates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) DEFAULT NULL,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `expirydate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `clientnote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) DEFAULT NULL,
  `invoiceid` int(11) DEFAULT NULL,
  `invoiced_date` datetime DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_estimate` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (1, 1, '2021-11-24 17:23:05', 4, NULL, 0, 1, 'EST-', 1, 'd0a937d443e932e25cede4f998c4b68f', '2021-11-24 15:34:50', '2021-11-24', '2021-12-01', 1, '15.00', '0.00', '15.00', '0.00', 12, 2, '', '', '0.00', '0.00', '', NULL, NULL, '', '', 0, 'rgqregrgq', 'efaf', 'fejhkjeaf', '89879897', 6, '', '', '', '', NULL, 1, 1, 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (2, 1, '2021-11-24 16:07:51', 1, NULL, 0, 2, 'EST-', 1, '052c29ba8b83c69e1656b7b4230531b1', '2021-11-24 16:03:00', '2021-11-24', '2021-12-01', 1, '15.00', '0.00', '15.00', '0.00', 12, 4, 'ièèè', 'oièlriè', '0.00', '0.00', '', 1, '2021-11-24 16:14:17', 'iorrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr', 'èiuy', 12, 'zsdzaf', 'd', 'ok', '56465', 2, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 2, 0, 'ok', 'ok', 'azf@keza.mo', '2021-11-24 16:14:17', '::1', 'signature.png', NULL);
INSERT INTO `tblestimates` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `project_id`, `number`, `prefix`, `number_format`, `hash`, `datecreated`, `date`, `expirydate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `status`, `clientnote`, `adminnote`, `discount_percent`, `discount_total`, `discount_type`, `invoiceid`, `invoiced_date`, `terms`, `reference_no`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_estimate`, `show_quantity_as`, `pipeline_order`, `is_expiry_notified`, `acceptance_firstname`, `acceptance_lastname`, `acceptance_email`, `acceptance_date`, `acceptance_ip`, `signature`, `short_link`) VALUES (3, 0, NULL, 2, NULL, 0, 3, 'EST-', 1, 'bfda937383c2ac60680c4bfed31adfb9', '2021-11-25 09:49:55', '2021-11-25', '2021-12-02', 1, '15.00', '0.00', '16.70', '2.00', 1, 2, '', 'pour ce devis', '2.00', '0.30', 'after_tax', NULL, NULL, '', '454mpoj', 6, 'adress', 'ville', 'region', '4578', 76, NULL, NULL, NULL, NULL, NULL, 0, 1, 2, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tblevents
#

DROP TABLE IF EXISTS `tblevents`;

CREATE TABLE `tblevents` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `title` mediumtext NOT NULL,
  `description` text DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `public` int(11) NOT NULL DEFAULT 0,
  `color` varchar(10) DEFAULT NULL,
  `isstartnotified` tinyint(1) NOT NULL DEFAULT 0,
  `reminder_before` int(11) NOT NULL DEFAULT 0,
  `reminder_before_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses
#

DROP TABLE IF EXISTS `tblexpenses`;

CREATE TABLE `tblexpenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `currency` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) NOT NULL DEFAULT 0,
  `reference_no` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `expense_name` varchar(191) DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `billable` int(11) DEFAULT 0,
  `invoiceid` int(11) DEFAULT NULL,
  `paymentmode` varchar(50) DEFAULT NULL,
  `date` date NOT NULL,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` int(11) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `create_invoice_billable` tinyint(1) DEFAULT NULL,
  `send_invoice_to_customer` tinyint(1) NOT NULL,
  `recurring_from` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `category` (`category`),
  KEY `currency` (`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblexpenses_categories
#

DROP TABLE IF EXISTS `tblexpenses_categories`;

CREATE TABLE `tblexpenses_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblfiles
#

DROP TABLE IF EXISTS `tblfiles`;

CREATE TABLE `tblfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(40) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `attachment_key` varchar(32) DEFAULT NULL,
  `external` varchar(40) DEFAULT NULL,
  `external_link` text DEFAULT NULL,
  `thumbnail_link` text DEFAULT NULL COMMENT 'For external usage',
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `task_comment_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_question_box
#

DROP TABLE IF EXISTS `tblform_question_box`;

CREATE TABLE `tblform_question_box` (
  `boxid` int(11) NOT NULL AUTO_INCREMENT,
  `boxtype` varchar(10) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`boxid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_question_box_description
#

DROP TABLE IF EXISTS `tblform_question_box_description`;

CREATE TABLE `tblform_question_box_description` (
  `questionboxdescriptionid` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `boxid` mediumtext NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`questionboxdescriptionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_questions
#

DROP TABLE IF EXISTS `tblform_questions`;

CREATE TABLE `tblform_questions` (
  `questionid` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `question` mediumtext NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `question_order` int(11) NOT NULL,
  PRIMARY KEY (`questionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblform_results
#

DROP TABLE IF EXISTS `tblform_results`;

CREATE TABLE `tblform_results` (
  `resultid` int(11) NOT NULL AUTO_INCREMENT,
  `boxid` int(11) NOT NULL,
  `boxdescriptionid` int(11) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `answer` text DEFAULT NULL,
  `resultsetid` int(11) NOT NULL,
  PRIMARY KEY (`resultid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblgdpr_requests
#

DROP TABLE IF EXISTS `tblgdpr_requests`;

CREATE TABLE `tblgdpr_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientid` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `lead_id` int(11) NOT NULL DEFAULT 0,
  `request_type` varchar(191) DEFAULT NULL,
  `status` varchar(40) DEFAULT NULL,
  `request_date` datetime NOT NULL,
  `request_from` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblgoals
#

DROP TABLE IF EXISTS `tblgoals`;

CREATE TABLE `tblgoals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `goal_type` int(11) NOT NULL,
  `contract_type` int(11) NOT NULL DEFAULT 0,
  `achievement` int(11) NOT NULL,
  `notify_when_fail` tinyint(1) NOT NULL DEFAULT 1,
  `notify_when_achieve` tinyint(1) NOT NULL DEFAULT 1,
  `notified` int(11) NOT NULL DEFAULT 0,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoicepaymentrecords
#

DROP TABLE IF EXISTS `tblinvoicepaymentrecords`;

CREATE TABLE `tblinvoicepaymentrecords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceid` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `paymentmode` varchar(40) DEFAULT NULL,
  `paymentmethod` varchar(191) DEFAULT NULL,
  `date` date NOT NULL,
  `daterecorded` datetime NOT NULL,
  `note` text NOT NULL,
  `transactionid` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceid` (`invoiceid`),
  KEY `paymentmethod` (`paymentmethod`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblinvoices
#

DROP TABLE IF EXISTS `tblinvoices`;

CREATE TABLE `tblinvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sent` tinyint(1) NOT NULL DEFAULT 0,
  `datesend` datetime DEFAULT NULL,
  `clientid` int(11) NOT NULL,
  `deleted_customer_name` varchar(100) DEFAULT NULL,
  `number` int(11) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `number_format` int(11) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `date` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `total` decimal(15,2) NOT NULL,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `status` int(11) DEFAULT 1,
  `clientnote` text DEFAULT NULL,
  `adminnote` text DEFAULT NULL,
  `last_overdue_reminder` date DEFAULT NULL,
  `last_due_reminder` date DEFAULT NULL,
  `cancel_overdue_reminders` int(11) NOT NULL DEFAULT 0,
  `allowed_payment_modes` mediumtext DEFAULT NULL,
  `token` mediumtext DEFAULT NULL,
  `discount_percent` decimal(15,2) DEFAULT 0.00,
  `discount_total` decimal(15,2) DEFAULT 0.00,
  `discount_type` varchar(30) NOT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `last_recurring_date` date DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `sale_agent` int(11) NOT NULL DEFAULT 0,
  `billing_street` varchar(200) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(100) DEFAULT NULL,
  `billing_country` int(11) DEFAULT NULL,
  `shipping_street` varchar(200) DEFAULT NULL,
  `shipping_city` varchar(100) DEFAULT NULL,
  `shipping_state` varchar(100) DEFAULT NULL,
  `shipping_zip` varchar(100) DEFAULT NULL,
  `shipping_country` int(11) DEFAULT NULL,
  `include_shipping` tinyint(1) NOT NULL,
  `show_shipping_on_invoice` tinyint(1) NOT NULL DEFAULT 1,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) DEFAULT 0,
  `subscription_id` int(11) NOT NULL DEFAULT 0,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `currency` (`currency`),
  KEY `clientid` (`clientid`),
  KEY `project_id` (`project_id`),
  KEY `sale_agent` (`sale_agent`),
  KEY `total` (`total`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblinvoices` (`id`, `sent`, `datesend`, `clientid`, `deleted_customer_name`, `number`, `prefix`, `number_format`, `datecreated`, `date`, `duedate`, `currency`, `subtotal`, `total_tax`, `total`, `adjustment`, `addedfrom`, `hash`, `status`, `clientnote`, `adminnote`, `last_overdue_reminder`, `last_due_reminder`, `cancel_overdue_reminders`, `allowed_payment_modes`, `token`, `discount_percent`, `discount_total`, `discount_type`, `recurring`, `recurring_type`, `custom_recurring`, `cycles`, `total_cycles`, `is_recurring_from`, `last_recurring_date`, `terms`, `sale_agent`, `billing_street`, `billing_city`, `billing_state`, `billing_zip`, `billing_country`, `shipping_street`, `shipping_city`, `shipping_state`, `shipping_zip`, `shipping_country`, `include_shipping`, `show_shipping_on_invoice`, `show_quantity_as`, `project_id`, `subscription_id`, `short_link`) VALUES (1, 1, '2021-11-24 17:24:11', 1, NULL, 1, 'INV-', 1, '2021-11-24 16:14:17', '2021-11-24', '2021-12-24', 1, '15.00', '0.00', '15.00', '0.00', 12, '580b6c63aa25b055bc9ce62f70768445', 1, '', '', NULL, NULL, 0, 'a:1:{i:0;s:1:\"1\";}', NULL, '0.00', '0.00', '', 0, NULL, 0, 0, 0, NULL, NULL, '', 12, 'zsdzaf', 'd', 'ok', '56465', 2, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, NULL);


#
# TABLE STRUCTURE FOR: tblitem_tax
#

DROP TABLE IF EXISTS `tblitem_tax`;

CREATE TABLE `tblitem_tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` int(11) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  `taxname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `rel_id` (`rel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblitemable
#

DROP TABLE IF EXISTS `tblitemable`;

CREATE TABLE `tblitemable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `description` mediumtext NOT NULL,
  `long_description` mediumtext DEFAULT NULL,
  `qty` decimal(15,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `qty` (`qty`),
  KEY `rate` (`rate`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (1, 1, 'estimate', 'Assurance auto', '', '1.00', '15.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (2, 2, 'estimate', 'Assurance auto', '', '1.00', '15.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (3, 1, 'invoice', 'Assurance auto', '', '1.00', '15.00', '', 1);
INSERT INTO `tblitemable` (`id`, `rel_id`, `rel_type`, `description`, `long_description`, `qty`, `rate`, `unit`, `item_order`) VALUES (4, 3, 'estimate', 'Assurance auto', '', '1.00', '15.00', '', 1);


#
# TABLE STRUCTURE FOR: tblitems
#

DROP TABLE IF EXISTS `tblitems`;

CREATE TABLE `tblitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` mediumtext NOT NULL,
  `long_description` text DEFAULT NULL,
  `rate` decimal(15,2) NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax2` int(11) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `group_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `tax` (`tax`),
  KEY `tax2` (`tax2`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblitems` (`id`, `description`, `long_description`, `rate`, `tax`, `tax2`, `unit`, `group_id`) VALUES (1, 'Assurance auto', '', '15.00', NULL, NULL, '', 0);


#
# TABLE STRUCTURE FOR: tblitems_groups
#

DROP TABLE IF EXISTS `tblitems_groups`;

CREATE TABLE `tblitems_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowedge_base_article_feedback
#

DROP TABLE IF EXISTS `tblknowedge_base_article_feedback`;

CREATE TABLE `tblknowedge_base_article_feedback` (
  `articleanswerid` int(11) NOT NULL AUTO_INCREMENT,
  `articleid` int(11) NOT NULL,
  `answer` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`articleanswerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledge_base
#

DROP TABLE IF EXISTS `tblknowledge_base`;

CREATE TABLE `tblknowledge_base` (
  `articleid` int(11) NOT NULL AUTO_INCREMENT,
  `articlegroup` int(11) NOT NULL,
  `subject` mediumtext NOT NULL,
  `description` text NOT NULL,
  `slug` mediumtext NOT NULL,
  `active` tinyint(4) NOT NULL,
  `datecreated` datetime NOT NULL,
  `article_order` int(11) NOT NULL DEFAULT 0,
  `staff_article` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblknowledge_base_groups
#

DROP TABLE IF EXISTS `tblknowledge_base_groups`;

CREATE TABLE `tblknowledge_base_groups` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `group_slug` text DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `active` tinyint(4) NOT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `group_order` int(11) DEFAULT 0,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbllead_activity_log
#

DROP TABLE IF EXISTS `tbllead_activity_log`;

CREATE TABLE `tbllead_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leadid` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `additional_data` text DEFAULT NULL,
  `date` datetime NOT NULL,
  `staffid` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `custom_activity` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8;

INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (1, 1, 'not_lead_activity_created', '', '2021-11-17 14:20:55', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (2, 2, 'not_lead_activity_created', '', '2021-11-17 16:33:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (3, 2, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:90:\"<a href=\"http://localhost/CRM/crm/admin/profile/3\" target=\"_blank\">spervisor spervisor</a>\";}', '2021-11-17 16:33:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (4, 3, 'not_lead_activity_created', '', '2021-11-17 16:39:05', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (5, 3, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:96:\"<a href=\"http://localhost/CRM/crm/admin/profile/4\" target=\"_blank\">gestionnaire gestionnaire</a>\";}', '2021-11-17 16:39:05', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (6, 4, 'not_lead_activity_created', '', '2021-11-17 16:44:01', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (7, 5, 'not_lead_activity_created', '', '2021-11-17 16:58:35', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (8, 16, 'not_lead_activity_created', '', '2021-11-18 09:58:57', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (9, 17, 'not_lead_activity_created', '', '2021-11-18 10:00:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (10, 18, 'not_lead_activity_created', '', '2021-11-18 10:05:06', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (11, 19, 'not_lead_activity_created', '', '2021-11-18 10:10:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (12, 20, 'not_lead_activity_created', '', '2021-11-18 10:41:56', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (13, 20, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:96:\"<a href=\"http://localhost/CRM/crm/admin/profile/4\" target=\"_blank\">gestionnaire gestionnaire</a>\";}', '2021-11-18 10:41:56', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (14, 21, 'not_lead_activity_created', '', '2021-11-18 10:51:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (15, 22, 'not_lead_activity_created', '', '2021-11-18 10:54:45', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (16, 23, 'not_lead_activity_created', '', '2021-11-18 11:08:56', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (17, 24, 'not_lead_activity_created', '', '2021-11-18 13:24:33', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (18, 25, 'not_lead_activity_created', '', '2021-11-18 13:28:00', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (19, 26, 'not_lead_activity_created', '', '2021-11-18 13:33:10', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (20, 27, 'not_lead_activity_created', '', '2021-11-18 13:54:25', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (21, 28, 'not_lead_activity_created', '', '2021-11-18 13:59:38', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (22, 29, 'not_lead_activity_created', '', '2021-11-18 14:00:22', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (23, 30, 'not_lead_activity_created', '', '2021-11-18 14:14:14', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (24, 31, 'not_lead_activity_created', '', '2021-11-18 14:16:38', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (25, 32, 'not_lead_activity_created', '', '2021-11-18 14:23:21', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (26, 33, 'not_lead_activity_created', '', '2021-11-18 14:31:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (27, 34, 'not_lead_activity_created', '', '2021-11-18 14:33:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (28, 35, 'not_lead_activity_created', '', '2021-11-18 14:34:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (29, 36, 'not_lead_activity_created', '', '2021-11-18 14:36:33', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (30, 37, 'not_lead_activity_created', '', '2021-11-18 14:37:19', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (31, 38, 'not_lead_activity_created', '', '2021-11-18 14:39:07', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (32, 39, 'not_lead_activity_created', '', '2021-11-18 14:42:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (33, 40, 'not_lead_activity_created', '', '2021-11-18 14:43:46', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (34, 41, 'not_lead_activity_created', '', '2021-11-18 14:46:24', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (35, 42, 'not_lead_activity_created', '', '2021-11-18 14:49:42', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (36, 43, 'not_lead_activity_created', '', '2021-11-18 15:16:52', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (37, 44, 'not_lead_activity_created', '', '2021-11-18 15:19:43', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (38, 47, 'not_lead_activity_created', '', '2021-11-19 08:36:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (39, 50, 'not_lead_activity_created', '', '2021-11-19 08:38:17', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (40, 51, 'not_lead_activity_created', '', '2021-11-19 08:40:15', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (41, 52, 'not_lead_activity_created', '', '2021-11-19 08:42:54', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (42, 53, 'not_lead_activity_created', '', '2021-11-19 08:47:33', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (43, 54, 'not_lead_activity_created', '', '2021-11-19 08:48:33', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (44, 55, 'not_lead_activity_created', '', '2021-11-19 08:51:44', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (45, 56, 'not_lead_activity_created', '', '2021-11-19 08:53:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (46, 56, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:14:\"Nouvelle Fiche\";i:2;s:10:\"Hors Cible\";}', '2021-11-19 11:24:18', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (47, 55, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:14:\"Nouvelle Fiche\";i:2;s:7:\"Doublon\";}', '2021-11-19 11:24:27', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (48, 54, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:14:\"Nouvelle Fiche\";i:2;s:11:\"Trop Chére\";}', '2021-11-19 11:24:34', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (49, 54, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:11:\"Trop Chére\";i:2;s:9:\"Exclusion\";}', '2021-11-22 10:33:36', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (50, 55, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:7:\"Doublon\";i:2;s:12:\"Fausse Fiche\";}', '2021-11-22 10:33:42', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (51, 56, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:10:\"Hors Cible\";i:2;s:14:\"déja souscris\";}', '2021-11-22 10:33:44', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (52, 58, 'not_lead_activity_created', '', '2021-11-22 13:27:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (53, 60, 'not_lead_activity_created', '', '2021-11-22 13:27:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (54, 62, 'not_lead_activity_created', '', '2021-11-22 13:27:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (55, 64, 'not_lead_activity_created', '', '2021-11-22 13:27:13', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (56, 66, 'not_lead_activity_created', '', '2021-11-22 13:27:13', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (57, 68, 'not_lead_activity_created', '', '2021-11-22 13:27:13', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (58, 70, 'not_lead_activity_created', '', '2021-11-22 13:27:14', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (59, 72, 'not_lead_activity_created', '', '2021-11-22 13:27:26', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (60, 74, 'not_lead_activity_created', '', '2021-11-22 13:27:28', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (61, 76, 'not_lead_activity_created', '', '2021-11-22 13:27:28', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (62, 78, 'not_lead_activity_created', '', '2021-11-22 13:27:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (63, 80, 'not_lead_activity_created', '', '2021-11-22 13:27:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (64, 82, 'not_lead_activity_created', '', '2021-11-22 13:27:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (65, 84, 'not_lead_activity_created', '', '2021-11-22 13:27:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (66, 86, 'not_lead_activity_created', '', '2021-11-22 13:27:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (67, 88, 'not_lead_activity_created', '', '2021-11-22 13:27:31', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (68, 90, 'not_lead_activity_created', '', '2021-11-22 13:27:57', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (69, 91, 'not_lead_activity_created', '', '2021-11-22 13:30:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (70, 92, 'not_lead_activity_created', '', '2021-11-22 13:31:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (71, 93, 'not_lead_activity_created', '', '2021-11-22 13:33:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (72, 94, 'not_lead_activity_created', '', '2021-11-22 14:09:15', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (73, 91, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:14:\"déja souscris\";i:2;s:12:\"Fausse Fiche\";}', '2021-11-22 14:19:34', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (74, 88, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:14:\"déja souscris\";i:2;s:9:\"Exclusion\";}', '2021-11-22 14:21:00', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (75, 95, 'not_lead_activity_created', '', '2021-11-22 14:30:50', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (76, 96, 'not_lead_activity_created', '', '2021-11-22 14:32:35', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (77, 97, 'not_lead_activity_created', '', '2021-11-22 14:33:17', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (78, 98, 'not_lead_activity_created', '', '2021-11-22 14:33:50', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (79, 99, 'not_lead_activity_created', '', '2021-11-22 14:38:54', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (80, 100, 'not_lead_activity_created', '', '2021-11-22 14:39:42', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (81, 101, 'not_lead_activity_created', '', '2021-11-22 14:40:25', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (82, 102, 'not_lead_activity_created', '', '2021-11-22 14:41:57', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (83, 103, 'not_lead_activity_created', '', '2021-11-22 14:42:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (84, 104, 'not_lead_activity_created', '', '2021-11-22 15:11:48', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (85, 104, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:90:\"<a href=\"http://localhost/CRM/crm/admin/profile/3\" target=\"_blank\">spervisor spervisor</a>\";}', '2021-11-22 15:11:48', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (86, 105, 'not_lead_activity_created', '', '2021-11-22 15:12:41', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (87, 106, 'not_lead_activity_created', '', '2021-11-22 16:45:57', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (88, 107, 'not_lead_activity_created', '', '2021-11-22 17:00:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (89, 108, 'not_lead_activity_created', '', '2021-11-22 17:01:31', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (90, 109, 'not_lead_activity_created', '', '2021-11-22 17:02:53', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (91, 110, 'not_lead_activity_created', '', '2021-11-22 17:15:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (92, 111, 'not_lead_activity_created', '', '2021-11-22 17:16:24', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (93, 112, 'not_lead_activity_created', '', '2021-11-23 08:08:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (94, 113, 'not_lead_activity_created', '', '2021-11-23 08:09:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (95, 114, 'not_lead_activity_created', '', '2021-11-23 08:10:28', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (96, 115, 'not_lead_activity_created', '', '2021-11-23 08:12:58', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (97, 116, 'not_lead_activity_created', '', '2021-11-23 08:21:48', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (98, 113, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:12:\"Fausse Fiche\";i:2;s:14:\"Nouvelle Fiche\";}', '2021-11-23 08:23:17', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (99, 117, 'not_lead_activity_created', '', '2021-11-23 08:27:31', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (100, 118, 'not_lead_activity_created', '', '2021-11-23 09:48:00', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (101, 119, 'not_lead_activity_created', '', '2021-11-23 10:18:46', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (102, 120, 'not_lead_activity_created', '', '2021-11-23 10:21:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (103, 121, 'not_lead_activity_created', '', '2021-11-23 10:23:28', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (104, 122, 'not_lead_activity_created', '', '2021-11-23 10:26:37', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (105, 123, 'not_lead_activity_created', '', '2021-11-23 10:33:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (106, 124, 'not_lead_activity_created', '', '2021-11-23 10:34:25', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (107, 125, 'not_lead_activity_created', '', '2021-11-23 10:46:23', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (108, 126, 'not_lead_activity_created', '', '2021-11-23 10:47:41', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (109, 127, 'not_lead_activity_created', '', '2021-11-23 10:49:07', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (110, 128, 'not_lead_activity_created', '', '2021-11-23 10:51:04', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (111, 129, 'not_lead_activity_created', '', '2021-11-23 10:57:14', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (112, 130, 'not_lead_activity_created', '', '2021-11-23 10:57:47', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (113, 131, 'not_lead_activity_created', '', '2021-11-23 11:21:03', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (114, 132, 'not_lead_activity_created', '', '2021-11-23 11:21:43', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (115, 133, 'not_lead_activity_created', '', '2021-11-23 11:25:00', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (116, 134, 'not_lead_activity_created', '', '2021-11-23 11:26:05', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (117, 135, 'not_lead_activity_created', '', '2021-11-23 11:27:27', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (118, 136, 'not_lead_activity_created', '', '2021-11-23 11:28:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (119, 137, 'not_lead_activity_created', '', '2021-11-23 11:28:46', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (120, 138, 'not_lead_activity_created', '', '2021-11-23 11:43:27', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (121, 139, 'not_lead_activity_created', '', '2021-11-23 11:45:05', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (122, 140, 'not_lead_activity_created', '', '2021-11-23 15:12:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (123, 141, 'not_lead_activity_created', '', '2021-11-23 15:13:32', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (124, 141, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-23 15:14:46', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (125, 139, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:13:\"Nouvelle Fich\";i:2;s:6:\"Client\";}', '2021-11-23 16:49:03', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (126, 138, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:13:\"Nouvelle Fich\";i:2;s:6:\"Client\";}', '2021-11-23 16:49:06', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (127, 142, 'not_lead_activity_created', '', '2021-11-23 17:37:46', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (128, 142, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:21:\"conseiller conseiller\";i:1;s:91:\"<a href=\"http://localhost/CRM/crm/admin/profile/1\" target=\"_blank\">Houssameddin chammaa</a>\";}', '2021-11-23 17:37:46', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (129, 143, 'not_lead_activity_created', '', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (130, 143, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:21:\"conseiller conseiller\";i:1;s:91:\"<a href=\"http://localhost/CRM/crm/admin/profile/1\" target=\"_blank\">Houssameddin chammaa</a>\";}', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (131, 144, 'not_lead_activity_created', '', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (132, 144, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:21:\"conseiller conseiller\";i:1;s:91:\"<a href=\"http://localhost/CRM/crm/admin/profile/1\" target=\"_blank\">Houssameddin chammaa</a>\";}', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (133, 145, 'not_lead_activity_created', '', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (134, 145, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:21:\"conseiller conseiller\";i:1;s:91:\"<a href=\"http://localhost/CRM/crm/admin/profile/1\" target=\"_blank\">Houssameddin chammaa</a>\";}', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (135, 146, 'not_lead_activity_created', '', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (136, 146, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:21:\"conseiller conseiller\";i:1;s:91:\"<a href=\"http://localhost/CRM/crm/admin/profile/1\" target=\"_blank\">Houssameddin chammaa</a>\";}', '2021-11-23 17:38:03', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (137, 147, 'not_lead_activity_created', '', '2021-11-23 17:38:37', 2, 'conseiller conseiller', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (138, 148, 'not_lead_activity_created', '', '2021-11-24 09:13:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (139, 148, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 09:14:15', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (140, 149, 'not_lead_activity_created', '', '2021-11-24 09:27:00', 6, 'responsable resonsable', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (141, 149, 'not_lead_activity_converted', 'a:1:{i:0;s:22:\"responsable resonsable\";}', '2021-11-24 09:27:23', 6, 'responsable resonsable', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (142, 143, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 09:36:22', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (143, 150, 'not_lead_activity_created', '', '2021-11-24 09:44:31', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (144, 151, 'not_lead_activity_created', '', '2021-11-24 09:45:53', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (145, 152, 'not_lead_activity_created', '', '2021-11-24 09:47:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (146, 153, 'not_lead_activity_created', '', '2021-11-24 09:48:21', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (147, 154, 'not_lead_activity_created', '', '2021-11-24 09:54:34', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (148, 155, 'not_lead_activity_created', '', '2021-11-24 10:06:30', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (149, 126, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:7:\"Doublon\";i:2;s:9:\"Exclusion\";}', '2021-11-24 10:07:42', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (150, 128, 'not_lead_activity_status_updated', 'a:3:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:23:\"N\'a pas fait de demande\";i:2;s:9:\"Exclusion\";}', '2021-11-24 10:07:47', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (151, 156, 'not_lead_activity_created', '', '2021-11-24 15:19:27', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (152, 156, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:27', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (153, 157, 'not_lead_activity_created', '', '2021-11-24 15:19:36', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (154, 157, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:36', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (155, 158, 'not_lead_activity_created', '', '2021-11-24 15:19:36', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (156, 158, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:36', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (157, 159, 'not_lead_activity_created', '', '2021-11-24 15:19:37', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (158, 159, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:37', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (159, 160, 'not_lead_activity_created', '', '2021-11-24 15:19:39', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (160, 160, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (161, 161, 'not_lead_activity_created', '', '2021-11-24 15:19:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (162, 161, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (163, 162, 'not_lead_activity_created', '', '2021-11-24 15:19:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (164, 162, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (165, 163, 'not_lead_activity_created', '', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (166, 163, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (167, 164, 'not_lead_activity_created', '', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (168, 164, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (169, 165, 'not_lead_activity_created', '', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (170, 165, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (171, 166, 'not_lead_activity_created', '', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (172, 166, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:19:51', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (173, 167, 'not_lead_activity_created', '', '2021-11-24 15:22:19', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (174, 168, 'not_lead_activity_created', '', '2021-11-24 15:23:13', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (175, 168, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:23:13', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (176, 168, 'not_lead_activity_status_updated', 'a:3:{i:0;s:12:\"andré  mora\";i:1;s:13:\"Nouvelle Fich\";i:2;s:6:\"Client\";}', '2021-11-24 15:26:25', 12, 'andré  mora', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (177, 168, 'not_lead_activity_converted', 'a:1:{i:0;s:12:\"andré  mora\";}', '2021-11-24 15:26:46', 12, 'andré  mora', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (178, 169, 'not_lead_activity_created', '', '2021-11-24 15:43:52', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (179, 169, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:43:52', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (180, 170, 'not_lead_activity_created', '', '2021-11-24 15:43:59', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (181, 170, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:43:59', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (182, 171, 'not_lead_activity_created', '', '2021-11-24 15:43:59', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (183, 171, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:43:59', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (184, 172, 'not_lead_activity_created', '', '2021-11-24 15:44:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (185, 172, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:44:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (186, 173, 'not_lead_activity_created', '', '2021-11-24 15:44:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (187, 173, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:87:\"<a href=\"http://localhost/CRM/crm/admin/profile/13\" target=\"_blank\">silvia alvares </a>\";}', '2021-11-24 15:44:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (188, 174, 'not_lead_activity_created', '', '2021-11-24 15:49:35', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (189, 169, 'not_lead_activity_converted', 'a:1:{i:0;s:12:\"andré  mora\";}', '2021-11-24 16:00:13', 12, 'andré  mora', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (190, 175, 'not_lead_activity_created', '', '2021-11-24 17:46:34', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (191, 176, 'not_lead_activity_created', '', '2021-11-24 17:53:52', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (192, 177, 'not_lead_activity_created', '', '2021-11-24 17:57:26', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (193, 177, 'not_lead_activity_assigned_to', 'a:2:{i:0;s:20:\"Houssameddin chammaa\";i:1;s:90:\"<a href=\"http://localhost/CRM/crm/admin/profile/3\" target=\"_blank\">spervisor spervisor</a>\";}', '2021-11-24 17:57:26', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (194, 178, 'not_lead_activity_created', '', '2021-11-24 17:58:12', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (195, 178, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 17:58:54', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (196, 179, 'not_lead_activity_created', '', '2021-11-24 18:01:15', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (197, 179, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 18:02:28', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (198, 177, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 18:04:22', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (199, 180, 'not_lead_activity_created', '', '2021-11-24 18:12:26', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (200, 180, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 18:13:02', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (201, 181, 'not_lead_activity_created', '', '2021-11-24 18:14:29', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (202, 181, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 18:15:09', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (203, 182, 'not_lead_activity_created', '', '2021-11-24 18:17:01', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (204, 182, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-24 18:17:34', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (205, 176, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 09:19:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (206, 183, 'not_lead_activity_created', '', '2021-11-25 09:44:43', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (207, 183, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 09:45:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (208, 184, 'not_lead_activity_created', '', '2021-11-25 09:59:02', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (209, 185, 'not_lead_activity_created', '', '2021-11-25 10:03:20', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (210, 185, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 10:03:56', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (211, 186, 'not_lead_activity_created', '', '2021-11-25 10:11:11', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (212, 186, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 10:11:43', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (213, 187, 'not_lead_activity_created', '', '2021-11-25 11:07:39', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (214, 187, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 11:08:40', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (215, 188, 'not_lead_activity_created', '', '2021-11-25 11:19:18', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (216, 188, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 11:19:59', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (217, 189, 'not_lead_activity_created', '', '2021-11-25 11:53:38', 1, 'Houssameddin chammaa', 0);
INSERT INTO `tbllead_activity_log` (`id`, `leadid`, `description`, `additional_data`, `date`, `staffid`, `full_name`, `custom_activity`) VALUES (218, 189, 'not_lead_activity_converted', 'a:1:{i:0;s:20:\"Houssameddin chammaa\";}', '2021-11-25 11:54:05', 1, 'Houssameddin chammaa', 0);


#
# TABLE STRUCTURE FOR: tbllead_integration_emails
#

DROP TABLE IF EXISTS `tbllead_integration_emails`;

CREATE TABLE `tbllead_integration_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` mediumtext DEFAULT NULL,
  `body` mediumtext DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `leadid` int(11) NOT NULL,
  `emailid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblleads
#

DROP TABLE IF EXISTS `tblleads`;

CREATE TABLE `tblleads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash` varchar(65) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `company` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(15) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `from_form_id` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL,
  `source` int(11) NOT NULL,
  `lastcontact` datetime DEFAULT NULL,
  `dateassigned` date DEFAULT NULL,
  `last_status_change` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `leadorder` int(11) DEFAULT 1,
  `phonenumber` varchar(50) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `lost` tinyint(1) NOT NULL DEFAULT 0,
  `junk` int(11) NOT NULL DEFAULT 0,
  `last_lead_status` int(11) NOT NULL DEFAULT 0,
  `is_imported_from_email_integration` tinyint(1) NOT NULL DEFAULT 0,
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `default_language` varchar(40) DEFAULT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `title` varchar(50) NOT NULL,
  `lead_value` varchar(50) NOT NULL,
  `nom_service` varchar(155) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `company` (`company`),
  KEY `email` (`email`),
  KEY `assigned` (`assigned`),
  KEY `status` (`status`),
  KEY `source` (`source`),
  KEY `lastcontact` (`lastcontact`),
  KEY `dateadded` (`dateadded`),
  KEY `leadorder` (`leadorder`),
  KEY `from_form_id` (`from_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=190 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (183, 'dafe3fbf4ff75289902285e7ee0c7e0d-021a06344cb43e51229a1276f02e51a6', 'client1', NULL, 'noter bien : un bon service ', 76, '78000', 'paris', 'ile-de-france', 'paris ile-de-france', 1, '2021-11-25 09:44:43', 0, 1, 2, NULL, NULL, NULL, 1, 'client1@cl.cl', 1, '045123256', '2021-11-25 09:45:40', 0, 0, 0, 0, NULL, 0, NULL, 0, 'Santé', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (184, '38d22f4b84ff09cce4391423ae3fb0ec-3c2cbcc0e20bbdd3e982948f188b9f19', 'Client', NULL, 'fzezgr', 76, '', 'paris', 'alsace-lorraine', 'paris paris', 1, '2021-11-25 09:59:02', 0, 2, 2, NULL, NULL, NULL, 1, 'Client@li', 1, '024545', NULL, 0, 0, 0, 0, NULL, 0, NULL, 0, 'santé', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (185, '52d42d1851b55ff54b67b02c1a1ce38f-a8cba5e5d0eb5414859a0f27782df536', 'client', NULL, '', 76, '15487', 'paris', 'ile de france', 'paris', 1, '2021-11-25 10:03:20', 0, 1, 2, NULL, NULL, NULL, 1, 'client@li.hi', 1, '0547854', '2021-11-25 10:03:56', 0, 0, 0, 0, NULL, 0, NULL, 0, 'santé', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (186, 'eb83b00865c7a435ce19771237e67c57-91bc8a2d7538983e1a32de7c722b7880', 'kjhsqbjh', NULL, '', 76, '', '', '', '', 1, '2021-11-25 10:11:11', 0, 1, 2, NULL, NULL, NULL, 1, '', 1, '', '2021-11-25 10:11:43', 0, 0, 0, 0, NULL, 0, NULL, 0, '', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (187, 'f16c9b443a2a570ae618bb775b4ce78c-aae8d11489ca43a03278c9f633662083', 'Houssam', NULL, 'paris ile de france', 76, '93000', 'paris', 'ile de france', '', 1, '2021-11-25 11:07:39', 0, 1, 2, NULL, NULL, NULL, 1, 'Houssam@li', 1, '', '2021-11-25 11:08:40', 0, 0, 0, 0, NULL, 0, NULL, 0, 'décennal', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (188, '238b385462cf79f2cbcd41a083b27248-84bd99d54e4871c9e0aacbdff3654985', 'sfsfd', NULL, '', 76, '', 'fsqf', 'fsq', '', 1, '2021-11-25 11:19:18', 0, 1, 2, NULL, NULL, NULL, 1, '', 1, '', '2021-11-25 11:19:59', 0, 0, 0, 0, NULL, 0, NULL, 0, 'sfdf', '', '');
INSERT INTO `tblleads` (`id`, `hash`, `name`, `company`, `description`, `country`, `zip`, `city`, `state`, `address`, `assigned`, `dateadded`, `from_form_id`, `status`, `source`, `lastcontact`, `dateassigned`, `last_status_change`, `addedfrom`, `email`, `leadorder`, `phonenumber`, `date_converted`, `lost`, `junk`, `last_lead_status`, `is_imported_from_email_integration`, `email_integration_uid`, `is_public`, `default_language`, `client_id`, `title`, `lead_value`, `nom_service`) VALUES (189, 'c5d0059221fabc0a7a96578296eb218e-3955070b8f5a0c5260f88594fda9e283', 'ouidad ', NULL, '', 76, '75000', 'paris', 'ile de france', 'zafrzf', 1, '2021-11-25 11:53:38', 0, 1, 2, NULL, NULL, NULL, 1, 'ouidad@li', 1, '8465465465', '2021-11-25 11:54:05', 0, 0, 0, 0, NULL, 0, NULL, 0, 'santé ', '', '');


#
# TABLE STRUCTURE FOR: tblleads_email_integration
#

DROP TABLE IF EXISTS `tblleads_email_integration`;

CREATE TABLE `tblleads_email_integration` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'the ID always must be 1',
  `active` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `imap_server` varchar(100) NOT NULL,
  `password` mediumtext NOT NULL,
  `check_every` int(11) NOT NULL DEFAULT 5,
  `responsible` int(11) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `encryption` varchar(3) DEFAULT NULL,
  `folder` varchar(100) NOT NULL,
  `last_run` varchar(50) DEFAULT NULL,
  `notify_lead_imported` tinyint(1) NOT NULL DEFAULT 1,
  `notify_lead_contact_more_times` tinyint(1) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `only_loop_on_unseen_emails` tinyint(1) NOT NULL DEFAULT 1,
  `delete_after_import` int(11) NOT NULL DEFAULT 0,
  `create_task_if_customer` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_email_integration` (`id`, `active`, `email`, `imap_server`, `password`, `check_every`, `responsible`, `lead_source`, `lead_status`, `encryption`, `folder`, `last_run`, `notify_lead_imported`, `notify_lead_contact_more_times`, `notify_type`, `notify_ids`, `mark_public`, `only_loop_on_unseen_emails`, `delete_after_import`, `create_task_if_customer`) VALUES (1, 0, '', '', '', 10, 0, 0, 0, 'tls', 'INBOX', '', 1, 1, 'assigned', '', 0, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tblleads_sources
#

DROP TABLE IF EXISTS `tblleads_sources`;

CREATE TABLE `tblleads_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (2, 'Facebook');
INSERT INTO `tblleads_sources` (`id`, `name`) VALUES (1, 'Google');


#
# TABLE STRUCTURE FOR: tblleads_status
#

DROP TABLE IF EXISTS `tblleads_status`;

CREATE TABLE `tblleads_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `statusorder` int(11) DEFAULT NULL,
  `color` varchar(10) DEFAULT '#28B8DA',
  `isdefault` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (1, 'Client', 1000, '#7cb342', 1);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (2, 'déja souscris', 2, '#e55a21', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (3, 'Doublon', 3, '#ce00c8', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (4, 'Exclusion', 4, '#13dddb', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (5, 'Fausse Fiche', 5, '#e3e500', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (6, 'Faux Numéro', 6, '#001aef', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (7, 'Hors Cible', 7, '#757575', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (8, 'N\'a pas fait de demande', 8, '#1e0b0b', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (9, 'Pas Intéresser', 9, '#00f2ff', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (10, 'Trop Chére', 10, '#b0b0b0', 0);
INSERT INTO `tblleads_status` (`id`, `name`, `statusorder`, `color`, `isdefault`) VALUES (11, 'Nouvelle Fich', 11, '#757575', 0);


#
# TABLE STRUCTURE FOR: tblmail_queue
#

DROP TABLE IF EXISTS `tblmail_queue`;

CREATE TABLE `tblmail_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `engine` varchar(40) DEFAULT NULL,
  `email` varchar(191) NOT NULL,
  `cc` text DEFAULT NULL,
  `bcc` text DEFAULT NULL,
  `message` mediumtext NOT NULL,
  `alt_message` mediumtext DEFAULT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` text DEFAULT NULL,
  `attachments` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmigrations
#

DROP TABLE IF EXISTS `tblmigrations`;

CREATE TABLE `tblmigrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblmigrations` (`version`) VALUES ('291');


#
# TABLE STRUCTURE FOR: tblmilestones
#

DROP TABLE IF EXISTS `tblmilestones`;

CREATE TABLE `tblmilestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `description_visible_to_customer` tinyint(1) DEFAULT 0,
  `due_date` date NOT NULL,
  `project_id` int(11) NOT NULL,
  `color` varchar(10) DEFAULT NULL,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `datecreated` date NOT NULL,
  `hide_from_customer` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblmodules
#

DROP TABLE IF EXISTS `tblmodules`;

CREATE TABLE `tblmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (1, 'theme_style', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (2, 'backup', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (3, 'goals', '2.3.0', 1);
INSERT INTO `tblmodules` (`id`, `module_name`, `installed_version`, `active`) VALUES (4, 'menu_setup', '2.3.0', 1);


#
# TABLE STRUCTURE FOR: tblnewsfeed_comment_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_comment_likes`;

CREATE TABLE `tblnewsfeed_comment_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `commentid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_comments
#

DROP TABLE IF EXISTS `tblnewsfeed_post_comments`;

CREATE TABLE `tblnewsfeed_post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `postid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_post_likes
#

DROP TABLE IF EXISTS `tblnewsfeed_post_likes`;

CREATE TABLE `tblnewsfeed_post_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `dateliked` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnewsfeed_posts
#

DROP TABLE IF EXISTS `tblnewsfeed_posts`;

CREATE TABLE `tblnewsfeed_posts` (
  `postid` int(11) NOT NULL AUTO_INCREMENT,
  `creator` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `visibility` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `pinned` int(11) NOT NULL,
  `datepinned` datetime DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblnotes
#

DROP TABLE IF EXISTS `tblnotes`;

CREATE TABLE `tblnotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblnotes` (`id`, `rel_id`, `rel_type`, `description`, `date_contacted`, `addedfrom`, `dateadded`) VALUES (1, 183, 'lead', '', NULL, 1, '2021-11-25 09:46:53');


#
# TABLE STRUCTURE FOR: tblnotifications
#

DROP TABLE IF EXISTS `tblnotifications`;

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isread` int(11) NOT NULL DEFAULT 0,
  `isread_inline` tinyint(1) NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT 0,
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext DEFAULT NULL,
  `additional_data` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (1, 1, 1, '2021-11-17 16:33:32', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 3, NULL, '#leadid=2', 'a:1:{i:0;s:10:\"Conseiller\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (2, 1, 0, '2021-11-17 16:39:05', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 4, NULL, '#leadid=3', 'a:1:{i:0;s:12:\"Gestionnaire\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (3, 1, 0, '2021-11-18 10:41:56', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 4, NULL, '#leadid=20', 'a:1:{i:0;s:9:\"dkfndfskn\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (4, 1, 1, '2021-11-22 15:11:48', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 3, NULL, '#leadid=104', 'a:1:{i:0;s:3:\"eaz\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (5, 1, 1, '2021-11-23 14:41:12', 'not_staff_added_as_project_member', 1, 0, 'Houssameddin chammaa', 3, NULL, 'projects/view/5', 'a:1:{i:0;s:11:\"Prévoyance\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (6, 1, 0, '2021-11-23 17:37:46', 'not_assigned_lead_to_you', 2, 0, 'conseiller conseiller', 1, NULL, '#leadid=142', 'a:1:{i:0;s:10:\"clientauoo\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (7, 1, 1, '2021-11-23 17:38:03', 'not_assigned_lead_to_you', 2, 0, 'conseiller conseiller', 1, NULL, '#leadid=143', 'a:1:{i:0;s:10:\"clientauoo\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (8, 1, 0, '2021-11-23 17:38:03', 'not_assigned_lead_to_you', 2, 0, 'conseiller conseiller', 1, NULL, '#leadid=144', 'a:1:{i:0;s:10:\"clientauoo\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (9, 1, 0, '2021-11-23 17:38:03', 'not_assigned_lead_to_you', 2, 0, 'conseiller conseiller', 1, NULL, '#leadid=145', 'a:1:{i:0;s:10:\"clientauoo\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (10, 1, 0, '2021-11-23 17:38:03', 'not_assigned_lead_to_you', 2, 0, 'conseiller conseiller', 1, NULL, '#leadid=146', 'a:1:{i:0;s:10:\"clientauoo\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (11, 1, 1, '2021-11-24 10:10:19', 'not_customer_uploaded_file', 0, 2, 'Client yioou', 1, NULL, 'clients/client/2?group=attachments', NULL);
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (12, 1, 1, '2021-11-24 10:10:19', 'not_customer_uploaded_file', 0, 2, 'Client yioou', 6, NULL, 'clients/client/2?group=attachments', NULL);
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (13, 1, 0, '2021-11-24 15:19:27', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=156', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (14, 1, 0, '2021-11-24 15:19:36', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=157', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (15, 1, 0, '2021-11-24 15:19:36', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=158', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (16, 1, 0, '2021-11-24 15:19:37', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=159', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (17, 1, 0, '2021-11-24 15:19:39', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=160', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (18, 1, 1, '2021-11-24 15:19:40', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=161', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (19, 1, 0, '2021-11-24 15:19:40', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=162', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (20, 1, 0, '2021-11-24 15:19:51', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=163', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (21, 1, 0, '2021-11-24 15:19:51', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=164', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (22, 1, 0, '2021-11-24 15:19:51', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=165', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (23, 1, 0, '2021-11-24 15:19:51', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=166', 'a:1:{i:0;s:11:\"jean dupont\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (24, 1, 0, '2021-11-24 15:23:13', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=168', 'a:1:{i:0;s:4:\"jean\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (25, 0, 0, '2021-11-24 15:43:52', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=169', 'a:1:{i:0;s:8:\"prospect\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (26, 0, 0, '2021-11-24 15:43:59', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=170', 'a:1:{i:0;s:8:\"prospect\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (27, 0, 0, '2021-11-24 15:43:59', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=171', 'a:1:{i:0;s:8:\"prospect\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (28, 0, 0, '2021-11-24 15:44:11', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=172', 'a:1:{i:0;s:8:\"prospect\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (29, 0, 0, '2021-11-24 15:44:11', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 13, NULL, '#leadid=173', 'a:1:{i:0;s:8:\"prospect\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (30, 1, 1, '2021-11-24 16:09:46', 'not_customer_viewed_estimate', 0, 1, 'ok ok', 12, NULL, 'estimates/list_estimates/2', 'a:1:{i:0;s:10:\"EST-000002\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (31, 1, 0, '2021-11-24 16:14:17', 'not_estimate_customer_accepted', 0, 1, '', 12, 1, 'estimates/list_estimates/2', 'a:1:{i:0;s:10:\"EST-000002\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (32, 1, 1, '2021-11-24 16:14:18', 'not_customer_viewed_invoice', 0, 1, 'ok ok', 12, NULL, 'invoices/list_invoices/1', 'a:1:{i:0;s:10:\"INV-000001\";}');
INSERT INTO `tblnotifications` (`id`, `isread`, `isread_inline`, `date`, `description`, `fromuserid`, `fromclientid`, `from_fullname`, `touserid`, `fromcompany`, `link`, `additional_data`) VALUES (33, 0, 0, '2021-11-24 17:57:26', 'not_assigned_lead_to_you', 1, 0, 'Houssameddin chammaa', 3, NULL, '#leadid=177', 'a:1:{i:0;s:6:\"client\";}');


#
# TABLE STRUCTURE FOR: tbloptions
#

DROP TABLE IF EXISTS `tbloptions`;

CREATE TABLE `tbloptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `value` longtext NOT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=431 DEFAULT CHARSET=utf8;

INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (1, 'dateformat', 'Y-m-d|%Y-%m-%d', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (2, 'companyname', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (3, 'services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (4, 'maximum_allowed_ticket_attachments', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (5, 'ticket_attachments_file_extensions', '.jpg,.png,.pdf,.doc,.zip,.rar', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (6, 'staff_access_only_assigned_departments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (7, 'use_knowledge_base', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (8, 'smtp_email', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (9, 'smtp_password', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (10, 'company_info_format', '{company_name}<br />\r\n{address}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (11, 'smtp_port', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (12, 'smtp_host', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (13, 'smtp_email_charset', 'utf-8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (14, 'default_timezone', 'UTC', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (15, 'clients_default_theme', 'perfex', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (16, 'company_logo', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (17, 'tables_pagination_limit', '25', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (18, 'main_domain', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (19, 'allow_registration', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (20, 'knowledge_base_without_registration', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (21, 'email_signature', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (22, 'default_staff_role', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (23, 'newsfeed_maximum_files_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (24, 'contract_expiration_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (25, 'invoice_prefix', 'INV-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (26, 'decimal_separator', '.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (27, 'thousand_separator', ',', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (28, 'invoice_company_name', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (29, 'invoice_company_address', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (30, 'invoice_company_city', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (31, 'invoice_company_country_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (32, 'invoice_company_postal_code', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (33, 'invoice_company_phonenumber', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (34, 'view_invoice_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (35, 'invoice_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (36, 'next_invoice_number', '2', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (37, 'active_language', 'french', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (38, 'invoice_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (39, 'automatically_send_invoice_overdue_reminder_after', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (40, 'automatically_resend_invoice_overdue_reminder_after', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (41, 'expenses_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (42, 'delete_only_on_last_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (43, 'delete_only_on_last_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (44, 'create_invoice_from_recurring_only_on_paid_invoices', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (45, 'allow_payment_amount_to_be_modified', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (46, 'rtl_support_client', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (47, 'limit_top_search_bar_results_to', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (48, 'estimate_prefix', 'EST-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (49, 'next_estimate_number', '4', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (50, 'estimate_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (51, 'estimate_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (52, 'estimate_auto_convert_to_invoice_on_client_accept', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (53, 'exclude_estimate_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (54, 'rtl_support_admin', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (55, 'last_cron_run', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (56, 'show_sale_agent_on_estimates', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (57, 'show_sale_agent_on_invoices', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (58, 'predefined_terms_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (59, 'predefined_terms_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (60, 'default_task_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (61, 'dropbox_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (62, 'show_expense_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (63, 'only_show_contact_tickets', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (64, 'predefined_clientnote_invoice', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (65, 'predefined_clientnote_estimate', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (66, 'custom_pdf_logo_image_url', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (67, 'favicon', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (68, 'invoice_due_after', '30', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (69, 'google_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (70, 'google_calendar_main_calendar', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (71, 'default_tax', 'a:0:{}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (72, 'show_invoices_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (73, 'show_estimates_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (74, 'show_contracts_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (75, 'show_tasks_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (76, 'show_customer_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (77, 'output_client_pdfs_from_admin_area_in_client_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (78, 'show_lead_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (79, 'send_estimate_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (80, 'leads_default_source', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (81, 'leads_default_status', '11', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (82, 'proposal_expiry_reminder_enabled', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (83, 'send_proposal_expiry_reminder_before', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (84, 'default_contact_permissions', 'a:6:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"3\";i:3;s:1:\"4\";i:4;s:1:\"5\";i:5;s:1:\"6\";}', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (85, 'pdf_logo_width', '150', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (86, 'access_tickets_to_none_staff_members', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (87, 'customer_default_country', '76', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (88, 'view_estimate_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (89, 'show_status_on_pdf_ei', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (90, 'email_piping_only_replies', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (91, 'email_piping_only_registered', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (92, 'default_view_calendar', 'dayGridMonth', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (93, 'email_piping_default_priority', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (94, 'total_to_words_lowercase', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (95, 'show_tax_per_item', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (96, 'total_to_words_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (97, 'receive_notification_on_new_ticket', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (98, 'autoclose_tickets_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (99, 'media_max_file_size_upload', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (100, 'client_staff_add_edit_delete_task_comments_first_hour', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (101, 'show_projects_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (102, 'leads_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (103, 'tasks_reminder_notification_before', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (104, 'pdf_font', 'freesans', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (105, 'pdf_table_heading_color', '#323a45', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (106, 'pdf_table_heading_text_color', '#ffffff', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (107, 'pdf_font_size', '10', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (108, 'default_leads_kanban_sort', 'lastcontact', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (109, 'default_leads_kanban_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (110, 'allowed_files', '.png,.jpg,.pdf,.doc,.docx,.xls,.xlsx,.zip,.rar,.txt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (111, 'show_all_tasks_for_project_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (112, 'email_protocol', 'smtp', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (113, 'calendar_first_day', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (114, 'recaptcha_secret_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (115, 'show_help_on_setup_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (116, 'show_proposals_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (117, 'smtp_encryption', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (118, 'recaptcha_site_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (119, 'smtp_username', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (120, 'auto_stop_tasks_timers_on_new_timer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (121, 'notification_when_customer_pay_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (122, 'calendar_invoice_color', '#FF6F00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (123, 'calendar_estimate_color', '#FF6F00', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (124, 'calendar_proposal_color', '#84c529', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (125, 'new_task_auto_assign_current_member', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (126, 'calendar_reminder_color', '#03A9F4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (127, 'calendar_contract_color', '#B72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (128, 'calendar_project_color', '#B72974', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (129, 'update_info_message', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (130, 'show_estimate_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (131, 'show_invoice_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (132, 'show_proposal_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (133, 'proposal_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (134, 'allow_customer_to_change_ticket_status', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (135, 'lead_lock_after_convert_to_customer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (136, 'default_proposals_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (137, 'default_proposals_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (138, 'default_estimates_pipeline_sort', 'pipeline_order', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (139, 'default_estimates_pipeline_sort_type', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (140, 'use_recaptcha_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (141, 'remove_decimals_on_zero', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (142, 'remove_tax_name_from_item_table', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (143, 'pdf_format_invoice', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (144, 'pdf_format_estimate', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (145, 'pdf_format_proposal', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (146, 'pdf_format_payment', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (147, 'pdf_format_contract', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (148, 'swap_pdf_info', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (149, 'exclude_invoice_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (150, 'cron_has_run_from_cli', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (151, 'hide_cron_is_required_message', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (152, 'auto_assign_customer_admin_after_lead_convert', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (153, 'show_transactions_on_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (154, 'show_pay_link_to_invoice_pdf', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (155, 'tasks_kanban_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (156, 'purchase_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (157, 'estimates_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (158, 'proposals_pipeline_limit', '50', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (159, 'proposal_number_prefix', 'PRO-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (160, 'number_padding_prefixes', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (161, 'show_page_number_on_pdf', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (162, 'calendar_events_limit', '4', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (163, 'show_setup_menu_item_only_on_hover', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (164, 'company_requires_vat_number_field', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (165, 'company_is_required', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (166, 'allow_contact_to_delete_files', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (167, 'company_vat', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (168, 'di', '1637072364', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (169, 'invoice_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (170, 'use_minified_files', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (171, 'only_own_files_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (172, 'allow_primary_contact_to_view_edit_billing_and_shipping', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (173, 'estimate_due_after', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (174, 'staff_members_open_tickets_to_all_contacts', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (175, 'time_format', '24', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (176, 'delete_activity_log_older_then', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (177, 'disable_language', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (178, 'company_state', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (179, 'email_header', '<!doctype html>\r\n                            <html>\r\n                            <head>\r\n                              <meta name=\"viewport\" content=\"width=device-width\" />\r\n                              <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\r\n                              <style>\r\n                                body {\r\n                                 background-color: #f6f6f6;\r\n                                 font-family: sans-serif;\r\n                                 -webkit-font-smoothing: antialiased;\r\n                                 font-size: 14px;\r\n                                 line-height: 1.4;\r\n                                 margin: 0;\r\n                                 padding: 0;\r\n                                 -ms-text-size-adjust: 100%;\r\n                                 -webkit-text-size-adjust: 100%;\r\n                               }\r\n                               table {\r\n                                 border-collapse: separate;\r\n                                 mso-table-lspace: 0pt;\r\n                                 mso-table-rspace: 0pt;\r\n                                 width: 100%;\r\n                               }\r\n                               table td {\r\n                                 font-family: sans-serif;\r\n                                 font-size: 14px;\r\n                                 vertical-align: top;\r\n                               }\r\n                                   /* -------------------------------------\r\n                                     BODY & CONTAINER\r\n                                     ------------------------------------- */\r\n                                     .body {\r\n                                       background-color: #f6f6f6;\r\n                                       width: 100%;\r\n                                     }\r\n                                     /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */\r\n\r\n                                     .container {\r\n                                       display: block;\r\n                                       margin: 0 auto !important;\r\n                                       /* makes it centered */\r\n                                       max-width: 680px;\r\n                                       padding: 10px;\r\n                                       width: 680px;\r\n                                     }\r\n                                     /* This should also be a block element, so that it will fill 100% of the .container */\r\n\r\n                                     .content {\r\n                                       box-sizing: border-box;\r\n                                       display: block;\r\n                                       margin: 0 auto;\r\n                                       max-width: 680px;\r\n                                       padding: 10px;\r\n                                     }\r\n                                   /* -------------------------------------\r\n                                     HEADER, FOOTER, MAIN\r\n                                     ------------------------------------- */\r\n\r\n                                     .main {\r\n                                       background: #fff;\r\n                                       border-radius: 3px;\r\n                                       width: 100%;\r\n                                     }\r\n                                     .wrapper {\r\n                                       box-sizing: border-box;\r\n                                       padding: 20px;\r\n                                     }\r\n                                     .footer {\r\n                                       clear: both;\r\n                                       padding-top: 10px;\r\n                                       text-align: center;\r\n                                       width: 100%;\r\n                                     }\r\n                                     .footer td,\r\n                                     .footer p,\r\n                                     .footer span,\r\n                                     .footer a {\r\n                                       color: #999999;\r\n                                       font-size: 12px;\r\n                                       text-align: center;\r\n                                     }\r\n                                     hr {\r\n                                       border: 0;\r\n                                       border-bottom: 1px solid #f6f6f6;\r\n                                       margin: 20px 0;\r\n                                     }\r\n                                   /* -------------------------------------\r\n                                     RESPONSIVE AND MOBILE FRIENDLY STYLES\r\n                                     ------------------------------------- */\r\n\r\n                                     @media only screen and (max-width: 620px) {\r\n                                       table[class=body] .content {\r\n                                         padding: 0 !important;\r\n                                       }\r\n                                       table[class=body] .container {\r\n                                         padding: 0 !important;\r\n                                         width: 100% !important;\r\n                                       }\r\n                                       table[class=body] .main {\r\n                                         border-left-width: 0 !important;\r\n                                         border-radius: 0 !important;\r\n                                         border-right-width: 0 !important;\r\n                                       }\r\n                                     }\r\n                                   </style>\r\n                                 </head>\r\n                                 <body class=\"\">\r\n                                  <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\">\r\n                                    <tr>\r\n                                     <td>&nbsp;</td>\r\n                                     <td class=\"container\">\r\n                                      <div class=\"content\">\r\n                                        <!-- START CENTERED WHITE CONTAINER -->\r\n                                        <table class=\"main\">\r\n                                          <!-- START MAIN CONTENT AREA -->\r\n                                          <tr>\r\n                                           <td class=\"wrapper\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                              <tr>\r\n                                               <td>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (180, 'show_pdf_signature_invoice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (181, 'show_pdf_signature_estimate', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (182, 'signature_image', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (183, 'email_footer', '</td>\r\n                             </tr>\r\n                           </table>\r\n                         </td>\r\n                       </tr>\r\n                       <!-- END MAIN CONTENT AREA -->\r\n                     </table>\r\n                     <!-- START FOOTER -->\r\n                     <div class=\"footer\">\r\n                      <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                        <tr>\r\n                          <td class=\"content-block\">\r\n                            <span>{companyname}</span>\r\n                          </td>\r\n                        </tr>\r\n                      </table>\r\n                    </div>\r\n                    <!-- END FOOTER -->\r\n                    <!-- END CENTERED WHITE CONTAINER -->\r\n                  </div>\r\n                </td>\r\n                <td>&nbsp;</td>\r\n              </tr>\r\n            </table>\r\n            </body>\r\n            </html>', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (184, 'exclude_proposal_from_client_area_with_draft_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (185, 'pusher_app_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (186, 'pusher_app_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (187, 'pusher_app_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (188, 'pusher_realtime_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (189, 'pdf_format_statement', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (190, 'pusher_cluster', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (191, 'show_table_export_button', 'to_all', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (192, 'allow_staff_view_proposals_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (193, 'show_cloudflare_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (194, 'task_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (195, 'lead_modal_class', 'modal-lg', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (196, 'show_timesheets_overview_all_members_notice_admins', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (197, 'desktop_notifications', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (198, 'hide_notified_reminders_from_calendar', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (199, 'customer_info_format', '{company_name}<br />\r\n{street}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{vat_number_with_label}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (200, 'timer_started_change_status_in_progress', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (201, 'default_ticket_reply_status', '3', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (202, 'default_task_status', 'auto', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (203, 'email_queue_skip_with_attachments', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (204, 'email_queue_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (205, 'last_email_queue_retry', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (206, 'auto_dismiss_desktop_notifications_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (207, 'proposal_info_format', '{proposal_to}<br />\r\n{address}<br />\r\n{city} {state}<br />\r\n{country_code} {zip_code}<br />\r\n{phone}<br />\r\n{email}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (208, 'ticket_replies_order', 'asc', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (209, 'new_recurring_invoice_action', 'generate_and_send', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (210, 'bcc_emails', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (211, 'email_templates_language_checks', 'a:79:{s:25:\"new-client-created-french\";i:1;s:29:\"invoice-send-to-client-french\";i:1;s:30:\"new-ticket-opened-admin-french\";i:1;s:19:\"ticket-reply-french\";i:1;s:26:\"ticket-autoresponse-french\";i:1;s:31:\"invoice-payment-recorded-french\";i:1;s:29:\"invoice-overdue-notice-french\";i:1;s:27:\"invoice-already-send-french\";i:1;s:31:\"new-ticket-created-staff-french\";i:1;s:30:\"estimate-send-to-client-french\";i:1;s:28:\"ticket-reply-to-admin-french\";i:1;s:28:\"estimate-already-send-french\";i:1;s:26:\"contract-expiration-french\";i:1;s:20:\"task-assigned-french\";i:1;s:29:\"task-added-as-follower-french\";i:1;s:21:\"task-commented-french\";i:1;s:28:\"task-added-attachment-french\";i:1;s:33:\"estimate-declined-to-staff-french\";i:1;s:33:\"estimate-accepted-to-staff-french\";i:1;s:31:\"proposal-client-accepted-french\";i:1;s:32:\"proposal-send-to-customer-french\";i:1;s:31:\"proposal-client-declined-french\";i:1;s:32:\"proposal-client-thank-you-french\";i:1;s:33:\"proposal-comment-to-client-french\";i:1;s:32:\"proposal-comment-to-admin-french\";i:1;s:37:\"estimate-thank-you-to-customer-french\";i:1;s:33:\"task-deadline-notification-french\";i:1;s:20:\"send-contract-french\";i:1;s:40:\"invoice-payment-recorded-to-staff-french\";i:1;s:24:\"auto-close-ticket-french\";i:1;s:46:\"new-project-discussion-created-to-staff-french\";i:1;s:49:\"new-project-discussion-created-to-customer-french\";i:1;s:44:\"new-project-file-uploaded-to-customer-french\";i:1;s:41:\"new-project-file-uploaded-to-staff-french\";i:1;s:49:\"new-project-discussion-comment-to-customer-french\";i:1;s:46:\"new-project-discussion-comment-to-staff-french\";i:1;s:36:\"staff-added-as-project-member-french\";i:1;s:31:\"estimate-expiry-reminder-french\";i:1;s:31:\"proposal-expiry-reminder-french\";i:1;s:24:\"new-staff-created-french\";i:1;s:30:\"contact-forgot-password-french\";i:1;s:31:\"contact-password-reseted-french\";i:1;s:27:\"contact-set-password-french\";i:1;s:28:\"staff-forgot-password-french\";i:1;s:29:\"staff-password-reseted-french\";i:1;s:26:\"assigned-to-project-french\";i:1;s:40:\"task-added-attachment-to-contacts-french\";i:1;s:33:\"task-commented-to-contacts-french\";i:1;s:24:\"new-lead-assigned-french\";i:1;s:23:\"client-statement-french\";i:1;s:31:\"ticket-assigned-to-admin-french\";i:1;s:37:\"new-client-registered-to-admin-french\";i:1;s:37:\"new-web-to-lead-form-submitted-french\";i:1;s:32:\"two-factor-authentication-french\";i:1;s:35:\"project-finished-to-customer-french\";i:1;s:33:\"credit-note-send-to-client-french\";i:1;s:34:\"task-status-change-to-staff-french\";i:1;s:37:\"task-status-change-to-contacts-french\";i:1;s:27:\"reminder-email-staff-french\";i:1;s:33:\"contract-comment-to-client-french\";i:1;s:32:\"contract-comment-to-admin-french\";i:1;s:24:\"send-subscription-french\";i:1;s:34:\"subscription-payment-failed-french\";i:1;s:28:\"subscription-canceled-french\";i:1;s:37:\"subscription-payment-succeeded-french\";i:1;s:35:\"contract-expiration-to-staff-french\";i:1;s:27:\"gdpr-removal-request-french\";i:1;s:32:\"gdpr-removal-request-lead-french\";i:1;s:36:\"client-registration-confirmed-french\";i:1;s:31:\"contract-signed-to-staff-french\";i:1;s:35:\"customer-subscribed-to-staff-french\";i:1;s:33:\"contact-verification-email-french\";i:1;s:50:\"new-customer-profile-file-uploaded-to-staff-french\";i:1;s:34:\"event-notification-to-staff-french\";i:1;s:43:\"subscription-payment-requires-action-french\";i:1;s:25:\"invoice-due-notice-french\";i:1;s:42:\"estimate-request-submitted-to-staff-french\";i:1;s:32:\"estimate-request-assigned-french\";i:1;s:40:\"estimate-request-received-to-user-french\";i:1;}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (212, 'proposal_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (213, 'estimate_accept_identity_confirmation', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (214, 'new_task_auto_follower_current_member', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (215, 'task_biillable_checked_on_creation', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (216, 'predefined_clientnote_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (217, 'predefined_terms_credit_note', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (218, 'next_credit_note_number', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (219, 'credit_note_prefix', 'CN-', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (220, 'credit_note_number_decrement_on_delete', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (221, 'pdf_format_credit_note', 'A4-PORTRAIT', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (222, 'show_pdf_signature_credit_note', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (223, 'show_credit_note_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (224, 'show_amount_due_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (225, 'show_total_paid_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (226, 'show_credits_applied_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (227, 'staff_members_create_inline_lead_status', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (228, 'staff_members_create_inline_customer_groups', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (229, 'staff_members_create_inline_ticket_services', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (230, 'staff_members_save_tickets_predefined_replies', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (231, 'staff_members_create_inline_contract_types', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (232, 'staff_members_create_inline_expense_categories', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (233, 'show_project_on_credit_note', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (234, 'proposals_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (235, 'estimates_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (236, 'contracts_auto_operations_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (237, 'credit_note_number_format', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (238, 'allow_non_admin_members_to_import_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (239, 'e_sign_legal_text', 'By clicking on \"Sign\", I consent to be legally bound by this electronic representation of my signature.', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (240, 'show_pdf_signature_contract', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (241, 'view_contract_only_logged_in', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (242, 'show_subscriptions_in_customers_area', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (243, 'calendar_only_assigned_tasks', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (244, 'after_subscription_payment_captured', 'send_invoice_and_receipt', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (245, 'mail_engine', 'phpmailer', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (246, 'gdpr_enable_terms_and_conditions', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (247, 'privacy_policy', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (248, 'terms_and_conditions', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (249, 'gdpr_enable_terms_and_conditions_lead_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (250, 'gdpr_enable_terms_and_conditions_ticket_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (251, 'gdpr_contact_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (252, 'show_gdpr_in_customers_menu', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (253, 'show_gdpr_link_in_footer', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (254, 'enable_gdpr', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (255, 'gdpr_on_forgotten_remove_invoices_credit_notes', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (256, 'gdpr_on_forgotten_remove_estimates', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (257, 'gdpr_enable_consent_for_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (258, 'gdpr_consent_public_page_top_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (259, 'gdpr_page_top_information_block', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (260, 'gdpr_enable_lead_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (261, 'gdpr_show_lead_custom_fields_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (262, 'gdpr_lead_attachments_on_public_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (263, 'gdpr_enable_consent_for_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (264, 'gdpr_lead_enable_right_to_be_forgotten', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (265, 'allow_staff_view_invoices_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (266, 'gdpr_data_portability_leads', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (267, 'gdpr_lead_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (268, 'gdpr_contact_data_portability_allowed', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (269, 'gdpr_data_portability_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (270, 'allow_staff_view_estimates_assigned', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (271, 'gdpr_after_lead_converted_delete', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (272, 'gdpr_show_terms_and_conditions_in_footer', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (273, 'save_last_order_for_tables', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (274, 'company_logo_dark', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (275, 'customers_register_require_confirmation', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (276, 'allow_non_admin_staff_to_delete_ticket_attachments', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (277, 'receive_notification_on_new_ticket_replies', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (278, 'google_client_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (279, 'enable_google_picker', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (280, 'show_ticket_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (281, 'ticket_import_reply_only', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (282, 'visible_customer_profile_tabs', 'a:19:{s:7:\"profile\";b:0;s:8:\"contacts\";b:0;s:5:\"notes\";b:0;s:9:\"statement\";b:0;s:8:\"invoices\";b:0;s:8:\"payments\";b:0;s:9:\"proposals\";b:0;s:12:\"credit_notes\";b:0;s:9:\"estimates\";b:1;s:13:\"subscriptions\";b:0;s:8:\"expenses\";b:0;s:9:\"contracts\";b:1;s:8:\"projects\";b:0;s:5:\"tasks\";b:0;s:7:\"tickets\";b:0;s:11:\"attachments\";b:0;s:5:\"vault\";b:0;s:9:\"reminders\";b:0;s:3:\"map\";b:0;}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (283, 'show_project_on_invoice', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (284, 'show_project_on_estimate', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (285, 'staff_members_create_inline_lead_source', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (286, 'lead_unique_validation', '[\"email\"]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (287, 'last_upgrade_copy_data', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (288, 'custom_js_admin_scripts', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (289, 'custom_js_customer_scripts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (290, 'stripe_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (291, 'stripe_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (292, 'stripe_ideal_webhook_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (293, 'stripe_ideal_webhook_signing_secret', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (294, 'show_php_version_notice', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (295, 'recaptcha_ignore_ips', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (296, 'show_task_reminders_on_calendar', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (297, 'customer_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (298, 'tasks_reminder_notification_hour', '21', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (299, 'allow_primary_contact_to_manage_other_contacts', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (300, 'items_table_amounts_exclude_currency_symbol', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (301, 'round_off_task_timer_option', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (302, 'round_off_task_timer_time', '5', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (303, 'bitly_access_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (304, 'enable_support_menu_badges', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (305, 'attach_invoice_to_payment_receipt_email', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (306, 'invoice_due_notice_before', '2', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (307, 'invoice_due_notice_resend_after', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (308, '_leads_settings', 'true', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (309, 'show_estimate_request_in_customers_area', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (310, 'gdpr_enable_terms_and_conditions_estimate_request_form', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (311, 'upgraded_from_version', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (312, 'identification_key', '136200665616370725156193be831ab9d', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (313, 'automatically_stop_task_timer_after_hours', '8', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (314, 'automatically_assign_ticket_to_first_staff_responding', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (315, 'sms_clickatell_api_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (316, 'sms_clickatell_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (317, 'sms_clickatell_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (318, 'sms_msg91_sender_id', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (319, 'sms_msg91_api_type', 'api', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (320, 'sms_msg91_auth_key', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (321, 'sms_msg91_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (322, 'sms_msg91_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (323, 'sms_twilio_account_sid', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (324, 'sms_twilio_auth_token', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (325, 'sms_twilio_phone_number', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (326, 'sms_twilio_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (327, 'sms_twilio_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (328, 'paymentmethod_instamojo_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (329, 'paymentmethod_instamojo_label', 'Instamojo', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (330, 'paymentmethod_instamojo_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (331, 'paymentmethod_instamojo_auth_token', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (332, 'paymentmethod_instamojo_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (333, 'paymentmethod_instamojo_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (334, 'paymentmethod_instamojo_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (335, 'paymentmethod_instamojo_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (336, 'paymentmethod_instamojo_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (337, 'paymentmethod_paypal_braintree_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (338, 'paymentmethod_paypal_braintree_label', 'Braintree', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (339, 'paymentmethod_paypal_braintree_merchant_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (340, 'paymentmethod_paypal_braintree_api_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (341, 'paymentmethod_paypal_braintree_api_private_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (342, 'paymentmethod_paypal_braintree_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (343, 'paymentmethod_paypal_braintree_paypal_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (344, 'paymentmethod_paypal_braintree_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (345, 'paymentmethod_paypal_braintree_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (346, 'paymentmethod_paypal_braintree_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (347, 'paymentmethod_paypal_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (348, 'paymentmethod_paypal_checkout_label', 'Paypal Smart Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (349, 'paymentmethod_paypal_checkout_client_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (350, 'paymentmethod_paypal_checkout_secret', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (351, 'paymentmethod_paypal_checkout_payment_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (352, 'paymentmethod_paypal_checkout_currencies', 'USD,CAD,EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (353, 'paymentmethod_paypal_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (354, 'paymentmethod_paypal_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (355, 'paymentmethod_paypal_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (356, 'paymentmethod_paypal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (357, 'paymentmethod_paypal_label', 'Paypal', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (358, 'paymentmethod_paypal_username', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (359, 'paymentmethod_paypal_password', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (360, 'paymentmethod_paypal_signature', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (361, 'paymentmethod_paypal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (362, 'paymentmethod_paypal_currencies', 'EUR,USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (363, 'paymentmethod_paypal_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (364, 'paymentmethod_paypal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (365, 'paymentmethod_paypal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (366, 'paymentmethod_authorize_acceptjs_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (367, 'paymentmethod_authorize_acceptjs_label', 'Authorize.net Accept.js', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (368, 'paymentmethod_authorize_acceptjs_public_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (369, 'paymentmethod_authorize_acceptjs_api_login_id', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (370, 'paymentmethod_authorize_acceptjs_api_transaction_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (371, 'paymentmethod_authorize_acceptjs_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (372, 'paymentmethod_authorize_acceptjs_currencies', 'USD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (373, 'paymentmethod_authorize_acceptjs_test_mode_enabled', '0', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (374, 'paymentmethod_authorize_acceptjs_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (375, 'paymentmethod_authorize_acceptjs_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (376, 'paymentmethod_mollie_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (377, 'paymentmethod_mollie_label', 'Mollie', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (378, 'paymentmethod_mollie_api_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (379, 'paymentmethod_mollie_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (380, 'paymentmethod_mollie_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (381, 'paymentmethod_mollie_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (382, 'paymentmethod_mollie_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (383, 'paymentmethod_mollie_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (384, 'paymentmethod_payu_money_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (385, 'paymentmethod_payu_money_label', 'PayU Money', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (386, 'paymentmethod_payu_money_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (387, 'paymentmethod_payu_money_salt', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (388, 'paymentmethod_payu_money_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (389, 'paymentmethod_payu_money_currencies', 'INR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (390, 'paymentmethod_payu_money_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (391, 'paymentmethod_payu_money_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (392, 'paymentmethod_payu_money_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (393, 'paymentmethod_stripe_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (394, 'paymentmethod_stripe_label', 'Stripe Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (395, 'paymentmethod_stripe_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (396, 'paymentmethod_stripe_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (397, 'paymentmethod_stripe_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (398, 'paymentmethod_stripe_currencies', 'USD,CAD', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (399, 'paymentmethod_stripe_allow_primary_contact_to_update_credit_card', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (400, 'paymentmethod_stripe_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (401, 'paymentmethod_stripe_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (402, 'paymentmethod_stripe_ideal_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (403, 'paymentmethod_stripe_ideal_label', 'Stripe iDEAL', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (404, 'paymentmethod_stripe_ideal_api_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (405, 'paymentmethod_stripe_ideal_api_publishable_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (406, 'paymentmethod_stripe_ideal_description_dashboard', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (407, 'paymentmethod_stripe_ideal_statement_descriptor', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (408, 'paymentmethod_stripe_ideal_currencies', 'EUR', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (409, 'paymentmethod_stripe_ideal_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (410, 'paymentmethod_stripe_ideal_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (411, 'paymentmethod_two_checkout_active', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (412, 'paymentmethod_two_checkout_label', '2Checkout', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (413, 'paymentmethod_two_checkout_merchant_code', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (414, 'paymentmethod_two_checkout_secret_key', '', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (415, 'paymentmethod_two_checkout_description', 'Payment for Invoice {invoice_number}', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (416, 'paymentmethod_two_checkout_currencies', 'USD, EUR, GBP', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (417, 'paymentmethod_two_checkout_test_mode_enabled', '1', 0);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (418, 'paymentmethod_two_checkout_default_selected', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (419, 'paymentmethod_two_checkout_initialized', '1', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (420, 'theme_style', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (421, 'theme_style_custom_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (422, 'theme_style_custom_clients_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (423, 'theme_style_custom_clients_and_admin_area', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (424, 'auto_backup_enabled', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (425, 'auto_backup_every', '7', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (426, 'last_auto_backup', '', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (427, 'delete_backups_older_then', '0', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (428, 'auto_backup_hour', '6', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (429, 'aside_menu_active', '[]', 1);
INSERT INTO `tbloptions` (`id`, `name`, `value`, `autoload`) VALUES (430, 'setup_menu_active', '[]', 1);


#
# TABLE STRUCTURE FOR: tblpayment_modes
#

DROP TABLE IF EXISTS `tblpayment_modes`;

CREATE TABLE `tblpayment_modes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `show_on_pdf` int(11) NOT NULL DEFAULT 0,
  `invoices_only` int(11) NOT NULL DEFAULT 0,
  `expenses_only` int(11) NOT NULL DEFAULT 0,
  `selected_by_default` int(11) NOT NULL DEFAULT 1,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblpayment_modes` (`id`, `name`, `description`, `show_on_pdf`, `invoices_only`, `expenses_only`, `selected_by_default`, `active`) VALUES (1, 'Bank', NULL, 0, 0, 0, 1, 1);


#
# TABLE STRUCTURE FOR: tblpinned_projects
#

DROP TABLE IF EXISTS `tblpinned_projects`;

CREATE TABLE `tblpinned_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_activity
#

DROP TABLE IF EXISTS `tblproject_activity`;

CREATE TABLE `tblproject_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `fullname` varchar(100) DEFAULT NULL,
  `visible_to_customer` int(11) NOT NULL DEFAULT 0,
  `description_key` varchar(191) NOT NULL COMMENT 'Language file key',
  `additional_data` text DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (1, 1, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 12:23:19');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (2, 1, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 12:23:19');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (3, 2, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 12:25:42');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (4, 2, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 12:25:42');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (5, 3, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 14:32:05');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (6, 3, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 14:32:05');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (7, 4, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 14:32:56');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (8, 4, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 14:32:56');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (9, 5, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'spervisor spervisor', '2021-11-23 14:41:12');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (10, 5, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 14:41:12');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (11, 6, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 14:50:37');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (12, 6, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 14:50:37');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (13, 7, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_added_team_member', 'Houssameddin chammaa', '2021-11-23 14:55:12');
INSERT INTO `tblproject_activity` (`id`, `project_id`, `staff_id`, `contact_id`, `fullname`, `visible_to_customer`, `description_key`, `additional_data`, `dateadded`) VALUES (14, 7, 1, 0, 'Houssameddin chammaa', 1, 'project_activity_created', '', '2021-11-23 14:55:12');


#
# TABLE STRUCTURE FOR: tblproject_files
#

DROP TABLE IF EXISTS `tblproject_files`;

CREATE TABLE `tblproject_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(191) NOT NULL,
  `original_file_name` mediumtext DEFAULT NULL,
  `subject` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `project_id` int(11) NOT NULL,
  `visible_to_customer` tinyint(1) DEFAULT 0,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `external` varchar(40) DEFAULT NULL,
  `external_link` text DEFAULT NULL,
  `thumbnail_link` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_members
#

DROP TABLE IF EXISTS `tblproject_members`;

CREATE TABLE `tblproject_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (1, 1, 1);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (2, 2, 1);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (3, 3, 1);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (4, 4, 1);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (5, 5, 3);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (6, 6, 1);
INSERT INTO `tblproject_members` (`id`, `project_id`, `staff_id`) VALUES (7, 7, 1);


#
# TABLE STRUCTURE FOR: tblproject_notes
#

DROP TABLE IF EXISTS `tblproject_notes`;

CREATE TABLE `tblproject_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproject_settings
#

DROP TABLE IF EXISTS `tblproject_settings`;

CREATE TABLE `tblproject_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (1, 1, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (2, 1, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (3, 1, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (4, 1, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (5, 1, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (6, 1, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (7, 1, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (8, 1, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (9, 1, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (10, 1, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (11, 1, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (12, 1, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (13, 1, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (14, 1, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (15, 1, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (16, 1, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (17, 1, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (18, 1, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (19, 1, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (20, 2, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (21, 2, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (22, 2, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (23, 2, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (24, 2, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (25, 2, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (26, 2, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (27, 2, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (28, 2, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (29, 2, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (30, 2, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (31, 2, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (32, 2, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (33, 2, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (34, 2, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (35, 2, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (36, 2, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (37, 2, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (38, 2, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (39, 3, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (40, 3, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (41, 3, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (42, 3, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (43, 3, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (44, 3, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (45, 3, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (46, 3, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (47, 3, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (48, 3, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (49, 3, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (50, 3, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (51, 3, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (52, 3, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (53, 3, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (54, 3, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (55, 3, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (56, 3, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (57, 3, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (58, 4, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (59, 4, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (60, 4, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (61, 4, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (62, 4, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (63, 4, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (64, 4, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (65, 4, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (66, 4, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (67, 4, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (68, 4, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (69, 4, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (70, 4, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (71, 4, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (72, 4, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (73, 4, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (74, 4, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (75, 4, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (76, 4, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (77, 5, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (78, 5, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (79, 5, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (80, 5, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (81, 5, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (82, 5, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (83, 5, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (84, 5, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (85, 5, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (86, 5, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (87, 5, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (88, 5, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (89, 5, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (90, 5, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (91, 5, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (92, 5, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (93, 5, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (94, 5, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (95, 5, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (96, 6, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:1;s:18:\"project_timesheets\";i:1;s:18:\"project_milestones\";i:1;s:13:\"project_files\";i:1;s:19:\"project_discussions\";i:1;s:13:\"project_gantt\";i:1;s:15:\"project_tickets\";i:1;s:17:\"project_contracts\";i:1;s:16:\"project_invoices\";i:1;s:17:\"project_estimates\";i:1;s:16:\"project_expenses\";i:1;s:20:\"project_credit_notes\";i:1;s:21:\"project_subscriptions\";i:1;s:13:\"project_notes\";i:1;s:16:\"project_activity\";i:1;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (97, 6, 'view_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (98, 6, 'create_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (99, 6, 'edit_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (100, 6, 'comment_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (101, 6, 'view_task_comments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (102, 6, 'view_task_attachments', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (103, 6, 'view_task_checklist_items', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (104, 6, 'upload_on_tasks', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (105, 6, 'view_task_total_logged_time', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (106, 6, 'view_finance_overview', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (107, 6, 'upload_files', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (108, 6, 'open_discussions', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (109, 6, 'view_milestones', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (110, 6, 'view_gantt', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (111, 6, 'view_timesheets', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (112, 6, 'view_activity_log', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (113, 6, 'view_team_members', '1');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (114, 6, 'hide_tasks_on_main_tasks_table', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (115, 7, 'available_features', 'a:16:{s:16:\"project_overview\";i:1;s:13:\"project_tasks\";i:0;s:18:\"project_timesheets\";i:0;s:18:\"project_milestones\";i:0;s:13:\"project_files\";i:0;s:19:\"project_discussions\";i:0;s:13:\"project_gantt\";i:0;s:15:\"project_tickets\";i:0;s:17:\"project_contracts\";i:0;s:16:\"project_invoices\";i:0;s:17:\"project_estimates\";i:0;s:16:\"project_expenses\";i:0;s:20:\"project_credit_notes\";i:0;s:21:\"project_subscriptions\";i:0;s:13:\"project_notes\";i:0;s:16:\"project_activity\";i:0;}');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (116, 7, 'view_tasks', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (117, 7, 'create_tasks', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (118, 7, 'edit_tasks', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (119, 7, 'comment_on_tasks', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (120, 7, 'view_task_comments', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (121, 7, 'view_task_attachments', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (122, 7, 'view_task_checklist_items', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (123, 7, 'upload_on_tasks', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (124, 7, 'view_task_total_logged_time', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (125, 7, 'view_finance_overview', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (126, 7, 'upload_files', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (127, 7, 'open_discussions', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (128, 7, 'view_milestones', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (129, 7, 'view_gantt', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (130, 7, 'view_timesheets', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (131, 7, 'view_activity_log', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (132, 7, 'view_team_members', '0');
INSERT INTO `tblproject_settings` (`id`, `project_id`, `name`, `value`) VALUES (133, 7, 'hide_tasks_on_main_tasks_table', '0');


#
# TABLE STRUCTURE FOR: tblprojectdiscussioncomments
#

DROP TABLE IF EXISTS `tblprojectdiscussioncomments`;

CREATE TABLE `tblprojectdiscussioncomments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discussion_id` int(11) NOT NULL,
  `discussion_type` varchar(10) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  `content` text NOT NULL,
  `staff_id` int(11) NOT NULL,
  `contact_id` int(11) DEFAULT 0,
  `fullname` varchar(191) DEFAULT NULL,
  `file_name` varchar(191) DEFAULT NULL,
  `file_mime_type` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojectdiscussions
#

DROP TABLE IF EXISTS `tblprojectdiscussions`;

CREATE TABLE `tblprojectdiscussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `show_to_customer` tinyint(1) NOT NULL DEFAULT 0,
  `datecreated` datetime NOT NULL,
  `last_activity` datetime DEFAULT NULL,
  `staff_id` int(11) NOT NULL DEFAULT 0,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblprojects
#

DROP TABLE IF EXISTS `tblprojects`;

CREATE TABLE `tblprojects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `project_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `progress_from_tasks` int(11) NOT NULL DEFAULT 1,
  `project_cost` decimal(15,2) DEFAULT NULL,
  `project_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11) DEFAULT 1,
  `notify_contacts` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposal_comments
#

DROP TABLE IF EXISTS `tblproposal_comments`;

CREATE TABLE `tblproposal_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext DEFAULT NULL,
  `proposalid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblproposals
#

DROP TABLE IF EXISTS `tblproposals`;

CREATE TABLE `tblproposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(191) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `total_tax` decimal(15,2) NOT NULL DEFAULT 0.00,
  `adjustment` decimal(15,2) DEFAULT NULL,
  `discount_percent` decimal(15,2) NOT NULL,
  `discount_total` decimal(15,2) NOT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `show_quantity_as` int(11) NOT NULL DEFAULT 1,
  `currency` int(11) NOT NULL,
  `open_till` date DEFAULT NULL,
  `date` date NOT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(40) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `proposal_to` varchar(191) DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `zip` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL DEFAULT 1,
  `status` int(11) NOT NULL,
  `estimate_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `date_converted` datetime DEFAULT NULL,
  `pipeline_order` int(11) NOT NULL DEFAULT 0,
  `is_expiry_notified` int(11) NOT NULL DEFAULT 0,
  `acceptance_firstname` varchar(50) DEFAULT NULL,
  `acceptance_lastname` varchar(50) DEFAULT NULL,
  `acceptance_email` varchar(100) DEFAULT NULL,
  `acceptance_date` datetime DEFAULT NULL,
  `acceptance_ip` varchar(40) DEFAULT NULL,
  `signature` varchar(40) DEFAULT NULL,
  `short_link` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblrelated_items
#

DROP TABLE IF EXISTS `tblrelated_items`;

CREATE TABLE `tblrelated_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(30) NOT NULL,
  `item_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblreminders
#

DROP TABLE IF EXISTS `tblreminders`;

CREATE TABLE `tblreminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL,
  `date` datetime NOT NULL,
  `isnotified` int(11) NOT NULL DEFAULT 0,
  `rel_id` int(11) NOT NULL,
  `staff` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `notify_by_email` int(11) NOT NULL DEFAULT 1,
  `creator` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `staff` (`staff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblroles
#

DROP TABLE IF EXISTS `tblroles`;

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `permissions` longtext DEFAULT NULL,
  PRIMARY KEY (`roleid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (1, 'Responsable', 'a:12:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"customers\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:15:\"email_templates\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"estimates\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"items\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:7:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:17:\"create_milestones\";i:5;s:15:\"edit_milestones\";i:6;s:17:\"delete_milestones\";}s:9:\"proposals\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"staff\";a:1:{i:0;s:4:\"view\";}s:16:\"estimate_request\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"leads\";a:1:{i:0;s:4:\"view\";}}');
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (2, 'Conseiller', 'a:12:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:3:{i:0;s:8:\"view_own\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:9:\"customers\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:15:\"email_templates\";a:1:{i:0;s:4:\"view\";}s:9:\"estimates\";a:4:{i:0;s:8:\"view_own\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"items\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"knowledge_base\";a:1:{i:0;s:4:\"view\";}s:9:\"proposals\";a:4:{i:0;s:8:\"view_own\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"staff\";a:1:{i:0;s:4:\"view\";}s:16:\"estimate_request\";a:4:{i:0;s:8:\"view_own\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"leads\";a:1:{i:0;s:4:\"view\";}}');
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (3, 'Supervisor', 'a:14:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:1:{i:0;s:4:\"view\";}s:9:\"customers\";a:1:{i:0;s:4:\"view\";}s:15:\"email_templates\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"estimates\";a:1:{i:0;s:4:\"view\";}s:14:\"knowledge_base\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:7:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:17:\"create_milestones\";i:5;s:15:\"edit_milestones\";i:6;s:17:\"delete_milestones\";}s:9:\"proposals\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"roles\";a:1:{i:0;s:4:\"view\";}s:8:\"settings\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:5:\"staff\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:16:\"estimate_request\";a:3:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";}s:5:\"leads\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"delete\";}}');
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (4, 'Gestionnaire', 'a:13:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"customers\";a:1:{i:0;s:4:\"view\";}s:15:\"email_templates\";a:1:{i:0;s:4:\"view\";}s:9:\"estimates\";a:1:{i:0;s:4:\"view\";}s:5:\"items\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"knowledge_base\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:1:{i:0;s:4:\"view\";}s:9:\"proposals\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"staff\";a:1:{i:0;s:4:\"view\";}s:16:\"estimate_request\";a:1:{i:0;s:4:\"view\";}s:5:\"leads\";a:1:{i:0;s:4:\"view\";}}');
INSERT INTO `tblroles` (`roleid`, `name`, `permissions`) VALUES (5, 'Admin', 'a:21:{s:17:\"bulk_pdf_exporter\";a:1:{i:0;s:4:\"view\";}s:9:\"contracts\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:12:\"credit_notes\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:9:\"customers\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:15:\"email_templates\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:9:\"estimates\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"expenses\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"invoices\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:14:\"knowledge_base\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"payments\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"projects\";a:7:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:17:\"create_milestones\";i:5;s:15:\"edit_milestones\";i:6;s:17:\"delete_milestones\";}s:9:\"proposals\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:7:\"reports\";a:1:{i:0;s:4:\"view\";}s:5:\"roles\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:8:\"settings\";a:2:{i:0;s:4:\"view\";i:1;s:4:\"edit\";}s:5:\"staff\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:13:\"subscriptions\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"tasks\";a:8:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";i:4;s:14:\"edit_timesheet\";i:5;s:18:\"edit_own_timesheet\";i:6;s:16:\"delete_timesheet\";i:7;s:20:\"delete_own_timesheet\";}s:19:\"checklist_templates\";a:2:{i:0;s:6:\"create\";i:1;s:6:\"delete\";}s:16:\"estimate_request\";a:4:{i:0;s:4:\"view\";i:1;s:6:\"create\";i:2;s:4:\"edit\";i:3;s:6:\"delete\";}s:5:\"leads\";a:2:{i:0;s:4:\"view\";i:1;s:6:\"delete\";}}');


#
# TABLE STRUCTURE FOR: tblsales_activity
#

DROP TABLE IF EXISTS `tblsales_activity`;

CREATE TABLE `tblsales_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_type` varchar(20) DEFAULT NULL,
  `rel_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `additional_data` text DEFAULT NULL,
  `staffid` varchar(11) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (1, 'estimate', 1, 'estimate_activity_created', '', '12', 'andré  mora', '2021-11-24 15:34:50');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (2, 'estimate', 2, 'estimate_activity_created', '', '12', 'andré  mora', '2021-11-24 16:03:00');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (3, 'estimate', 2, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>2</status>\";}', '1', 'Houssameddin chammaa', '2021-11-24 16:07:51');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (4, 'estimate', 1, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>2</status>\";}', '1', 'Houssameddin chammaa', '2021-11-24 16:08:05');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (6, 'invoice', 1, 'invoice_activity_auto_converted_from_estimate', 'a:1:{i:0;s:82:\"<a href=\"http://localhost/CRM/crm/admin/estimates/list_estimates/2\">EST-000002</a>\";}', NULL, '', '2021-11-24 16:14:17');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (7, 'estimate', 2, 'estimate_activity_client_accepted_and_converted', 'a:1:{i:0;s:80:\"<a href=\"http://localhost/CRM/crm/admin/invoices/list_invoices/1\">INV-000001</a>\";}', NULL, '', '2021-11-24 16:14:17');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (8, 'estimate', 1, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>1</status>\";}', '12', 'andré  mora', '2021-11-24 17:22:18');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (9, 'estimate', 1, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>2</status>\";}', '12', 'andré  mora', '2021-11-24 17:22:32');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (10, 'estimate', 1, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>1</status>\";}', '12', 'andré  mora', '2021-11-24 17:22:54');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (11, 'estimate', 1, 'estimate_activity_marked', 'a:1:{i:0;s:18:\"<status>2</status>\";}', '12', 'andré  mora', '2021-11-24 17:23:05');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (12, 'invoice', 1, 'invoice_activity_marked_as_sent', 'a:0:{}', '12', 'andré  mora', '2021-11-24 17:24:11');
INSERT INTO `tblsales_activity` (`id`, `rel_type`, `rel_id`, `description`, `additional_data`, `staffid`, `full_name`, `date`) VALUES (13, 'estimate', 3, 'estimate_activity_created', '', '1', 'Houssameddin chammaa', '2021-11-25 09:49:55');


#
# TABLE STRUCTURE FOR: tblscheduled_emails
#

DROP TABLE IF EXISTS `tblscheduled_emails`;

CREATE TABLE `tblscheduled_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(15) NOT NULL,
  `scheduled_at` datetime NOT NULL,
  `contacts` varchar(197) NOT NULL,
  `cc` text DEFAULT NULL,
  `attach_pdf` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(197) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblservice
#

DROP TABLE IF EXISTS `tblservice`;

CREATE TABLE `tblservice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tblservice` (`id`, `name`) VALUES (1, 'Santé');
INSERT INTO `tblservice` (`id`, `name`) VALUES (2, 'Prévoyance');
INSERT INTO `tblservice` (`id`, `name`) VALUES (3, 'Auto');
INSERT INTO `tblservice` (`id`, `name`) VALUES (4, 'décennal');


#
# TABLE STRUCTURE FOR: tblservices
#

DROP TABLE IF EXISTS `tblservices`;

CREATE TABLE `tblservices` (
  `serviceid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `tblservices` (`serviceid`, `name`) VALUES (1, 'santé');


#
# TABLE STRUCTURE FOR: tblsessions
#

DROP TABLE IF EXISTS `tblsessions`;

CREATE TABLE `tblsessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0jfogv2v3bnne6hll4s1av9md7316qsc', '::1', 1637838739, '__ci_last_regenerate|i:1637838739;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('27n3q3l7ciq821ohu2r1fluva7eq7l7g', '::1', 1637840958, '__ci_last_regenerate|i:1637840958;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5989113g2qvlouq1m31opnrkqdg059jq', '::1', 1637831950, '__ci_last_regenerate|i:1637831950;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5tln56k9hv593g6gpofl5kbj8f5anhak', '::1', 1637841262, '__ci_last_regenerate|i:1637841262;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";message-success|s:31:\"Client mis à jour avec succès\";__ci_vars|a:1:{s:15:\"message-success\";s:3:\"old\";}');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('678soio0ar5ngln1ggkahcvbe5mfis5f', '127.0.0.1', 1637838313, '__ci_last_regenerate|i:1637838313;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6fej76mjeb1llttiejc9r10tatbeh489', '::1', 1637841588, '__ci_last_regenerate|i:1637841588;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:5:\"false\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6t3l68282i5d7p2eau1jt5t4id75jh0e', '::1', 1637839537, '__ci_last_regenerate|i:1637839537;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6vg9ki3ttbp183h6bk9ilkmjkbeknruo', '::1', 1637833540, '__ci_last_regenerate|i:1637833540;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8ia1ttd7lkrhm6tvc9kgm7mp2mj3c80g', '::1', 1637833844, '__ci_last_regenerate|i:1637833844;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:42:\"http://localhost/CRM/crm/clients/estimates\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a92pvc2tqih2srr0n8mqepdlfj9hgckp', '::1', 1637833101, '__ci_last_regenerate|i:1637833101;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ber24ag2nl8ugd6ht93nhk43t97o4qf8', '::1', 1637832685, '__ci_last_regenerate|i:1637832685;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ei5oahiifl1kvul3onv956frof661kd7', '::1', 1637842162, '__ci_last_regenerate|i:1637842162;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:5:\"false\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqnkbe0m86d4pjbvokia900b344hr91c', '::1', 1637831463, '__ci_last_regenerate|i:1637831463;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gdj2cj836ba1qd09vole790c0l3h971v', '::1', 1637834186, '__ci_last_regenerate|i:1637834186;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:42:\"http://localhost/CRM/crm/clients/estimates\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hg5a1sejnse5omc1gbup7j8agq4qetak', '::1', 1637835032, '__ci_last_regenerate|i:1637835032;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lv1iiftkbejnaqdtf8uajovp7d8f5hhg', '::1', 1637839134, '__ci_last_regenerate|i:1637839134;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lvj82k35hto8dan8oij454osoa2tr4tv', '::1', 1637837924, '__ci_last_regenerate|i:1637837921;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r5v13q1pqtnrc2vjegnckbbfcn9kghi1', '::1', 1637832280, '__ci_last_regenerate|i:1637832280;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|b:1;');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rg4al9gfqm1piorusbmqcvdh5j6d0nku', '::1', 1637834636, '__ci_last_regenerate|i:1637834636;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";red_url|s:42:\"http://localhost/CRM/crm/clients/estimates\";leads_kanban_view|s:4:\"true\";estimate_pipeline|s:5:\"false\";');
INSERT INTO `tblsessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ud4ka1v3k59c0p76q9cv5agecnqs5qcf', '::1', 1637842284, '__ci_last_regenerate|i:1637842162;staff_user_id|s:1:\"1\";staff_logged_in|b:1;setup-menu-open|s:0:\"\";leads_kanban_view|s:5:\"false\";estimate_pipeline|s:5:\"false\";red_url|s:41:\"http://localhost/CRM/crm/clients/invoices\";');


#
# TABLE STRUCTURE FOR: tblshared_customer_files
#

DROP TABLE IF EXISTS `tblshared_customer_files`;

CREATE TABLE `tblshared_customer_files` (
  `file_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblspam_filters
#

DROP TABLE IF EXISTS `tblspam_filters`;

CREATE TABLE `tblspam_filters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(40) NOT NULL,
  `rel_type` varchar(10) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaff
#

DROP TABLE IF EXISTS `tblstaff`;

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `phonenumber` varchar(30) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(191) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT 0,
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT 1,
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(191) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT 0,
  `two_factor_auth_enabled` tinyint(1) DEFAULT 0,
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` text DEFAULT NULL,
  `google_auth_secret` text DEFAULT NULL,
  `facebook` char(50) NOT NULL,
  PRIMARY KEY (`staffid`),
  KEY `firstname` (`firstname`),
  KEY `lastname` (`lastname`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (1, 'chammaa.hossam@assursocial.com', 'Houssameddin', 'chammaa', '', '$2a$08$b4IqsQmyPZCC1XsdxypuZOnggD1OdFF43TReuixDB35bQVkacoJ1O', '2021-11-16 15:19:24', NULL, '::1', '2021-11-25 09:05:33', '2021-11-25 12:11:28', NULL, NULL, NULL, 1, 5, 1, 'french', NULL, NULL, 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (3, 'spervisor@spervisor.hy', 'spervisor', 'spervisor', '05487787455', '$2a$08$Ih3GE2hLlFnI6pkXjFyePu2wyW9ykEGXuIeEDkew54MSQMHYdMGVu', '2021-11-16 14:56:17', NULL, '::1', '2021-11-24 10:18:54', '2021-11-24 10:19:57', '2021-11-24 10:18:39', NULL, NULL, 0, 2, 1, 'french', NULL, 'spervisor-spervisor', 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (4, 'gestionnaire@gestionnaire.ki', 'gestionnaire', 'gestionnaire', '156486548486', '$2a$08$FNsT2Ocf/egSVPFFVUUtg.7Bzwitl31AlAGid0MkP8e779ahXjMnS', '2021-11-16 15:00:56', NULL, '::1', '2021-11-24 10:44:25', '2021-11-24 10:45:27', '2021-11-24 10:44:16', NULL, NULL, 0, 4, 1, 'french', NULL, 'gestionnaire-gestionnaire', 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (5, 'test@test.fr', 'test', 'test', '56488978', '$2a$08$uBXOBCuB/wL6WLS2Y9..dujxaojxcgaEIpsw92NRe5naFDs7UJ3jO', '2021-11-19 10:43:33', NULL, '::1', '2021-11-19 10:44:12', '2021-11-19 10:47:21', NULL, NULL, NULL, 0, 2, 1, 'french', NULL, 'test-test', 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (6, 'resp@resp.com', 'responsable', 'resonsable', '054875245', '$2a$08$kqEoy1ed7lQZ0QkfwQOiOeRuj.VgNXFr.a3qk0iyAetzoWkE0wnki', '2021-11-19 11:08:34', NULL, '::1', '2021-11-24 14:32:15', '2021-11-24 15:06:17', '2021-11-24 14:32:04', NULL, NULL, 0, 1, 1, 'french', NULL, 'responsable-resonsable', 0, 0, NULL, NULL, '', NULL, 'Equipe B');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (7, 'zaddz@zdk', 'zdzad', 'dzadza', '54654', '$2a$08$K6LzDP9Bt0F31pa8vmU3juSiTzJB9dDKOlLEU.cjJwx/D06sx6uRi', '2021-11-23 15:47:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1, 'french', NULL, 'zdzad-dzadza', 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (8, 'yey@ly.hy', 'etre', 'ryrte', 'grz', '$2a$08$N6j9j4o3cPDBuVwCL1w3BeSAcaCC8EsU2kRTIxYkWTh7kPGosCq5W', '2021-11-23 15:58:45', NULL, NULL, NULL, NULL, '2021-11-25 09:11:17', NULL, NULL, 0, 2, 1, '', NULL, 'etre-ryrte', 0, 0, NULL, NULL, '', NULL, 'ezrt');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (9, 'trztr@rtkl.gr', 'erter', 'trzt', '654651', '$2a$08$Qjaq7MATlBTO9UnSjXxQL..fP19vjsyBns12kdpmcrGHC.H99Iviy', '2021-11-23 15:59:41', NULL, '::1', '2021-11-24 15:09:20', '2021-11-24 15:11:05', '2021-11-24 15:09:09', NULL, NULL, 0, 2, 1, '', NULL, 'erter-trzt', 0, 0, NULL, NULL, '', NULL, 'ezrezr');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (10, 'erg@regk.gtg', 'fg', 'gefr', '5456', '$2a$08$nIz1ZDMvYeiiNxdxO2Zk6ebg4qqPbbUo4kDI8dvdaYYa3esF9QUOK', '2021-11-23 16:03:34', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1, '', NULL, 'fg-gefr', 0, 0, NULL, NULL, '', NULL, 'equpe 1');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (11, 'test@hdy.t', 'test', 'test', '545545', '$2a$08$RreVOreaWHbWLb.5VQMsdeEWNhGKV0jaeMYV5CLEC0g4MDOIO/p5a', '2021-11-23 16:14:08', NULL, '::1', '2021-11-23 16:21:02', '2021-11-23 16:26:25', NULL, NULL, NULL, 0, 2, 1, 'english', NULL, 'test-test', 0, 0, NULL, NULL, '', NULL, 'Equipe 14');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (12, 'andre.mora@assursocial.com', 'andré ', 'mora', '0547744539', '$2a$08$70YabxQt6ZoHO.yS/xYNoeISxpGE0NV0h6/YbznBQDZYo2.iGeBUa', '2021-11-24 15:14:52', NULL, '::1', '2021-11-24 16:17:04', '2021-11-24 17:26:04', '2021-11-24 16:16:53', NULL, NULL, 0, 2, 1, 'english', NULL, 'andre-mora', 0, 0, NULL, NULL, '', NULL, 'Auto silvia');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (13, 'silvia.alvares@assursocial.com', 'silvia', 'alvares ', '0547744539', '$2a$08$6l6d15oseWoDPKY8KjjxG.r5B9Axjg0E8CxxSsPJB.T2935QVQ4iO', '2021-11-24 15:17:09', NULL, '::1', '2021-11-24 15:24:27', '2021-11-24 15:25:17', NULL, NULL, NULL, 0, 1, 1, '', NULL, 'silvia-alvares', 0, 0, NULL, NULL, '', NULL, 'auto silvia');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (14, 'tyuhyt@lhk.hj', 'tyuty', 'trstr', '', '$2a$08$Y6tMrtSVrvo2qBx5NQRI/.kYa8LNg/u0yLfid.nnpEtswv2SJxIgW', '2021-11-24 18:20:48', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1, '', NULL, 'tyuty-trstr', 0, 0, NULL, NULL, '', NULL, '');
INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `phonenumber`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`, `google_auth_secret`, `facebook`) VALUES (15, 'gfdh@gfkhj.h', 'fghy', 'hdfh', '', '$2a$08$4dvJXjqsd6DcSW5afXqP7ewMB7SnqSkUKEfslhUMyHUMDQYzPph0O', '2021-11-24 18:21:53', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1, '', NULL, 'fghy-hdfh', 0, 0, NULL, NULL, '', NULL, '');


#
# TABLE STRUCTURE FOR: tblstaff_departments
#

DROP TABLE IF EXISTS `tblstaff_departments`;

CREATE TABLE `tblstaff_departments` (
  `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL,
  PRIMARY KEY (`staffdepartmentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblstaff_permissions
#

DROP TABLE IF EXISTS `tblstaff_permissions`;

CREATE TABLE `tblstaff_permissions` (
  `staff_id` int(11) NOT NULL,
  `feature` varchar(40) NOT NULL,
  `capability` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (7, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (5, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (11, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (10, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (3, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'contracts', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'knowledge_base', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'knowledge_base', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'knowledge_base', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'proposals', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (4, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'contracts', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'customers', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'email_templates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'create_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'edit_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'projects', 'delete_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'proposals', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimate_request', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (6, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (9, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'contracts', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'customers', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'email_templates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'create_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'edit_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'projects', 'delete_milestones');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'proposals', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'tasks', 'edit_timesheet');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'tasks', 'edit_own_timesheet');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'tasks', 'delete_timesheet');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'tasks', 'delete_own_timesheet');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimate_request', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (13, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (12, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (14, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'customers', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (15, 'leads', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'bulk_pdf_exporter', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'contracts', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'contracts', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'contracts', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'customers', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'customers', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'email_templates', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimates', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimates', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimates', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimates', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'items', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'items', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'items', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'items', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'knowledge_base', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'proposals', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'proposals', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'proposals', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'proposals', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'reports', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'staff', 'view');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimate_request', 'view_own');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimate_request', 'create');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimate_request', 'edit');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'estimate_request', 'delete');
INSERT INTO `tblstaff_permissions` (`staff_id`, `feature`, `capability`) VALUES (8, 'leads', 'view');


#
# TABLE STRUCTURE FOR: tblsubscriptions
#

DROP TABLE IF EXISTS `tblsubscriptions`;

CREATE TABLE `tblsubscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `description_in_item` tinyint(1) NOT NULL DEFAULT 0,
  `clientid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `currency` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id` varchar(50) DEFAULT NULL,
  `tax_id_2` int(11) NOT NULL DEFAULT 0,
  `stripe_tax_id_2` varchar(50) DEFAULT NULL,
  `stripe_plan_id` text DEFAULT NULL,
  `stripe_subscription_id` text NOT NULL,
  `next_billing_cycle` bigint(20) DEFAULT NULL,
  `ends_at` bigint(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `hash` varchar(32) NOT NULL,
  `created` datetime NOT NULL,
  `created_from` int(11) NOT NULL,
  `date_subscribed` datetime DEFAULT NULL,
  `in_test_environment` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clientid` (`clientid`),
  KEY `currency` (`currency`),
  KEY `tax_id` (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaggables
#

DROP TABLE IF EXISTS `tbltaggables`;

CREATE TABLE `tbltaggables` (
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(20) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `tag_order` int(11) NOT NULL DEFAULT 0,
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `tag_id` (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltags
#

DROP TABLE IF EXISTS `tbltags`;

CREATE TABLE `tbltags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_assigned
#

DROP TABLE IF EXISTS `tbltask_assigned`;

CREATE TABLE `tbltask_assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  `assigned_from` int(11) NOT NULL DEFAULT 0,
  `is_assigned_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `staffid` (`staffid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_checklist_items
#

DROP TABLE IF EXISTS `tbltask_checklist_items`;

CREATE TABLE `tbltask_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL,
  `description` text NOT NULL,
  `finished` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `finished_from` int(11) DEFAULT 0,
  `list_order` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_comments
#

DROP TABLE IF EXISTS `tbltask_comments`;

CREATE TABLE `tbltask_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `taskid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL DEFAULT 0,
  `file_id` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_id` (`file_id`),
  KEY `taskid` (`taskid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltask_followers
#

DROP TABLE IF EXISTS `tbltask_followers`;

CREATE TABLE `tbltask_followers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staffid` int(11) NOT NULL,
  `taskid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltasks
#

DROP TABLE IF EXISTS `tbltasks`;

CREATE TABLE `tbltasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` mediumtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  `startdate` date NOT NULL,
  `duedate` date DEFAULT NULL,
  `datefinished` datetime DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `is_added_from_contact` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `recurring_type` varchar(10) DEFAULT NULL,
  `repeat_every` int(11) DEFAULT NULL,
  `recurring` int(11) NOT NULL DEFAULT 0,
  `is_recurring_from` int(11) DEFAULT NULL,
  `cycles` int(11) NOT NULL DEFAULT 0,
  `total_cycles` int(11) NOT NULL DEFAULT 0,
  `custom_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `last_recurring_date` date DEFAULT NULL,
  `rel_id` int(11) DEFAULT NULL,
  `rel_type` varchar(30) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `billable` tinyint(1) NOT NULL DEFAULT 0,
  `billed` tinyint(1) NOT NULL DEFAULT 0,
  `invoice_id` int(11) NOT NULL DEFAULT 0,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `milestone` int(11) DEFAULT 0,
  `kanban_order` int(11) NOT NULL DEFAULT 0,
  `milestone_order` int(11) NOT NULL DEFAULT 0,
  `visible_to_client` tinyint(1) NOT NULL DEFAULT 0,
  `deadline_notified` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `rel_type` (`rel_type`),
  KEY `milestone` (`milestone`),
  KEY `kanban_order` (`kanban_order`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltasks_checklist_templates
#

DROP TABLE IF EXISTS `tbltasks_checklist_templates`;

CREATE TABLE `tbltasks_checklist_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaskstimers
#

DROP TABLE IF EXISTS `tbltaskstimers`;

CREATE TABLE `tbltaskstimers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) NOT NULL,
  `start_time` varchar(64) NOT NULL,
  `end_time` varchar(64) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT 0.00,
  `note` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `task_id` (`task_id`),
  KEY `staff_id` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltaxes
#

DROP TABLE IF EXISTS `tbltaxes`;

CREATE TABLE `tbltaxes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `taxrate` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltemplates
#

DROP TABLE IF EXISTS `tbltemplates`;

CREATE TABLE `tbltemplates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `addedfrom` int(11) NOT NULL,
  `content` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticket_attachments
#

DROP TABLE IF EXISTS `tblticket_attachments`;

CREATE TABLE `tblticket_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `replyid` int(11) DEFAULT NULL,
  `file_name` varchar(191) NOT NULL,
  `filetype` varchar(50) DEFAULT NULL,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblticket_replies
#

DROP TABLE IF EXISTS `tblticket_replies`;

CREATE TABLE `tblticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `name` text DEFAULT NULL,
  `email` text DEFAULT NULL,
  `date` datetime NOT NULL,
  `message` text DEFAULT NULL,
  `attachment` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets
#

DROP TABLE IF EXISTS `tbltickets`;

CREATE TABLE `tbltickets` (
  `ticketid` int(11) NOT NULL AUTO_INCREMENT,
  `adminreplying` int(11) NOT NULL DEFAULT 0,
  `userid` int(11) NOT NULL,
  `contactid` int(11) NOT NULL DEFAULT 0,
  `email` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `department` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `ticketkey` varchar(32) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` text DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `project_id` int(11) NOT NULL DEFAULT 0,
  `lastreply` datetime DEFAULT NULL,
  `clientread` int(11) NOT NULL DEFAULT 0,
  `adminread` int(11) NOT NULL DEFAULT 0,
  `assigned` int(11) NOT NULL DEFAULT 0,
  `cc` varchar(191) DEFAULT NULL,
  PRIMARY KEY (`ticketid`),
  KEY `service` (`service`),
  KEY `department` (`department`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `priority` (`priority`),
  KEY `project_id` (`project_id`),
  KEY `contactid` (`contactid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets_pipe_log
#

DROP TABLE IF EXISTS `tbltickets_pipe_log`;

CREATE TABLE `tbltickets_pipe_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `email_to` varchar(100) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `message` mediumtext NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets_predefined_replies
#

DROP TABLE IF EXISTS `tbltickets_predefined_replies`;

CREATE TABLE `tbltickets_predefined_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltickets_priorities
#

DROP TABLE IF EXISTS `tbltickets_priorities`;

CREATE TABLE `tbltickets_priorities` (
  `priorityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`priorityid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (1, 'Low');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (2, 'Medium');
INSERT INTO `tbltickets_priorities` (`priorityid`, `name`) VALUES (3, 'High');


#
# TABLE STRUCTURE FOR: tbltickets_status
#

DROP TABLE IF EXISTS `tbltickets_status`;

CREATE TABLE `tbltickets_status` (
  `ticketstatusid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT 0,
  `statuscolor` varchar(7) DEFAULT NULL,
  `statusorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`ticketstatusid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (1, 'Open', 1, '#ff2d42', 1);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (2, 'In progress', 1, '#84c529', 2);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (3, 'Answered', 1, '#0000ff', 3);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (4, 'On Hold', 1, '#c0c0c0', 4);
INSERT INTO `tbltickets_status` (`ticketstatusid`, `name`, `isdefault`, `statuscolor`, `statusorder`) VALUES (5, 'Closed', 1, '#03a9f4', 5);


#
# TABLE STRUCTURE FOR: tbltodos
#

DROP TABLE IF EXISTS `tbltodos`;

CREATE TABLE `tbltodos` (
  `todoid` int(11) NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `staffid` int(11) NOT NULL,
  `dateadded` datetime NOT NULL,
  `finished` tinyint(1) NOT NULL,
  `datefinished` datetime DEFAULT NULL,
  `item_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`todoid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltracked_mails
#

DROP TABLE IF EXISTS `tbltracked_mails`;

CREATE TABLE `tbltracked_mails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(32) NOT NULL,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(100) NOT NULL,
  `opened` tinyint(1) NOT NULL DEFAULT 0,
  `date_opened` datetime DEFAULT NULL,
  `subject` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbltwocheckout_log
#

DROP TABLE IF EXISTS `tbltwocheckout_log`;

CREATE TABLE `tbltwocheckout_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(64) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `tbltwocheckout_log_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `tblinvoices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbluser_auto_login
#

DROP TABLE IF EXISTS `tbluser_auto_login`;

CREATE TABLE `tbluser_auto_login` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbluser_auto_login` (`key_id`, `user_id`, `user_agent`, `last_ip`, `last_login`, `staff`) VALUES ('64b34e4e1167b8ec5884abe1dbc58598', 1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36', '::1', '2021-11-25 09:05:33', 1);


#
# TABLE STRUCTURE FOR: tbluser_meta
#

DROP TABLE IF EXISTS `tbluser_meta`;

CREATE TABLE `tbluser_meta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `client_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `contact_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(191) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('1', '1', '0', '0', 'recent_searches', '[]');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('2', '1', '0', '0', 'dashboard_widgets_visibility', NULL);
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('3', '1', '0', '0', 'dashboard_widgets_order', 'a:8:{s:6:\"top-12\";a:1:{i:0;s:16:\"widget-top_stats\";}s:13:\"middle-left-6\";a:0:{}s:14:\"middle-right-6\";a:0:{}s:6:\"left-8\";a:6:{i:0;s:23:\"widget-finance_overview\";i:1;s:16:\"widget-user_data\";i:2;s:22:\"widget-upcoming_events\";i:3;s:15:\"widget-calendar\";i:4;s:21:\"widget-payments_chart\";i:5;s:25:\"widget-contracts_expiring\";}s:7:\"right-4\";a:5:{i:0;s:12:\"widget-todos\";i:1;s:18:\"widget-leads_chart\";i:2;s:24:\"widget-projects_activity\";i:3;s:21:\"widget-projects_chart\";i:4;s:20:\"widget-tickets_chart\";}s:13:\"bottom-left-4\";a:0:{}s:15:\"bottom-middle-4\";a:0:{}s:14:\"bottom-right-4\";a:0:{}}');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('4', '0', '0', '1', 'consent_key', '1c98d58fbe1aa94edda04af39ec9c707-8f674e79f1f59c493e486c670903bf56');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('7', '0', '0', '2', 'consent_key', '7ef540ab11c8d7f3f5eebb107968c129-a14b7cb9f48015245b1eb0ce37fd5495');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('8', '0', '0', '3', 'consent_key', 'fbdac303651073372a02f5dc854d067c-dcd440cacd78962dff80c519972d3f0f');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('9', '0', '0', '4', 'consent_key', 'd64e3c4355a7ac1dcb9e0bca81bae6d8-c9c4a75ea8bf5548703421b72203ec03');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('10', '0', '0', '5', 'consent_key', '2bf6e0d83d26f5ed7e96e8fa53f036b3-f0a85940255b0056c59188e9ae471951');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('11', '0', '0', '6', 'consent_key', '4f6c9be34269a5e676fd93685bce4cd8-8dd3467383841c9d706424c11648ff32');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('12', '0', '0', '7', 'consent_key', 'cb64fae507e5bd49728f3446528d0a58-30b0ebc3e8bc5a77f7f1db7e8cdb7fd7');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('13', '0', '0', '8', 'consent_key', '34ed749fae4822126f6e8c28b423b639-68f2ae7771cf6bba7f38a49f49408e77');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('14', '0', '0', '9', 'consent_key', 'f1e23fbb7158dfd06b4b87db73c05655-008846fe0e9fab13237f9c0a8719ec3c');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('15', '0', '0', '10', 'consent_key', '95a9e4859e0bbad9ad2349665f2d592b-fa20415ccaddbb1589dd532b5cf69890');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('16', '0', '0', '11', 'consent_key', '02b9e73b34b6b2b1deb5d7df0abc304e-9bcea2d1562bfd92d6f5b8e68423f931');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('17', '0', '0', '12', 'consent_key', '8212a0503b144c5b996e1934779a1706-b86d982c329b44119427bcf848461864');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('18', '0', '0', '13', 'consent_key', '0893a39031a0d0ef2f5eebdda00267ed-dcd4af8d86d43e563a3b833eadd61334');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('19', '0', '0', '14', 'consent_key', '1dee550b64e1afdfae82681d2d8841bc-bcd0ead6f4b0c614c6fbf3b57eb22208');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('20', '0', '0', '15', 'consent_key', '3dd29073231fb951f0c8f8e83e71d9e7-be5bc14b02e6596ef25fcb01763a1166');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('21', '0', '0', '16', 'consent_key', '153b4169f93aee84e6d51a757acb9660-21032d23798efe8d9a4cc57b6770ec9f');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('22', '0', '0', '17', 'consent_key', 'c737db98505c0e039580b87601e6d4aa-2e345cbf67f5a90f373c388fff36ba0b');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('23', '0', '0', '18', 'consent_key', '6172372ff85381f320996fec56e1a281-59b18f1abac4b38f3c7b8dc301fe80ec');
INSERT INTO `tbluser_meta` (`umeta_id`, `staff_id`, `client_id`, `contact_id`, `meta_key`, `meta_value`) VALUES ('24', '0', '0', '19', 'consent_key', 'e7513c4acc630b9f2596b8ff011ab313-342c7f8b8254ccc6960083b79ef827d0');


#
# TABLE STRUCTURE FOR: tblvault
#

DROP TABLE IF EXISTS `tblvault`;

CREATE TABLE `tblvault` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `server_address` varchar(191) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `username` varchar(191) NOT NULL,
  `password` text NOT NULL,
  `description` text DEFAULT NULL,
  `creator` int(11) NOT NULL,
  `creator_name` varchar(100) DEFAULT NULL,
  `visibility` tinyint(1) NOT NULL DEFAULT 1,
  `share_in_projects` tinyint(1) NOT NULL DEFAULT 0,
  `last_updated` datetime DEFAULT NULL,
  `last_updated_from` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tblviews_tracking
#

DROP TABLE IF EXISTS `tblviews_tracking`;

CREATE TABLE `tblviews_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_id` int(11) NOT NULL,
  `rel_type` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  `view_ip` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `tblviews_tracking` (`id`, `rel_id`, `rel_type`, `date`, `view_ip`) VALUES (1, 2, 'estimate', '2021-11-24 16:09:46', '::1');
INSERT INTO `tblviews_tracking` (`id`, `rel_id`, `rel_type`, `date`, `view_ip`) VALUES (2, 1, 'invoice', '2021-11-24 16:14:18', '::1');


#
# TABLE STRUCTURE FOR: tblweb_to_lead
#

DROP TABLE IF EXISTS `tblweb_to_lead`;

CREATE TABLE `tblweb_to_lead` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `lead_source` int(11) NOT NULL,
  `lead_status` int(11) NOT NULL,
  `notify_lead_imported` int(11) NOT NULL DEFAULT 1,
  `notify_type` varchar(20) DEFAULT NULL,
  `notify_ids` mediumtext DEFAULT NULL,
  `responsible` int(11) NOT NULL DEFAULT 0,
  `name` varchar(191) NOT NULL,
  `form_data` mediumtext DEFAULT NULL,
  `recaptcha` int(11) NOT NULL DEFAULT 0,
  `submit_btn_name` varchar(40) DEFAULT NULL,
  `submit_btn_text_color` varchar(10) DEFAULT '#ffffff',
  `submit_btn_bg_color` varchar(10) DEFAULT '#84c529',
  `success_submit_msg` text DEFAULT NULL,
  `submit_action` int(11) DEFAULT 0,
  `submit_redirect_url` mediumtext DEFAULT NULL,
  `language` varchar(40) DEFAULT NULL,
  `allow_duplicate` int(11) NOT NULL DEFAULT 1,
  `mark_public` int(11) NOT NULL DEFAULT 0,
  `track_duplicate_field` varchar(20) DEFAULT NULL,
  `track_duplicate_field_and` varchar(20) DEFAULT NULL,
  `create_task_on_duplicate` int(11) NOT NULL DEFAULT 0,
  `dateadded` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

